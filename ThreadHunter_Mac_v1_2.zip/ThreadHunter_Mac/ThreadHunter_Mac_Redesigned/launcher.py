"""
launcher.py
-----------
ThreadHunter startup screen.
IRFlow-inspired design: near-black, monospace accents, dense data aesthetic.
"""
import customtkinter as ctk
from tkinter import filedialog, messagebox
from pathlib import Path
from typing import Callable, Optional, List
from datetime import datetime
import json

from core.case import Case


def _secure_delete(path) -> bool:
    """Overwrite file with zeros before deletion to reduce forensic recoverability."""
    from pathlib import Path as _P
    p = _P(path)
    try:
        size = p.stat().st_size
        if size > 0:
            with open(p, "r+b") as fh:
                fh.write(b"\x00" * size)
                fh.flush()
    except Exception:
        pass
    try:
        p.unlink(missing_ok=True)
        return True
    except Exception:
        return False


# ── Windows GUI Colour Palette ───────────────────────────────────────────────────
BG          = "#1A1D27"
PANEL       = "#1E2235"
SIDEBAR     = "#181B25"
CARD        = "#21253A"
CARD_HOV    = "#292E47"
BORDER      = "#2A2F4A"
BORDER_LT   = "#383E5E"
ACCENT      = "#6374F8"
ACCENT_HOV  = "#8B9EFF"
ACCENT_DIM  = "#4A57D4"
GREEN       = "#2EAD7A"
GREEN_HOV   = "#42CC8A"
TEXT        = "#FFFFFF"
TEXT_DIM    = "#8C90A4"
TEXT_MUTED  = "#6C7185"
MONO = "Menlo"

RECENT_FILE = Path.home() / ".threadhunter_recent"
MAX_RECENT  = 8


def _load_recent() -> List[str]:
    try:
        if RECENT_FILE.exists():
            data = json.loads(RECENT_FILE.read_text())
            return [p for p in data if Path(p).exists()]
    except Exception:
        pass
    return []


def _save_recent(paths: List[str]):
    try:
        RECENT_FILE.write_text(json.dumps(paths[:MAX_RECENT]))
    except Exception:
        pass


def _add_recent(path: str):
    paths = _load_recent()
    path  = str(Path(path).resolve())
    if path in paths:
        paths.remove(path)
    paths.insert(0, path)
    _save_recent(paths)


def _remove_recent(path: str):
    paths = _load_recent()
    path  = str(Path(path).resolve())
    if path in paths:
        paths.remove(path)
    _save_recent(paths)



def _make_app_icon(size=64):
    """
    Generate the ThreadHunter ◎ logo as a tk.PhotoImage for use as the window icon.
    Requires Pillow. Falls back silently if unavailable.
    """
    try:
        from PIL import Image, ImageDraw, ImageFont
        import tempfile, os
        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        # Outer ring
        margin = size // 10
        draw.ellipse([margin, margin, size - margin, size - margin],
                     outline="#6374F8", width=max(3, size // 12))
        # Inner dot
        dot_margin = size // 3
        draw.ellipse([dot_margin, dot_margin, size - dot_margin, size - dot_margin],
                     fill="#6374F8")
        # Save to temp and load as PhotoImage
        tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        img.save(tmp.name, "PNG")
        tmp.close()
        import tkinter as tk
        photo = tk.PhotoImage(file=tmp.name)
        os.unlink(tmp.name)
        return photo
    except Exception:
        return None

class NewCaseDialog(ctk.CTkToplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("New Case")
        self.resizable(False, False)
        self.configure(fg_color=BG)
        self.grab_set()
        self.result: Optional[dict] = None
        self._build()
        self.geometry("520x490")
        self._centre(parent)
        self.after(80, self._focus)

    def _centre(self, parent):
        self.update_idletasks()
        pw = parent.winfo_x() + parent.winfo_width() // 2
        ph = parent.winfo_y() + parent.winfo_height() // 2
        w, h = 520, 490
        self.geometry(f"{w}x{h}+{pw - w//2}+{ph - h//2}")

    def _focus(self):
        self.lift()
        self.focus_force()
        self._name_entry.focus_set()

    def _build(self):
        self.grid_columnconfigure(0, weight=1)
        row = 0

        # Header bar
        hdr = ctk.CTkFrame(self, fg_color=PANEL, corner_radius=0, height=48)
        hdr.grid(row=row, column=0, sticky="ew")
        hdr.grid_propagate(False)
        hdr.grid_columnconfigure(0, weight=1)
        ctk.CTkFrame(hdr, fg_color=ACCENT, width=3, corner_radius=0).place(x=0, y=0, relheight=1.0)
        ctk.CTkLabel(hdr,
                     text="NEW INVESTIGATION",
                     font=ctk.CTkFont(family=MONO, size=11, weight="bold"),
                     text_color=ACCENT).grid(row=0, column=0, padx=20, pady=14, sticky="w")
        row += 1

        ctk.CTkFrame(self, fg_color=BORDER, height=1).grid(row=row, column=0, sticky="ew")
        row += 1

        fields = [
            ("CASE NAME *",   "_name_entry",    "BEC — Acme Corp Jan 2026"),
            ("CLIENT",        "_client_entry",  "Acme Corporation"),
            ("LEAD ANALYST",  "_analyst_entry", ""),
            ("DESCRIPTION",   "_desc_entry",    "Brief summary of the engagement"),
        ]

        for label_text, attr, placeholder in fields:
            ctk.CTkLabel(self,
                         text=label_text,
                         font=ctk.CTkFont(family=MONO, size=9, weight="bold"),
                         text_color=TEXT_DIM).grid(
                row=row, column=0, padx=20, pady=(10, 2), sticky="w")
            row += 1
            entry = ctk.CTkEntry(
                self, placeholder_text=placeholder,
                fg_color=CARD, border_color=BORDER_LT, border_width=1,
                text_color=TEXT, placeholder_text_color=TEXT_MUTED,
                height=32, font=ctk.CTkFont(family=MONO, size=11))
            entry.grid(row=row, column=0, padx=20, pady=0, sticky="ew")
            setattr(self, attr, entry)
            row += 1

        ctk.CTkLabel(self, text="SAVE LOCATION *",
                     font=ctk.CTkFont(family=MONO, size=9, weight="bold"),
                     text_color=TEXT_DIM).grid(row=row, column=0, padx=20, pady=(10, 2), sticky="w")
        row += 1
        loc = ctk.CTkFrame(self, fg_color="transparent")
        loc.grid(row=row, column=0, padx=20, pady=0, sticky="ew")
        loc.grid_columnconfigure(0, weight=1)
        row += 1
        self._path_var = ctk.StringVar()
        ctk.CTkEntry(loc, textvariable=self._path_var,
                     fg_color=CARD, border_color=BORDER_LT, border_width=1,
                     text_color=TEXT, height=32,
                     font=ctk.CTkFont(family=MONO, size=11)).grid(
            row=0, column=0, sticky="ew", padx=(0, 6))
        ctk.CTkButton(loc, text="BROWSE", width=80, height=32,
                      fg_color=CARD, hover_color=CARD_HOV, text_color=TEXT_DIM,
                      border_color=BORDER_LT, border_width=1,
                      font=ctk.CTkFont(family=MONO, size=9, weight="bold"),
                      command=self._browse).grid(row=0, column=1)

        self.grid_rowconfigure(row, weight=1)
        row += 1

        ctk.CTkFrame(self, fg_color=BORDER, height=1).grid(row=row, column=0, sticky="ew", pady=(8, 0))
        row += 1

        btns = ctk.CTkFrame(self, fg_color=PANEL, corner_radius=0, height=56)
        btns.grid(row=row, column=0, sticky="ew")
        btns.grid_propagate(False)
        inner = ctk.CTkFrame(btns, fg_color="transparent")
        inner.place(relx=1.0, rely=0.5, anchor="e", x=-20)
        ctk.CTkButton(inner, text="CANCEL", width=80, height=30,
                      fg_color="transparent", hover_color=CARD_HOV,
                      text_color=TEXT_DIM, border_color=BORDER_LT, border_width=1,
                      font=ctk.CTkFont(family=MONO, size=9, weight="bold"),
                      command=self.destroy).grid(row=0, column=0, padx=(0, 8))
        ctk.CTkButton(inner, text="CREATE CASE ›", width=120, height=30,
                      fg_color=ACCENT, hover_color=ACCENT_HOV, text_color="#FFFFFF",
                      font=ctk.CTkFont(family=MONO, size=9, weight="bold"),
                      command=self._submit).grid(row=0, column=1)

    def _browse(self):
        name = self._name_entry.get().strip() or "NewCase"
        safe = "".join(c if c.isalnum() or c in " _-" else "_" for c in name)
        path = filedialog.asksaveasfilename(
            title="Save Case As", defaultextension=".threadhunter",
            initialfile=f"{safe}.threadhunter",
            filetypes=[("ThreadHunter Case", "*.threadhunter"), ("All files", "*.*")])
        if path:
            self._path_var.set(path)

    def _submit(self):
        name = self._name_entry.get().strip()
        path = self._path_var.get().strip()
        if not name:
            messagebox.showwarning("Required", "Case Name is required.", parent=self)
            self._name_entry.focus_set()
            return
        if not path:
            messagebox.showwarning("Required", "Choose a save location.", parent=self)
            return

        # PII advisory — shown once before creating the file
        if not messagebox.askokcancel(
            "Data Handling Advisory",
            "The case file will contain personal information from the\n"
            "audit log, including user identities, IP addresses, and\n"
            "access records.\n\n"
            "•  Store the file on an encrypted volume\n"
            "•  Do not store on unencrypted shared drives\n"
            "•  Delete case files when no longer required\n"
            "•  Handle in accordance with your engagement data\n"
            "   handling policy and applicable privacy law\n\n"
            "Continue creating case?",
            parent=self):
            return

        self.result = {
            "name": name, "client": self._client_entry.get().strip(),
            "analyst": self._analyst_entry.get().strip(),
            "description": self._desc_entry.get().strip(), "path": path,
        }
        self.destroy()


class LauncherWindow(ctk.CTk):
    def __init__(self, on_case_opened: Callable):
        super().__init__()
        self._callback = on_case_opened
        self.title("ThreadHunter — BEC Forensics")
        self.geometry("860x560")
        self.resizable(False, False)
        self.configure(fg_color=BG)
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")
        self._build()
        # Set window icon (after build so window exists)
        self.after(100, self._set_icon)

    def _set_icon(self):
        _icon = _make_app_icon(64)
        if _icon:
            try:
                self.wm_iconphoto(True, _icon)
                self._icon_ref = _icon  # prevent GC
            except Exception:
                pass

    def _build(self):
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        # ── Left rail ──────────────────────────────────────────────────────────
        left = ctk.CTkFrame(self, fg_color=SIDEBAR, corner_radius=0, width=260)
        left.grid(row=0, column=0, sticky="nsew")
        left.grid_propagate(False)
        left.grid_columnconfigure(0, weight=1)

        # Top accent line
        ctk.CTkFrame(left, fg_color=ACCENT, height=2, corner_radius=0).grid(
            row=0, column=0, sticky="ew")

        # Brand area
        ctk.CTkLabel(left, text="◎",
                     font=ctk.CTkFont(size=36), text_color=ACCENT).grid(
            row=1, column=0, padx=22, pady=(28, 4), sticky="w")
        ctk.CTkLabel(left, text="THREADHUNTER",
                     font=ctk.CTkFont(family=MONO, size=15, weight="bold"),
                     text_color=TEXT).grid(row=2, column=0, padx=22, pady=(0, 0), sticky="w")
        ctk.CTkLabel(left, text="BEC FORENSICS PLATFORM",
                     font=ctk.CTkFont(family=MONO, size=9),
                     text_color=TEXT_DIM).grid(row=3, column=0, padx=22, pady=(2, 0), sticky="w")

        ctk.CTkFrame(left, fg_color=BORDER_LT, height=1).grid(
            row=4, column=0, padx=22, pady=(22, 16), sticky="ew")

        ctk.CTkLabel(left, text="START",
                     font=ctk.CTkFont(family=MONO, size=9, weight="bold"),
                     text_color=TEXT_MUTED).grid(row=5, column=0, padx=22, pady=(0, 8), sticky="w")

        ctk.CTkButton(left, text="＋  NEW CASE",
                      fg_color=ACCENT, hover_color=ACCENT_HOV,
                      text_color="#FFFFFF", height=36, corner_radius=4,
                      font=ctk.CTkFont(family=MONO, size=10, weight="bold"),
                      command=self._new_case).grid(
            row=6, column=0, padx=18, pady=(0, 6), sticky="ew")

        ctk.CTkButton(left, text="▶  OPEN CASE FILE",
                      fg_color=CARD, hover_color=CARD_HOV,
                      text_color=TEXT_DIM, border_color=BORDER_LT, border_width=1,
                      height=34, corner_radius=4,
                      font=ctk.CTkFont(family=MONO, size=10),
                      command=self._open_case).grid(
            row=7, column=0, padx=18, pady=(0, 4), sticky="ew")

        left.grid_rowconfigure(8, weight=1)

        # Version strip at bottom
        ver = ctk.CTkFrame(left, fg_color=PANEL, corner_radius=0, height=36)
        ver.grid(row=9, column=0, sticky="sew")
        ver.grid_propagate(False)
        ver.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(ver, text="v1.0  ·  macOS  ·  DFIR",
                     font=ctk.CTkFont(family=MONO, size=9),
                     text_color=TEXT_MUTED).grid(row=0, column=0, padx=14, sticky="w")

        # ── Right panel ────────────────────────────────────────────────────────
        right = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        right.grid(row=0, column=1, sticky="nsew")
        right.grid_rowconfigure(2, weight=1)
        right.grid_columnconfigure(0, weight=1)

        ctk.CTkFrame(right, fg_color=ACCENT, height=2, corner_radius=0).grid(
            row=0, column=0, sticky="ew")

        hdr = ctk.CTkFrame(right, fg_color=PANEL, corner_radius=0, height=36)
        hdr.grid(row=1, column=0, sticky="ew")
        hdr.grid_propagate(False)
        hdr.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(hdr, text="RECENT CASES",
                     font=ctk.CTkFont(family=MONO, size=9, weight="bold"),
                     text_color=TEXT_DIM).grid(row=0, column=0, padx=16, sticky="w")

        self._recent_frame = ctk.CTkScrollableFrame(
            right, fg_color="transparent",
            scrollbar_button_color=BORDER_LT,
            scrollbar_button_hover_color=ACCENT_DIM)
        self._recent_frame.grid(row=2, column=0, sticky="nsew")
        self._recent_frame.grid_columnconfigure(0, weight=1)
        self._load_recent_cases()

    def _load_recent_cases(self):
        for w in self._recent_frame.winfo_children():
            w.destroy()
        recents = _load_recent()
        if not recents:
            ctk.CTkLabel(self._recent_frame,
                         text="No recent cases.\nCreate a new case to get started.",
                         font=ctk.CTkFont(family=MONO, size=11),
                         text_color=TEXT_MUTED, justify="center").grid(
                row=0, column=0, pady=80)
            return
        for i, path in enumerate(recents):
            self._recent_card(path, i)

    def _recent_card(self, path: str, row: int):
        p = Path(path)
        card = ctk.CTkFrame(self._recent_frame, fg_color=CARD, corner_radius=0, cursor="hand2")
        card.grid(row=row * 2, column=0, sticky="ew")
        card.grid_columnconfigure(1, weight=1)
        card.grid_columnconfigure(2, weight=0)

        accent_bar = ctk.CTkFrame(card, fg_color=BG, width=3, corner_radius=0)
        accent_bar.grid(row=0, column=0, rowspan=3, sticky="ns")

        name = p.stem
        meta_parts = []
        try:
            from core.database import Database
            db = Database(path).open()
            rows = db.fetchall("SELECT key, value FROM case_meta")
            meta = {r["key"]: r["value"] for r in rows}
            db.close()
            name      = meta.get("name", name)
            client    = meta.get("client", "")
            analyst   = meta.get("analyst", "")
            updated   = meta.get("updated_at", "")[:10]
            meta_parts = [x for x in [client, analyst, updated] if x]
        except Exception:
            pass

        ctk.CTkLabel(card, text=name,
                     font=ctk.CTkFont(family=MONO, size=12, weight="bold"),
                     text_color=TEXT, anchor="w").grid(
            row=0, column=1, padx=(10, 14), pady=(10, 1), sticky="w")
        ctk.CTkLabel(card, text=str(p),
                     font=ctk.CTkFont(family=MONO, size=9),
                     text_color=TEXT_MUTED, anchor="w", wraplength=480).grid(
            row=1, column=1, padx=(10, 14), pady=(0, 2), sticky="w")
        if meta_parts:
            ctk.CTkLabel(card, text="  ·  ".join(meta_parts),
                         font=ctk.CTkFont(family=MONO, size=9),
                         text_color=ACCENT, anchor="w").grid(
                row=2, column=1, padx=(10, 14), pady=(0, 10), sticky="w")
        else:
            ctk.CTkLabel(card, text="", height=4).grid(row=2, column=1)

        ctk.CTkFrame(self._recent_frame, fg_color=BORDER, height=1, corner_radius=0).grid(
            row=row * 2 + 1, column=0, sticky="ew")

        # Delete button — top-right corner of card
        del_btn = ctk.CTkButton(
            card, text="✕",
            width=24, height=24,
            fg_color="transparent",
            hover_color="#450A0A",
            text_color=TEXT_MUTED,
            font=ctk.CTkFont(family=MONO, size=10, weight="bold"),
            corner_radius=3,
            command=lambda pp=path: self._delete_case(pp))
        del_btn.grid(row=0, column=2, padx=(0, 8), pady=(8, 0), sticky="ne")

        def _enter(e, c=card, ab=accent_bar):
            c.configure(fg_color=CARD_HOV); ab.configure(fg_color=ACCENT)
        def _leave(e, c=card, ab=accent_bar):
            c.configure(fg_color=CARD); ab.configure(fg_color=BG)
        def _click(e, pp=path):
            self._open_path(pp)

        # Bind open action to card background and text labels only.
        # The delete button handles its own click via command=.
        for widget in [card, accent_bar]:
            widget.bind("<Button-1>", _click)
            widget.bind("<Enter>",    _enter)
            widget.bind("<Leave>",    _leave)
        # Also bind the text label children (not del_btn or its internals)
        for child in card.winfo_children():
            if isinstance(child, ctk.CTkLabel):
                child.bind("<Button-1>", _click)
                child.bind("<Enter>",    _enter)
                child.bind("<Leave>",    _leave)

    def _new_case(self):
        dlg = NewCaseDialog(self)
        self.wait_window(dlg)
        if not dlg.result:
            return
        r = dlg.result
        try:
            case = Case.create(r["path"], r["name"], client=r["client"],
                               analyst=r["analyst"], description=r["description"])
            _add_recent(r["path"])
            self._launch(case)
        except Exception as e:
            messagebox.showerror("Error", f"Could not create case:\n{e}")

    def _open_case(self):
        path = filedialog.askopenfilename(
            title="Open Case",
            filetypes=[("ThreadHunter Case", "*.threadhunter"), ("All Files", "*.*")])
        if path:
            self._open_path(path)

    def _open_path(self, path: str):
        try:
            case = Case.open(path)
            _add_recent(path)
            self._launch(case)
        except Exception as e:
            messagebox.showerror("Error", f"Could not open case:\n{e}")
            self._load_recent_cases()

    def _delete_case(self, path: str):
        """Delete a case file after confirmation and refresh the recent list."""
        p = Path(path)
        name = p.stem
        try:
            from core.database import Database
            db = Database(path).open()
            rows = db.fetchall("SELECT key, value FROM case_meta")
            meta = {r["key"]: r["value"] for r in rows}
            db.close()
            name = meta.get("name", name)
        except Exception:
            pass

        if not messagebox.askyesno(
            "Delete Case",
            f"Permanently delete case:\n\n\"{name}\"\n\n"
            f"File: {path}\n\n"
            "This cannot be undone.",
            icon="warning"):
            return

        try:
            if not _secure_delete(path):
                messagebox.showerror("Delete Failed", "Could not delete file.")
                return
        except Exception as e:
            messagebox.showerror("Delete Failed", f"Could not delete file:\n{e}")
            return

        _remove_recent(path)
        self._load_recent_cases()

    def _launch(self, case: Case):
        self.withdraw()
        self._callback(case, self)
