#!/usr/bin/env python3
"""
ThreadHunter — BEC Forensics  v2.1
GUI for enriching and visualising M365 Unified Audit Log data.
Features: GeoIP enrichment · TkinterMapView · IOC filtering · Impossible travel detection · HTML report export
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import customtkinter as ctk
import threading
import queue
import json
import re
import sys
import math
import os
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, List, Any, Tuple
from collections import defaultdict

# ── Bundled TkinterMapView ────────────────────────────────────────────────────
sys.path.insert(0, str(Path(__file__).parent))
try:
    from tkintermapview import TkinterMapView
    MAPVIEW_AVAILABLE = True
except ImportError:
    MAPVIEW_AVAILABLE = False

# ── Optional dependencies ─────────────────────────────────────────────────────
try:
    import polars as pl
    POLARS_AVAILABLE = True
except ImportError:
    POLARS_AVAILABLE = False

try:
    import geoip2.database
    import geoip2.errors
    GEOIP2_AVAILABLE = True
except ImportError:
    GEOIP2_AVAILABLE = False

try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

# ── Country centroids (fallback when GeoIP has no exact coordinates) ──────────
COUNTRY_COORDS: Dict[str, Tuple[float, float]] = {
    "Afghanistan": (33.93, 67.71), "Albania": (41.15, 20.17),
    "Algeria": (28.03, 1.66), "Angola": (-11.20, 17.87),
    "Argentina": (-38.42, -63.62), "Armenia": (40.07, 45.04),
    "Australia": (-25.27, 133.78), "Austria": (47.52, 14.55),
    "Azerbaijan": (40.14, 47.58), "Bahrain": (25.93, 50.64),
    "Bangladesh": (23.68, 90.36), "Belarus": (53.71, 27.95),
    "Belgium": (50.50, 4.47), "Bolivia": (-16.29, -63.59),
    "Bosnia and Herzegovina": (43.92, 17.68),
    "Brazil": (-14.24, -51.93), "Bulgaria": (42.73, 25.49),
    "Cambodia": (12.57, 104.99), "Cameroon": (7.37, 12.35),
    "Canada": (56.13, -106.35), "Chile": (-35.68, -71.54),
    "China": (35.86, 104.20), "Colombia": (4.57, -74.30),
    "Costa Rica": (9.75, -83.75), "Croatia": (45.10, 15.20),
    "Cuba": (21.52, -77.78), "Cyprus": (35.13, 33.43),
    "Czech Republic": (49.82, 15.47), "Denmark": (56.26, 9.50),
    "Dominican Republic": (18.74, -70.16), "Ecuador": (-1.83, -78.18),
    "Egypt": (26.82, 30.80), "El Salvador": (13.79, -88.90),
    "Estonia": (58.60, 25.01), "Ethiopia": (9.15, 40.49),
    "Finland": (61.92, 25.75), "France": (46.23, 2.21),
    "Georgia": (42.32, 43.36), "Germany": (51.17, 10.45),
    "Ghana": (7.95, -1.02), "Greece": (39.07, 21.82),
    "Guatemala": (15.78, -90.23), "Honduras": (15.20, -86.24),
    "Hong Kong": (22.40, 114.11), "Hungary": (47.16, 19.50),
    "Iceland": (64.96, -19.02), "India": (20.59, 78.96),
    "Indonesia": (-0.79, 113.92), "Iran": (32.43, 53.69),
    "Iraq": (33.22, 43.68), "Ireland": (53.41, -8.24),
    "Israel": (31.05, 34.85), "Italy": (41.87, 12.57),
    "Jamaica": (18.11, -77.30), "Japan": (36.20, 138.25),
    "Jordan": (30.59, 36.24), "Kazakhstan": (48.02, 66.92),
    "Kenya": (-0.02, 37.91), "Kuwait": (29.31, 47.48),
    "Latvia": (56.88, 24.60), "Lebanon": (33.85, 35.86),
    "Libya": (26.34, 17.23), "Lithuania": (55.17, 23.88),
    "Luxembourg": (49.82, 6.13), "Malaysia": (4.21, 101.98),
    "Malta": (35.94, 14.38), "Mexico": (23.63, -102.55),
    "Moldova": (47.41, 28.37), "Mongolia": (46.86, 103.85),
    "Montenegro": (42.71, 19.37), "Morocco": (31.79, -7.09),
    "Mozambique": (-18.67, 35.53), "Myanmar": (21.91, 95.96),
    "Nepal": (28.39, 84.12), "Netherlands": (52.13, 5.29),
    "New Zealand": (-40.90, 174.89), "Nicaragua": (12.87, -85.21),
    "Nigeria": (9.08, 8.68), "Norway": (60.47, 8.47),
    "Oman": (21.51, 55.92), "Pakistan": (30.38, 69.35),
    "Panama": (8.54, -80.78), "Paraguay": (-23.44, -58.44),
    "Peru": (-9.19, -75.02), "Philippines": (12.88, 121.77),
    "Poland": (51.92, 19.15), "Portugal": (39.40, -8.22),
    "Qatar": (25.35, 51.18), "Romania": (45.94, 24.97),
    "Russia": (61.52, 105.32), "Rwanda": (-1.94, 29.87),
    "Saudi Arabia": (23.89, 45.08), "Senegal": (14.50, 14.45),
    "Serbia": (44.02, 21.01), "Singapore": (1.35, 103.82),
    "Slovakia": (48.67, 19.70), "Slovenia": (46.15, 14.99),
    "Somalia": (5.15, 46.20), "South Africa": (-30.56, 22.94),
    "South Korea": (35.91, 127.77), "Spain": (40.46, -3.75),
    "Sri Lanka": (7.87, 80.77), "Sudan": (12.86, 30.22),
    "Sweden": (60.13, 18.64), "Switzerland": (46.82, 8.23),
    "Syria": (34.80, 38.99), "Taiwan": (23.70, 120.96),
    "Tajikistan": (38.86, 71.28), "Tanzania": (-6.37, 34.89),
    "Thailand": (15.87, 100.99), "Tunisia": (33.89, 9.54),
    "Turkey": (38.96, 35.24), "Turkmenistan": (38.97, 59.56),
    "Uganda": (1.37, 32.29), "Ukraine": (48.38, 31.17),
    "United Arab Emirates": (23.42, 53.85),
    "United Kingdom": (55.38, -3.44),
    "United States": (37.09, -95.71),
    "Uruguay": (-32.52, -55.77), "Uzbekistan": (41.38, 64.59),
    "Venezuela": (6.42, -66.59), "Vietnam": (14.06, 108.28),
    "Yemen": (15.55, 48.52), "Zambia": (-13.13, 27.85),
    "Zimbabwe": (-19.02, 29.15),
}

# ── Themes — IRFlow / Unit 42-inspired ───────────────────────────────────────
APP_VERSION = "1.0"

MONO = "Courier New"


def _secure_delete(path) -> bool:
    """
    Overwrite a file with zeros before deletion to reduce forensic recoverability.
    Not a guarantee against forensic recovery on SSDs (wear-levelling),
    but meaningfully raises the bar on HDDs and is best-practice for PII files.
    Falls back to a plain unlink if overwrite fails (e.g. permissions).
    """
    from pathlib import Path as _P
    p = _P(path)
    try:
        size = p.stat().st_size
        if size > 0:
            with open(p, "r+b") as fh:
                # One pass of zeros — sufficient for most compliance requirements
                fh.write(b"\x00" * size)
                fh.flush()
    except Exception:
        pass  # overwrite failed — still attempt deletion
    try:
        p.unlink(missing_ok=True)
        return True
    except Exception:
        return False


THEME: Dict[str, Dict[str, str]] = {
    "dark": {
        # Core surfaces
        "bg":                "#0A0C0F",   # near-black main bg
        "sidebar":           "#0D1014",   # left rail
        "panel":             "#0F1217",   # toolbar / header panels
        "card":              "#141820",   # card / row bg
        "card2":             "#0F1520",   # alternate row
        "border":            "#1E2535",   # subtle border
        "border_lt":         "#2A3548",   # lighter border / dividers
        # Accent palette
        "accent":            "#3B82F6",   # electric blue
        "accent2":           "#EF4444",   # alert red
        "accent3":           "#10B981",   # success green
        "accent4":           "#F59E0B",   # amber warning
        # Text
        "text":              "#E2E8F0",
        "text_dim":          "#64748B",
        "text_bright":       "#F8FAFC",
        "text_muted":        "#334155",
        # Buttons
        "btn_primary":       "#3B82F6",
        "btn_primary_hover": "#60A5FA",
        "btn_secondary":     "#141820",
        "btn_danger":        "#450A0A",
        "btn_danger_hover":  "#7F1D1D",
        # Status
        "status_ok":         "#10B981",
        "status_warn":       "#F59E0B",
        "status_err":        "#EF4444",
        # Map markers
        "marker_outer":      "#EF4444",
        "marker_inner":      "#FCA5A5",
        "marker_text":       "#FFFFFF",
        # IOC
        "ioc_found":         "#10B981",
        "ioc_miss":          "#EF4444",
    },
    "light": {
        "bg":                "#F1F5F9",
        "sidebar":           "#FFFFFF",
        "panel":             "#F8FAFC",
        "card":              "#FFFFFF",
        "card2":             "#F1F5F9",
        "border":            "#CBD5E1",
        "border_lt":         "#E2E8F0",
        "accent":            "#2563EB",
        "accent2":           "#DC2626",
        "accent3":           "#059669",
        "accent4":           "#D97706",
        "text":              "#0F172A",
        "text_dim":          "#475569",
        "text_bright":       "#000000",
        "text_muted":        "#94A3B8",
        "btn_primary":       "#2563EB",
        "btn_primary_hover": "#3B82F6",
        "btn_secondary":     "#F1F5F9",
        "btn_danger":        "#FEF2F2",
        "btn_danger_hover":  "#FECACA",
        "status_ok":         "#059669",
        "status_warn":       "#D97706",
        "status_err":        "#DC2626",
        "marker_outer":      "#DC2626",
        "marker_inner":      "#FCA5A5",
        "marker_text":       "#FFFFFF",
        "ioc_found":         "#059669",
        "ioc_miss":          "#DC2626",
    },
}

# ── Country name → ISO 3166-1 alpha-2 mapping (for flag emoji) ────────────────
# Names match MaxMind GeoLite2 output exactly.
_COUNTRY_ISO2: Dict[str, str] = {
    "Afghanistan": "af", "Albania": "al", "Algeria": "dz", "Andorra": "ad",
    "Angola": "ao", "Anguilla": "ai", "Antarctica": "aq", "Argentina": "ar",
    "Armenia": "am", "Aruba": "aw", "Australia": "au", "Austria": "at",
    "Azerbaijan": "az", "Bahamas": "bs", "Bahrain": "bh", "Bangladesh": "bd",
    "Barbados": "bb", "Belarus": "by", "Belgium": "be", "Belize": "bz",
    "Benin": "bj", "Bermuda": "bm", "Bhutan": "bt", "Bolivia": "bo",
    "Bosnia and Herzegovina": "ba", "Botswana": "bw", "Brazil": "br",
    "Brunei": "bn", "Bulgaria": "bg", "Burkina Faso": "bf", "Burundi": "bi",
    "Cambodia": "kh", "Cameroon": "cm", "Canada": "ca", "Chile": "cl",
    "China": "cn", "Colombia": "co", "Congo": "cd", "Costa Rica": "cr",
    "Croatia": "hr", "Cuba": "cu", "Cyprus": "cy", "Czech Republic": "cz",
    "Czechia": "cz", "Denmark": "dk", "Dominican Republic": "do",
    "Ecuador": "ec", "Egypt": "eg", "El Salvador": "sv", "Estonia": "ee",
    "Ethiopia": "et", "Fiji": "fj", "Finland": "fi", "France": "fr",
    "Gabon": "ga", "Georgia": "ge", "Germany": "de", "Ghana": "gh",
    "Greece": "gr", "Greenland": "gl", "Guatemala": "gt", "Guinea": "gn",
    "Haiti": "ht", "Honduras": "hn", "Hong Kong": "hk", "Hungary": "hu",
    "Iceland": "is", "India": "in", "Indonesia": "id", "Iran": "ir",
    "Iraq": "iq", "Ireland": "ie", "Israel": "il", "Italy": "it",
    "Jamaica": "jm", "Japan": "jp", "Jordan": "jo", "Kazakhstan": "kz",
    "Kenya": "ke", "Kuwait": "kw", "Kyrgyzstan": "kg", "Laos": "la",
    "Latvia": "lv", "Lebanon": "lb", "Libya": "ly", "Liechtenstein": "li",
    "Lithuania": "lt", "Luxembourg": "lu", "Malaysia": "my", "Maldives": "mv",
    "Mali": "ml", "Malta": "mt", "Mexico": "mx", "Moldova": "md",
    "Monaco": "mc", "Mongolia": "mn", "Montenegro": "me", "Morocco": "ma",
    "Mozambique": "mz", "Myanmar": "mm", "Namibia": "na", "Nepal": "np",
    "Netherlands": "nl", "New Zealand": "nz", "Nicaragua": "ni",
    "Nigeria": "ng", "North Korea": "kp", "North Macedonia": "mk",
    "Norway": "no", "Oman": "om", "Pakistan": "pk", "Panama": "pa",
    "Papua New Guinea": "pg", "Paraguay": "py", "Peru": "pe",
    "Philippines": "ph", "Poland": "pl", "Portugal": "pt", "Qatar": "qa",
    "Romania": "ro", "Russia": "ru", "Rwanda": "rw", "Saudi Arabia": "sa",
    "Senegal": "sn", "Serbia": "rs", "Singapore": "sg", "Slovakia": "sk",
    "Slovenia": "si", "Somalia": "so", "South Africa": "za",
    "South Korea": "kr", "Spain": "es", "Sri Lanka": "lk", "Sudan": "sd",
    "Sweden": "se", "Switzerland": "ch", "Syria": "sy", "Taiwan": "tw",
    "Tajikistan": "tj", "Tanzania": "tz", "Thailand": "th", "Togo": "tg",
    "Trinidad and Tobago": "tt", "Tunisia": "tn", "Turkey": "tr",
    "Turkmenistan": "tm", "Uganda": "ug", "Ukraine": "ua",
    "United Arab Emirates": "ae", "United Kingdom": "gb",
    "United States": "us", "Uruguay": "uy", "Uzbekistan": "uz",
    "Venezuela": "ve", "Vietnam": "vn", "Yemen": "ye", "Zambia": "zm",
    "Zimbabwe": "zw",
    # GeoLite2 alternate names / ISO formal names
    "The Netherlands": "nl",
    "Russian Federation": "ru",
    "United States of America": "us",
    "Republic of Korea": "kr",
    "Korea, Republic of": "kr",
    "Korea, Democratic People's Republic of": "kp",
    "Iran, Islamic Republic of": "ir",
    "Syrian Arab Republic": "sy",
    "Taiwan, Province of China": "tw",
    "Bolivia, Plurinational State of": "bo",
    "Venezuela, Bolivarian Republic of": "ve",
    "Tanzania, United Republic of": "tz",
    "Lao People's Democratic Republic": "la",
    "Brunei Darussalam": "bn",
    "Moldova, Republic of": "md",
    "Viet Nam": "vn",
    "Democratic Republic of the Congo": "cd",
    "Congo, The Democratic Republic of the": "cd",
    "Republic of the Congo": "cg",
    "North Macedonia": "mk",
    "Macedonia, The Former Yugoslav Republic of": "mk",
    "Palestine, State of": "ps",
    "State of Palestine": "ps",
    "Palestinian Territory": "ps",
    "Eswatini": "sz",
    "Swaziland": "sz",
    "Myanmar": "mm",
    "Burma": "mm",
    "Cabo Verde": "cv",
    "Cape Verde": "cv",
    "Timor-Leste": "tl",
    "East Timor": "tl",
    "Cote d'Ivoire": "ci",
    "Ivory Coast": "ci",
    "Reunion": "re",
    "R\u00e9union": "re",
}


# Cache of loaded flag CTkImages keyed by ISO2 code
_FLAG_IMAGE_CACHE: dict = {}
_FLAGS_DIR = Path(__file__).parent / "flags"


def _flag_image(country_name: str, size: tuple = (20, 15)):
    """Return a CTkImage for the country flag, or None if unavailable.
    Images are cached after first load. Requires the flags/ directory
    (pre-rendered PNGs bundled with the app).
    """
    iso2 = _COUNTRY_ISO2.get(country_name, "")
    if not iso2:
        return None
    cache_key = (iso2, size)
    if cache_key in _FLAG_IMAGE_CACHE:
        return _FLAG_IMAGE_CACHE[cache_key]
    png_path = _FLAGS_DIR / f"{iso2}.png"
    if not png_path.exists():
        _FLAG_IMAGE_CACHE[cache_key] = None
        return None
    try:
        from PIL import Image as _PilImage
        pil_img = _PilImage.open(png_path).resize(size, _PilImage.LANCZOS)
        img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=size)
        _FLAG_IMAGE_CACHE[cache_key] = img
        return img
    except Exception:
        _FLAG_IMAGE_CACHE[cache_key] = None
        return None


# Pre-built centroid DataFrame — used by _refresh_map on every filter change.
# Building it once at import time avoids recreating it on every map refresh.
_CENTROID_DF: "pl.DataFrame | None" = None

def _get_centroid_df():
    """Return the cached centroid DataFrame, building it on first call."""
    global _CENTROID_DF
    if _CENTROID_DF is None and POLARS_AVAILABLE:
        _CENTROID_DF = pl.DataFrame([
            {"Country": k, "_clat": float(v[0]), "_clon": float(v[1])}
            for k, v in COUNTRY_COORDS.items()
        ])
    return _CENTROID_DF


TILE_SERVERS: Dict[str, Tuple[str, int]] = {
    "OpenStreetMap":    ("https://a.tile.openstreetmap.org/{z}/{x}/{y}.png", 19),
    "Google Maps":      ("https://mt0.google.com/vt/lyrs=m&hl=en&x={x}&y={y}&z={z}&s=Ga", 22),
    "Google Satellite": ("https://mt0.google.com/vt/lyrs=s&hl=en&x={x}&y={y}&z={z}&s=Ga", 22),
    "CartoDB Dark":     ("https://cartodb-basemaps-a.global.ssl.fastly.net/dark_all/{z}/{x}/{y}.png", 19),
    "Self-hosted (localhost)": ("http://localhost:8080/{z}/{x}/{y}.png", 14),
}



# ══════════════════════════════════════════════════════════════════════════════
# Thread-safe logger
# ══════════════════════════════════════════════════════════════════════════════
class QueueLogger:
    def __init__(self, q: queue.Queue):
        self.q = q

    def info(self, msg):    self.q.put(("log", "INFO",  str(msg)))
    def warning(self, msg): self.q.put(("log", "WARN",  str(msg)))
    def error(self, msg):   self.q.put(("log", "ERROR", str(msg)))
    def debug(self, msg):   self.q.put(("log", "DEBUG", str(msg)))


# ══════════════════════════════════════════════════════════════════════════════
# Enrichment worker
# ══════════════════════════════════════════════════════════════════════════════
def run_enrichment(
    input_path: str,
    city_db_path: str,
    asn_db_path: str,
    skip_geoip: bool,
    output_dir: str,
    output_fmt: str,           # "csv" | "xlsx"
    split_ops: bool,
    logger: QueueLogger,
    result_q: queue.Queue,
) -> None:
    try:
        if not POLARS_AVAILABLE:
            result_q.put(("error", "polars not installed — run: pip install polars"))
            return

        logger.info(f"Loading: {Path(input_path).name}")
        ext = Path(input_path).suffix.lower()
        if ext == ".csv":
            df = pl.read_csv(input_path)
        elif ext in (".xlsx", ".xls"):
            df = pl.read_excel(input_path)
        else:
            result_q.put(("error", f"Unsupported format: {ext}"))
            return

        logger.info(f"Loaded {len(df):,} rows, {len(df.columns)} columns")
        if "AuditData" not in df.columns:
            result_q.put(("error", "'AuditData' column not found — not a valid M365 UAL export"))
            return

        # ── AppId lookup ──────────────────────────────────────────────────────
        appid_map: Dict[str, str] = {}
        appid_path = Path(__file__).parent / "appid_lookup.csv"
        if appid_path.exists():
            try:
                adf = pl.read_csv(appid_path)
                appid_map = dict(zip(adf["AppId"].to_list(), adf["AppDisplayName"].to_list()))
                logger.info(f"Loaded {len(appid_map):,} AppId mappings")
            except Exception as e:
                logger.warning(f"AppId lookup failed: {e}")

        # ── Parse AuditData JSON — parallel with ThreadPoolExecutor ──────────
        logger.info("Parsing AuditData JSON…")
        from concurrent.futures import ThreadPoolExecutor, as_completed

        def _san_ip(raw: str) -> Optional[str]:
            if not raw:
                return None
            raw = raw.strip()
            if raw.count(':') == 1:
                return raw.split(':')[0]
            if '[' in raw:
                m = re.match(r'\[([^\]]+)\]', raw)
                return m.group(1) if m else raw
            return raw or None

        def parse_row(s: str) -> Dict[str, Any]:
            out: Dict[str, Any] = {
                "ClientIP": None, "AppId": None, "AppDisplayName": None,
                "SessionId": None, "UserAgent": None, "UniqueTokenId": None,
            }
            if not s or not s.strip():
                return out
            try:
                d = json.loads(s)
                out["ClientIP"] = _san_ip(d.get("ClientIPAddress") or d.get("ClientIP") or "")
                out["AppId"] = d.get("AppId") or d.get("ClientAppId") or d.get("ApplicationId")
                ctx: Dict = d.get("AppAccessContext") or {}
                out["AppDisplayName"] = (
                    ctx.get("ClientAppName") or d.get("ClientAppName")
                    or d.get("ApplicationDisplayName"))
                if not out["AppDisplayName"] and out["AppId"]:
                    out["AppDisplayName"] = appid_map.get(out["AppId"])
                out["SessionId"] = d.get("SessionId") or ctx.get("AADSessionId")
                if not out["SessionId"]:
                    for p in (d.get("DeviceProperties") or []):
                        if isinstance(p, dict) and p.get("Name") == "SessionId":
                            out["SessionId"] = p.get("Value")
                            break
                out["UserAgent"] = d.get("UserAgent") or d.get("ActorInfoString")
                if not out["UserAgent"]:
                    for p in (d.get("ExtendedProperties") or []):
                        if isinstance(p, dict) and p.get("Name") == "UserAgent":
                            out["UserAgent"] = p.get("Value")
                            break
                out["UniqueTokenId"] = d.get("UniqueTokenId") or ctx.get("UniqueTokenId")
            except Exception:
                pass
            return out

        # Extract raw strings list once — avoid repeated Series access
        audit_strings: List[str] = df["AuditData"].to_list()
        n_rows = len(audit_strings)

        # Use ThreadPoolExecutor: json.loads releases the GIL, giving real parallelism
        workers = min(8, max(2, os.cpu_count() or 4))
        chunk   = max(1, n_rows // workers)
        parsed: List[Dict] = [{}] * n_rows

        def _parse_chunk(start: int, end: int) -> Tuple[int, List[Dict]]:
            return start, [parse_row(s or "") for s in audit_strings[start:end]]

        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(_parse_chunk, i, min(i + chunk, n_rows)): i
                for i in range(0, n_rows, chunk)
            }
            for future in as_completed(futures):
                start, results = future.result()
                for j, r in enumerate(results):
                    parsed[start + j] = r

        df = pl.concat([df, pl.DataFrame(parsed)], how="horizontal")

        # ── Format CreationDate ───────────────────────────────────────────────
        if "CreationDate" in df.columns:
            try:
                df = df.with_columns([
                    pl.col("CreationDate").str.strip_chars()
                    .str.strptime(pl.Datetime, "%Y-%m-%dT%H:%M:%S%.fZ", strict=False)
                    .dt.strftime("%Y-%m-%d %H:%M:%S")
                    .alias("CreationDate")
                ])
            except Exception:
                pass

        # ── GeoIP enrichment ──────────────────────────────────────────────────
        geo_cache: Dict[str, Dict] = {}

        if not skip_geoip and city_db_path and asn_db_path:
            if GEOIP2_AVAILABLE:
                logger.info("Performing GeoIP lookups…")
                unique_ips: List[str] = [
                    ip for ip in df["ClientIP"].drop_nulls().unique().to_list() if ip
                ]
                logger.info(f"{len(unique_ips):,} unique IPs to resolve")
                try:
                    with geoip2.database.Reader(city_db_path) as cr, \
                         geoip2.database.Reader(asn_db_path) as ar:
                        for ip in unique_ips:
                            rec: Dict[str, Any] = {
                                "Country": None, "City": None,
                                "ASN": None, "Organization": None,
                                "Latitude": None, "Longitude": None,
                            }
                            try:
                                c = cr.city(ip)
                                rec["Country"]   = c.country.name
                                rec["City"]      = c.city.name
                                rec["Latitude"]  = c.location.latitude
                                rec["Longitude"] = c.location.longitude
                            except Exception:
                                pass
                            try:
                                a = ar.asn(ip)
                                rec["ASN"]          = f"AS{a.autonomous_system_number}"
                                rec["Organization"] = a.autonomous_system_organization
                            except Exception:
                                pass
                            geo_cache[ip] = rec
                    logger.info(f"GeoIP complete — {len(geo_cache):,} IPs resolved")
                except Exception as e:
                    logger.warning(f"GeoIP error: {e}")
            else:
                logger.warning("geoip2 not installed — run: pip install geoip2")
        elif not skip_geoip and not (city_db_path and asn_db_path):
            logger.warning("City or ASN database not loaded — skipping GeoIP")
        elif skip_geoip:
            logger.info("GeoIP skipped by user")

        # Attach geo columns
        cols_geo: Dict[str, List] = defaultdict(list)
        for ip in df["ClientIP"].to_list():
            rec = geo_cache.get(ip or "", {})
            cols_geo["Country"].append(rec.get("Country"))
            cols_geo["City"].append(rec.get("City"))
            cols_geo["ASN"].append(rec.get("ASN"))
            cols_geo["Organization"].append(rec.get("Organization"))
            cols_geo["Latitude"].append(rec.get("Latitude"))
            cols_geo["Longitude"].append(rec.get("Longitude"))

        df = df.with_columns([
            pl.Series("Country",      cols_geo["Country"]),
            pl.Series("City",         cols_geo["City"]),
            pl.Series("ASN",          cols_geo["ASN"]),
            pl.Series("Organization", cols_geo["Organization"]),
            pl.Series("Latitude",     cols_geo["Latitude"]),
            pl.Series("Longitude",    cols_geo["Longitude"]),
        ])

        # ── Write main enriched output ────────────────────────────────────────
        out_dir = Path(output_dir) if output_dir else Path(input_path).parent
        out_dir.mkdir(parents=True, exist_ok=True)
        stem = Path(input_path).stem
        main_out = out_dir / f"{stem}_enriched.{output_fmt}"

        logger.info(f"Writing enriched file → {main_out.name}")
        if output_fmt == "csv":
            df.write_csv(str(main_out))
        else:
            df.write_excel(str(main_out))
        logger.info(f"Saved: {main_out}")

        # ── Operation splitting ───────────────────────────────────────────────
        split_results: Dict[str, int] = {}
        if split_ops and YAML_AVAILABLE and "Operation" in df.columns:
            cfg_path = Path(__file__).parent / "operations_config.yaml"
            if cfg_path.exists():
                logger.info("Splitting by operation…")
                try:
                    with open(cfg_path, "r", encoding="utf-8") as f:
                        cfg = yaml.safe_load(f)

                    ops_dir = out_dir / "Operations"
                    ops_dir.mkdir(exist_ok=True)

                    STANDARD = [
                        "CreationDate", "Operation", "UserId", "ClientIP",
                        "Country", "City", "ASN", "Organization",
                        "AppId", "AppDisplayName", "SessionId",
                        "UserAgent", "UniqueTokenId",
                    ]
                    std_cols = [c for c in STANDARD if c in df.columns]
                    operations = cfg.get("operations", {})

                    for op_name, op_cfg in operations.items():
                        if not op_cfg.get("enabled", False):
                            continue
                        op_df = df.filter(pl.col("Operation") == op_name)
                        if len(op_df) == 0:
                            continue

                        # Extract operation-specific fields from AuditData
                        field_cfgs = op_cfg.get("fields", [])
                        extra_rows: List[Dict] = []
                        for row in op_df.iter_rows(named=True):
                            s = row.get("AuditData", "") or ""
                            extras: Dict[str, Any] = {}
                            if s.strip():
                                try:
                                    d = json.loads(s)
                                    for fc in field_cfgs:
                                        ftype  = fc.get("type")
                                        oname  = fc.get("output")
                                        if not oname or ftype == "array_explosion":
                                            continue
                                        if ftype == "flat":
                                            extras[oname] = d.get(fc["source"], "")
                                        elif ftype == "nested":
                                            parts = fc["source"].split(".")
                                            cur = d
                                            for p in parts:
                                                cur = cur.get(p, {}) if isinstance(cur, dict) else {}
                                            extras[oname] = cur if not isinstance(cur, dict) else ""
                                        elif ftype == "name_value_array":
                                            arr = d.get(fc["source"], [])
                                            extras[oname] = next(
                                                (x.get("Value", "") for x in arr
                                                 if isinstance(x, dict) and x.get("Name") == fc.get("name")),
                                                ""
                                            )
                                except Exception:
                                    pass
                            extra_rows.append(extras)

                        result_df = op_df.select(std_cols)
                        if extra_rows and any(extra_rows):
                            try:
                                extra_df = pl.DataFrame(extra_rows, infer_schema_length=None)
                                result_df = pl.concat([result_df, extra_df], how="horizontal")
                            except Exception:
                                pass

                        op_file = ops_dir / f"{stem}_{op_name}.{output_fmt}"
                        if output_fmt == "csv":
                            result_df.write_csv(str(op_file))
                        else:
                            result_df.write_excel(str(op_file))

                        split_results[op_name] = len(result_df)
                        logger.info(f"  {op_name}: {len(result_df):,} rows → {op_file.name}")

                    logger.info(f"Operation split complete — {len(split_results)} file(s) written to Operations/")
                except Exception as e:
                    logger.warning(f"Operation splitting error: {e}")
            else:
                logger.warning("operations_config.yaml not found — splitting skipped")

        logger.info(f"All done — {len(df):,} rows enriched")
        result_q.put(("done", df, str(main_out), split_results))

    except Exception as e:
        import traceback
        result_q.put(("error", f"{e}\n{traceback.format_exc()}"))


# ══════════════════════════════════════════════════════════════════════════════
# IOC filter worker
# ══════════════════════════════════════════════════════════════════════════════
def run_ioc_filter(
    df,                        # polars DataFrame (already enriched)
    iocs: Dict[str, List[str]],  # {"ClientIP": [...], "SessionId": [...], ...}
    output_dir: str,
    output_fmt: str,
    input_stem: str,
    logger: QueueLogger,
    result_q: queue.Queue,
) -> None:
    try:
        if not POLARS_AVAILABLE:
            result_q.put(("ioc_error", "polars not installed"))
            return

        conditions = []
        summary: Dict[str, Any] = {
            "searched": 0,
            "found": {},
            "not_found": [],
            "total_rows": 0,
        }

        for col, values in iocs.items():
            if col not in df.columns or not values:
                continue
            for v in values:
                v = v.strip()
                if not v:
                    continue
                summary["searched"] += 1
                count = len(df.filter(pl.col(col) == v))
                if count > 0:
                    summary["found"][f"{col}={v}"] = count
                    conditions.append(pl.col(col) == v)
                else:
                    summary["not_found"].append(f"{col}={v}")

        if not conditions:
            result_q.put(("ioc_done", None, summary, ""))
            return

        combined = conditions[0]
        for c in conditions[1:]:
            combined = combined | c

        fdf = df.filter(combined)
        summary["total_rows"] = len(fdf)
        logger.info(f"IOC filter: {summary['total_rows']:,} matching rows")

        out_path = ""
        if summary["total_rows"] > 0 and output_dir:
            out_dir = Path(output_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            out_path = str(out_dir / f"{input_stem}_ioc_filtered.{output_fmt}")
            if output_fmt == "csv":
                fdf.write_csv(out_path)
            else:
                fdf.write_excel(out_path)
            logger.info(f"IOC filtered file saved → {Path(out_path).name}")

        result_q.put(("ioc_done", fdf, summary, out_path))

    except Exception as e:
        import traceback
        result_q.put(("ioc_error", f"{e}\n{traceback.format_exc()}"))


# ══════════════════════════════════════════════════════════════════════════════
# Main Application
# ══════════════════════════════════════════════════════════════════════════════
class ThreadHunterApp(ctk.CTkToplevel):

    def __init__(self, case=None):
        super().__init__()
        self._case = case  # core.case.Case object, or None (standalone mode)

        title = f"ThreadHunter — BEC Forensics  v{APP_VERSION}"
        if case is not None:
            title = f"ThreadHunter  ·  {case.name}"
        self.title(title)
        self.geometry("1480x900")
        self.minsize(1150, 720)

        # ── State ─────────────────────────────────────────────────────────────
        self._mode          = "dark"
        self._tc            = THEME["dark"]
        self._df            = None          # enriched DataFrame
        self._fdf           = None          # filtered view
        self._ioc_df        = None          # IOC-filtered DataFrame
        self._log_q         = queue.Queue()
        self._result_q      = queue.Queue()
        self._busy          = False
        self._city_db_path  = ""
        self._asn_db_path   = ""
        self._input_path    = ""
        self._output_dir    = case.path.parent if case else ""
        self._operations: List[str] = ["All Operations"]
        self._markers: List[Any]    = []
        self._sort_state: Dict[str, bool] = {}
        # Performance / caching state
        self._table_cols_cache: List[str] = []
        self._search_after_id             = None
        self._summary_cache_key           = None
        self._imp_travel_active: bool             = False
        self._imp_travel_cache: dict              = {}   # cached result keyed by id(df)
        self._op_updating: bool                   = False  # guard: suppress listbox events during programmatic update
        self._map_dirty:   bool                   = False  # map needs refresh on next tab switch
        # Module views (set during _build_ui)

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")

        self._build_ui()
        self._check_deps()
        self._poll_queues()

        # Pre-fill output dir label if we have a case
        if case and hasattr(self, "_out_lbl"):
            self._out_lbl.configure(
                text=f"✔  {case.path.parent}",
                text_color=self._tc["status_ok"])

    # ─────────────────────────────────────────────────────────────────────────
    # Dependency check on startup
    # ─────────────────────────────────────────────────────────────────────────
    def _check_deps(self):
        missing = []
        if not POLARS_AVAILABLE:   missing.append("polars")
        if not GEOIP2_AVAILABLE:   missing.append("geoip2")
        if not YAML_AVAILABLE:     missing.append("pyyaml")
        if not MAPVIEW_AVAILABLE:  missing.append("tkintermapview (check folder)")
        if missing:
            self._log(f"⚠ Missing dependencies: {', '.join(missing)}")
            self._log("  Run: pip install " + " ".join(m for m in missing if m != "tkintermapview (check folder)"))
        else:
            self._log("✔ All dependencies OK")

    # ─────────────────────────────────────────────────────────────────────────
    # Sidebar helpers
    # ─────────────────────────────────────────────────────────────────────────
    def _div(self, row: int, parent=None):
        p = parent or self.sidebar
        ctk.CTkFrame(p, fg_color=self._tc["border"], height=1).grid(
            row=row, column=0, padx=10, pady=3, sticky="ew")

    def _sb_section(self, text: str, row: int):
        ctk.CTkLabel(self.sidebar, text=text,
                     font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=self._tc["text_dim"]).grid(
            row=row, column=0, padx=18, pady=(8, 2), sticky="w")

    def _sb_button(self, text: str, cmd, row: int, color=None, hover=None, text_color=None):
        tc = self._tc
        ctk.CTkButton(
            self.sidebar, text=text,
            fg_color=color or tc["btn_secondary"],
            hover_color=hover or tc["border"],
            text_color=text_color or tc["text"],
            border_color=tc["border"], border_width=1,
            height=34, font=ctk.CTkFont(size=12),
            command=cmd,
        ).grid(row=row, column=0, padx=12, pady=(0, 4), sticky="ew")

    # ─────────────────────────────────────────────────────────────────────────
    # Full UI build
    # ─────────────────────────────────────────────────────────────────────────
    def _build_ui(self):
        tc = self._tc
        self.configure(fg_color=tc["bg"])
        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=0)  # footer — fixed height
        self.grid_columnconfigure(1, weight=1)
        # Init separator style before any widget build uses it
        _s = ttk.Style()
        _s.configure("TH.TSeparator", background=tc["border_lt"])
        self._build_sidebar()
        self._build_main()
        self._build_footer()

    def _build_footer(self):
        """Full-width status footer spanning sidebar + main."""
        tc   = self._tc
        mono = MONO

        bar = ctk.CTkFrame(self, fg_color="#141820", corner_radius=0, height=26)
        bar.grid(row=1, column=0, columnspan=2, sticky="ew")
        bar.grid_propagate(False)
        bar.grid_columnconfigure(0, weight=1)

        inner = ctk.CTkFrame(bar, fg_color="transparent")
        inner.place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkLabel(inner,
                     text="ThreadHunter  —  Created by Yuvi Kapoor  —  ",
                     font=ctk.CTkFont(family=mono, size=10),
                     text_color=tc["text_muted"]).pack(side="left")

        lnk = ctk.CTkLabel(inner,
                            text="Yuvi Kapoor | LinkedIn",
                            font=ctk.CTkFont(family=mono, size=10),
                            text_color=tc["accent"],
                            cursor="hand2")
        lnk.pack(side="left")
        lnk.bind("<Button-1>", lambda e: __import__("webbrowser").open(
            "https://www.linkedin.com/in/yuvi-kapoor/"))
        lnk.bind("<Enter>", lambda e: lnk.configure(text_color=tc["btn_primary_hover"]))
        lnk.bind("<Leave>", lambda e: lnk.configure(text_color=tc["accent"]))

    # ── Sidebar — IRFlow-style narrow config rail ─────────────────────────────
    def _build_sidebar(self):
        tc   = self._tc
        mono = MONO

        # Outer sidebar frame — fixed width, holds brand + scroll area + footer
        self.sidebar = ctk.CTkFrame(self, fg_color=tc["sidebar"],
                                    corner_radius=0, width=270)
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_propagate(False)
        self.sidebar.grid_columnconfigure(0, weight=1)

        # ── Brand header — pinned, never scrolls ──────────────────────────────
        brand_frame = ctk.CTkFrame(self.sidebar, fg_color=tc["sidebar"],
                                   corner_radius=0)
        brand_frame.grid(row=0, column=0, sticky="ew")
        brand_frame.grid_columnconfigure(0, weight=1)

        brand_inner = ctk.CTkFrame(brand_frame, fg_color="transparent")
        brand_inner.pack(fill="x", padx=18, pady=(16, 14))
        ctk.CTkLabel(brand_inner, text="◎",
                     font=ctk.CTkFont(size=32), text_color=tc["accent"],
                     anchor="w").pack(fill="x")
        ctk.CTkLabel(brand_inner, text="THREADHUNTER",
                     font=ctk.CTkFont(family=mono, size=15, weight="bold"),
                     text_color=tc["text_bright"], anchor="w").pack(fill="x")
        ctk.CTkLabel(brand_inner, text="BEC FORENSICS",
                     font=ctk.CTkFont(family=mono, size=11),
                     text_color=tc["accent"], anchor="w").pack(fill="x")

        # Separator below brand
        ttk.Separator(self.sidebar, orient="horizontal",
                      style="TH.TSeparator").grid(row=1, column=0, sticky="ew")

        # ── Scrollable content area ───────────────────────────────────────────
        self.sidebar.grid_rowconfigure(2, weight=1)
        scroll = ctk.CTkScrollableFrame(
            self.sidebar,
            fg_color=tc["sidebar"],
            scrollbar_button_color=tc["border_lt"],
            scrollbar_button_hover_color=tc["accent"],
            corner_radius=0,
        )
        scroll.grid(row=2, column=0, sticky="nsew")
        scroll.grid_columnconfigure(0, weight=1)

        # Separator above footer
        ttk.Separator(self.sidebar, orient="horizontal",
                      style="TH.TSeparator").grid(row=3, column=0, sticky="ew")

        # ── Bottom footer — pinned outside scroll, always visible ─────────────
        footer = ctk.CTkFrame(self.sidebar, fg_color=tc["panel"],
                              corner_radius=0)
        footer.grid(row=4, column=0, sticky="ew")
        footer.grid_columnconfigure(0, weight=1)
        footer.grid_columnconfigure(1, weight=1)

        ctk.CTkButton(
            footer, text="DARK",
            fg_color=tc["accent"] if self._mode == "dark" else tc["card"],
            text_color="#FFFFFF" if self._mode == "dark" else tc["text_dim"],
            hover_color=tc["btn_primary_hover"],
            height=28, corner_radius=3,
            font=ctk.CTkFont(family=mono, size=10, weight="bold"),
            command=lambda: self._set_theme("dark"),
        ).grid(row=0, column=0, padx=(12, 3), pady=(8, 4), sticky="ew")
        ctk.CTkButton(
            footer, text="LIGHT",
            fg_color=tc["accent"] if self._mode == "light" else tc["card"],
            text_color="#FFFFFF" if self._mode == "light" else tc["text_dim"],
            hover_color=tc["btn_primary_hover"],
            height=28, corner_radius=3,
            font=ctk.CTkFont(family=mono, size=10, weight="bold"),
            command=lambda: self._set_theme("light"),
        ).grid(row=0, column=1, padx=(3, 12), pady=(8, 4), sticky="ew")

        ctk.CTkButton(
            footer, text="← CLOSE CASE",
            fg_color="transparent", hover_color=tc["card"],
            text_color=tc["text_dim"], border_width=0,
            height=26, font=ctk.CTkFont(family=mono, size=10),
            command=self._close_case,
        ).grid(row=1, column=0, columnspan=2, padx=12, pady=(0, 10), sticky="ew")

        # ── Helpers — all parented to `scroll` ───────────────────────────────

        def _section_div(text: str):
            """PatternFly-style labeled section divider  ── LABEL ──────────"""
            outer = ctk.CTkFrame(scroll, fg_color="transparent")
            outer.pack(fill="x", padx=14, pady=(14, 5))
            # left stub
            left_line = ctk.CTkFrame(outer, fg_color=tc["border_lt"],
                                     height=1, corner_radius=0, width=10)
            left_line.pack(side="left", padx=(0, 0), pady=0, ipadx=0)
            left_line.pack_propagate(False)
            # label
            ctk.CTkLabel(outer,
                         text=f"  {text}  ",
                         font=ctk.CTkFont(family=mono, size=11, weight="bold"),
                         text_color=tc["text_dim"]).pack(side="left")
            # right fill line — use a Frame that expands
            right_line = ctk.CTkFrame(outer, fg_color=tc["border_lt"],
                                      height=1, corner_radius=0)
            right_line.pack(side="left", fill="x", expand=True, pady=0)

        def _card():
            """Elevated card panel — visually groups section content."""
            c = ctk.CTkFrame(scroll, fg_color=tc["card"],
                             corner_radius=8, border_width=1,
                             border_color=tc["border_lt"])
            c.pack(fill="x", padx=10, pady=(0, 6))
            return c

        def _btn(parent, text, cmd, primary=False):
            ctk.CTkButton(
                parent, text=text,
                fg_color=tc["btn_primary"] if primary else "transparent",
                hover_color=tc["btn_primary_hover"] if primary else tc["border"],
                text_color="#FFFFFF" if primary else tc["text_dim"],
                border_color=tc["border_lt"], border_width=0 if primary else 1,
                height=32, corner_radius=4,
                font=ctk.CTkFont(family=mono, size=11,
                                  weight="bold" if primary else "normal"),
                command=cmd,
            ).pack(fill="x", padx=8, pady=(0, 6))

        # ── INPUT FILE ────────────────────────────────────────────────────────
        _section_div("INPUT FILE")
        c = _card()
        self._ual_lbl = ctk.CTkLabel(
            c, text="No file selected",
            font=ctk.CTkFont(family=mono, size=12),
            text_color=tc["text_dim"], wraplength=220, justify="left", anchor="w")
        self._ual_lbl.pack(fill="x", padx=12, pady=(10, 6))
        _btn(c, "OPEN UAL FILE  ›", self._select_ual)

        # "More info" link for UAL export
        ual_info_row = ctk.CTkFrame(c, fg_color="transparent")
        ual_info_row.pack(fill="x", padx=12, pady=(0, 10))
        ctk.CTkLabel(ual_info_row,
                     text="Need a UAL export?",
                     font=ctk.CTkFont(family=mono, size=11),
                     text_color=tc["text_muted"]).pack(side="left")

        def _open_ual_url():
            import webbrowser
            webbrowser.open(
                "https://learn.microsoft.com/en-us/purview/audit-log-export-records")

        ual_lnk = ctk.CTkLabel(ual_info_row,
                               text="  More info ›",
                               font=ctk.CTkFont(family=mono, size=11, weight="bold"),
                               text_color=tc["accent"], cursor="hand2")
        ual_lnk.pack(side="left")
        ual_lnk.bind("<Button-1>", lambda e: _open_ual_url())
        ual_lnk.bind("<Enter>", lambda e: ual_lnk.configure(text_color=tc["btn_primary_hover"]))
        ual_lnk.bind("<Leave>", lambda e: ual_lnk.configure(text_color=tc["accent"]))

        # ── GEOIP DATABASES ───────────────────────────────────────────────────
        _section_div("GEOIP DATABASES")
        c = _card()

        self._city_lbl = ctk.CTkLabel(
            c, text="City DB: not loaded",
            font=ctk.CTkFont(family=mono, size=12),
            text_color=tc["text_dim"], wraplength=220, anchor="w")
        self._city_lbl.pack(fill="x", padx=12, pady=(10, 4))
        _btn(c, "LOAD CITY DB  ›", self._select_city_db)

        self._asn_lbl = ctk.CTkLabel(
            c, text="ASN DB: not loaded",
            font=ctk.CTkFont(family=mono, size=12),
            text_color=tc["text_dim"], wraplength=220, anchor="w")
        self._asn_lbl.pack(fill="x", padx=12, pady=(4, 4))
        _btn(c, "LOAD ASN DB  ›", self._select_asn_db)

        self._skip_geo = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(
            c, text="Skip GeoIP",
            variable=self._skip_geo,
            text_color=tc["text_dim"],
            font=ctk.CTkFont(family=mono, size=12),
            fg_color=tc["accent"], hover_color=tc["btn_primary_hover"],
            checkmark_color="#FFFFFF", border_color=tc["border_lt"]).pack(
            anchor="w", padx=12, pady=(2, 6))

        # "More info" link row
        info_row = ctk.CTkFrame(c, fg_color="transparent")
        info_row.pack(fill="x", padx=12, pady=(0, 10))
        ctk.CTkLabel(info_row,
                     text="Need the databases?",
                     font=ctk.CTkFont(family=mono, size=11),
                     text_color=tc["text_muted"]).pack(side="left")

        def _open_maxmind_url():
            import webbrowser
            webbrowser.open("https://dev.maxmind.com/geoip/geolite2-free-geolocation-data/")

        lnk = ctk.CTkLabel(info_row,
                            text="  More info ›",
                            font=ctk.CTkFont(family=mono, size=11, weight="bold"),
                            text_color=tc["accent"], cursor="hand2")
        lnk.pack(side="left")
        lnk.bind("<Button-1>", lambda e: _open_maxmind_url())
        lnk.bind("<Enter>", lambda e: lnk.configure(text_color=tc["btn_primary_hover"]))
        lnk.bind("<Leave>", lambda e: lnk.configure(text_color=tc["accent"]))

        # ── OUTPUT ────────────────────────────────────────────────────────────
        _section_div("OUTPUT")
        c = _card()

        self._out_lbl = ctk.CTkLabel(
            c, text="Same folder as input",
            font=ctk.CTkFont(family=mono, size=12),
            text_color=tc["text_dim"], wraplength=220, anchor="w")
        self._out_lbl.pack(fill="x", padx=12, pady=(10, 6))
        _btn(c, "SET OUTPUT FOLDER  ›", self._select_output_dir)

        fmt_row = ctk.CTkFrame(c, fg_color="transparent")
        fmt_row.pack(fill="x", padx=12, pady=(2, 6))
        ctk.CTkLabel(fmt_row, text="FORMAT",
                     font=ctk.CTkFont(family=mono, size=11, weight="bold"),
                     text_color=tc["text_dim"]).pack(side="left", padx=(0, 10))
        self._fmt_var = ctk.StringVar(value="CSV")
        ctk.CTkOptionMenu(
            fmt_row, variable=self._fmt_var, values=["CSV", "Excel"],
            fg_color=tc["sidebar"], button_color=tc["accent"],
            button_hover_color=tc["btn_primary_hover"],
            text_color=tc["text"],
            font=ctk.CTkFont(family=mono, size=11),
            width=100, dynamic_resizing=False).pack(side="left")

        self._split_ops = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(
            c, text="Split by Operation",
            variable=self._split_ops,
            text_color=tc["text_dim"],
            font=ctk.CTkFont(family=mono, size=12),
            fg_color=tc["accent"], hover_color=tc["btn_primary_hover"],
            checkmark_color="#FFFFFF", border_color=tc["border_lt"]).pack(
            anchor="w", padx=12, pady=(0, 10))

        # ── ACTIONS ───────────────────────────────────────────────────────────
        _section_div("ACTIONS")
        c = _card()

        self._run_btn = ctk.CTkButton(
            c, text="▶  RUN ENRICHMENT",
            fg_color=tc["btn_primary"], hover_color=tc["btn_primary_hover"],
            text_color="#FFFFFF", height=38, corner_radius=4,
            font=ctk.CTkFont(family=mono, size=12, weight="bold"),
            command=self._start_enrichment)
        self._run_btn.pack(fill="x", padx=8, pady=(10, 6))

        self._export_btn = ctk.CTkButton(
            c, text="EXPORT VIEW  ›",
            fg_color="transparent", hover_color=tc["border"],
            text_color=tc["text_dim"], border_color=tc["border_lt"], border_width=1,
            height=30, corner_radius=4,
            font=ctk.CTkFont(family=mono, size=11),
            command=self._export_results, state="disabled")
        self._export_btn.pack(fill="x", padx=8, pady=(0, 6))

        self._report_btn = ctk.CTkButton(
            c, text="GENERATE REPORT  ›",
            fg_color="transparent", hover_color=tc["border"],
            text_color=tc["text_dim"], border_color=tc["border_lt"], border_width=1,
            height=30, corner_radius=4,
            font=ctk.CTkFont(family=mono, size=11),
            command=self._generate_report, state="disabled")
        self._report_btn.pack(fill="x", padx=8, pady=(0, 6))

        self._progress = ctk.CTkProgressBar(
            c, mode="indeterminate",
            fg_color=tc["border"], progress_color=tc["accent"], height=3)
        self._progress.pack(fill="x", padx=8, pady=(2, 6))
        self._progress.set(0)

        self._status_var = ctk.StringVar(value="● READY")
        self._status_lbl = ctk.CTkLabel(
            c, textvariable=self._status_var,
            font=ctk.CTkFont(family=mono, size=11),
            text_color=tc["status_ok"])
        self._status_lbl.pack(anchor="w", padx=12, pady=(0, 10))

        # ── OPERATION FILTER ─────────────────────────────────────────────────
        _section_div("OPERATION FILTER")
        c = _card()
        self._op_var = ctk.StringVar(value="All Operations")

        # Native tk.Listbox + scrollbar — handles any number of operations.
        # MULTIPLE selectmode: click any item to toggle it on/off.
        # No modifier keys needed — each click independently toggles.

        # "All Operations" checkbox — selects/deselects everything
        self._op_all_var = ctk.BooleanVar(value=True)
        self._op_all_chk = ctk.CTkCheckBox(
            c,
            text="All Operations",
            variable=self._op_all_var,
            font=ctk.CTkFont(family=mono, size=10, weight="bold"),
            text_color=tc["text"],
            fg_color=tc["accent"],
            hover_color=tc["btn_primary_hover"],
            checkmark_color="#FFFFFF",
            border_color=tc["border_lt"],
            command=self._on_op_all_toggle,
        )
        self._op_all_chk.pack(anchor="w", padx=12, pady=(8, 4))

        lb_frame = ctk.CTkFrame(c, fg_color="transparent")
        lb_frame.pack(fill="x", padx=8, pady=(0, 8))
        lb_frame.grid_columnconfigure(0, weight=1)
        lb_frame.grid_rowconfigure(0, weight=1)

        lb_bg   = tc["card"]
        lb_fg   = tc["text_dim"]
        lb_sel  = tc["accent"]
        self._op_listbox = tk.Listbox(
            lb_frame,
            height=8,
            selectmode=tk.MULTIPLE,
            bg=lb_bg,
            fg=lb_fg,
            selectbackground=lb_sel,
            selectforeground="#FFFFFF",
            activestyle="none",
            relief="flat",
            borderwidth=0,
            highlightthickness=1,
            highlightbackground=tc["border_lt"],
            highlightcolor=tc["accent"],
            font=(mono, 10),
            exportselection=False,
        )
        op_vsb = ttk.Scrollbar(lb_frame, orient="vertical",
                               command=self._op_listbox.yview)
        self._op_listbox.configure(yscrollcommand=op_vsb.set)
        self._op_listbox.grid(row=0, column=0, sticky="nsew")
        op_vsb.grid(row=0, column=1, sticky="ns")

        # Populate initial values — no item selected (checkbox covers "all")
        for op in self._operations[1:]:  # skip "All Operations" — checkbox handles it
            self._op_listbox.insert(tk.END, op)
        self._op_listbox.bind("<<ListboxSelect>>", self._on_op_listbox_select)


        # ── DETECTION SETTINGS ───────────────────────────────────────────────
        _section_div("DETECTION SETTINGS")
        c = _card()
        imp_row = ctk.CTkFrame(c, fg_color="transparent")
        imp_row.pack(fill="x", padx=12, pady=(8, 8))
        imp_row.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(imp_row,
                     text="Impossible travel window",
                     font=ctk.CTkFont(family=mono, size=10),
                     text_color=tc["text_dim"]).grid(row=0, column=0, sticky="w")
        self._imp_window_var = ctk.StringVar(value=str(self._IMP_TRAVEL_WINDOW_MIN))
        ctk.CTkEntry(imp_row, textvariable=self._imp_window_var,
                     width=52, height=22,
                     fg_color=tc["bg"], border_color=tc["border_lt"], border_width=1,
                     text_color=tc["text"],
                     font=ctk.CTkFont(family=mono, size=10),
                     justify="center").grid(row=0, column=1, padx=(8, 4), sticky="e")
        ctk.CTkLabel(imp_row, text="min",
                     font=ctk.CTkFont(family=mono, size=10),
                     text_color=tc["text_dim"]).grid(row=0, column=2, sticky="w")

        def _on_imp_window_change(*_):
            try:
                v = int(self._imp_window_var.get())
                if 5 <= v <= 1440:
                    self.__class__._IMP_TRAVEL_WINDOW_MIN = v
            except ValueError:
                pass
        self._imp_window_var.trace_add("write", _on_imp_window_change)

        # ── MAP TILE SERVER ───────────────────────────────────────────────────
        _section_div("MAP TILE SERVER")
        c = _card()
        self._tile_var = ctk.StringVar(value="OpenStreetMap")
        ctk.CTkOptionMenu(
            c, variable=self._tile_var,
            values=list(TILE_SERVERS.keys()),
            fg_color=tc["sidebar"], button_color=tc["accent"],
            button_hover_color=tc["btn_primary_hover"],
            text_color=tc["text"],
            font=ctk.CTkFont(family=mono, size=11),
            dynamic_resizing=False,
            command=self._change_tile_server).pack(fill="x", padx=8, pady=10)

        # Bottom padding spacer inside scroll area
        ctk.CTkFrame(scroll, fg_color="transparent", height=16).pack()

    # ── Main content ──────────────────────────────────────────────────────────
    def _build_main(self):
        tc   = self._tc
        mono = MONO
        self.main = ctk.CTkFrame(self, fg_color=tc["bg"], corner_radius=0)
        self.main.grid(row=0, column=1, sticky="nsew")
        # row 0=banner, row 1=sep, row 2=tabview, row 3=sep, row 4=log
        self.main.grid_rowconfigure(2, weight=4)
        self.main.grid_rowconfigure(4, weight=1)
        self.main.grid_columnconfigure(0, weight=1)

        # ── Case context bar ──────────────────────────────────────────────────
        if self._case is not None:
            # ── Case banner — mockup-faithful design ──────────────────────────
            banner = ctk.CTkFrame(self.main, fg_color=tc["panel"],
                                  corner_radius=0, height=46)
            banner.grid(row=0, column=0, sticky="ew")
            banner.grid_propagate(False)
            banner.grid_columnconfigure(1, weight=1)

            # Left group: CASE pill + case name + analyst · client
            left = ctk.CTkFrame(banner, fg_color="transparent")
            left.grid(row=0, column=0, padx=(14, 0), sticky="nsw")

            # Clickable "CASE" pill — opens case info popup
            ctk.CTkButton(left,
                          text="CASE",
                          font=ctk.CTkFont(family=mono, size=9, weight="bold"),
                          text_color=tc["accent"],
                          fg_color="transparent",
                          hover_color=tc["card"],
                          border_color=tc["accent"],
                          border_width=1,
                          corner_radius=4,
                          height=22, width=52,
                          command=self._show_case_info).pack(
                side="left", padx=(0, 10), pady=0, anchor="center")

            # Case name — bright bold
            ctk.CTkLabel(left,
                         text=self._case.name,
                         font=ctk.CTkFont(family=mono, size=13, weight="bold"),
                         text_color=tc["text_bright"]).pack(side="left", padx=(0, 4))

            # analyst · client — dim monospace
            meta_parts = []
            if self._case.analyst:
                meta_parts.append(self._case.analyst)
            if self._case.client:
                meta_parts.append(self._case.client)
            if meta_parts:
                ctk.CTkLabel(left,
                             text="  ·  " + "  ·  ".join(meta_parts),
                             font=ctk.CTkFont(family=mono, size=10),
                             text_color=tc["text_dim"]).pack(side="left")

            # Right group: stat pill badges
            stats = self._case.stats()
            right = ctk.CTkFrame(banner, fg_color="transparent")
            right.grid(row=0, column=2, padx=(0, 14), sticky="nse")

            def _stat_pill(parent, text, border_col, label_col):
                f = ctk.CTkFrame(parent,
                                 fg_color="transparent",
                                 border_color=border_col,
                                 border_width=1,
                                 corner_radius=4)
                f.pack(side="left", padx=4, pady=0, anchor="center")
                lbl = ctk.CTkLabel(f,
                             text=text,
                             font=ctk.CTkFont(family=mono, size=10, weight="bold"),
                             text_color=label_col)
                lbl.pack(padx=8, pady=3)
                return lbl

            self._stat_events_lbl = _stat_pill(right, f"{stats['events']:,} events", tc["accent"], tc["accent"])

        # ── Bottom border on banner ───────────────────────────────────────────
        ctk.CTkFrame(self.main, fg_color=tc["border"],
                     height=1, corner_radius=0).grid(
            row=1, column=0, sticky="ew")

        # ── Tab view ─────────────────────────────────────────────────────────
        self.tabview = ctk.CTkTabview(
            self.main,
            fg_color=tc["panel"],
            segmented_button_fg_color=tc["panel"],
            segmented_button_selected_color=tc["panel"],
            segmented_button_selected_hover_color=tc["card"],
            segmented_button_unselected_color=tc["panel"],
            segmented_button_unselected_hover_color=tc["card"],
            text_color=tc["text_dim"],
            text_color_disabled=tc["text_dim"],
            border_color=tc["border"],
            border_width=0,
        )
        self.tabview.grid(row=2, column=0, sticky="nsew", padx=0, pady=0)

        for name in ("Map View", "Data Table", "IOC Filter", "Summary"):
            self.tabview.add(name)

        # Lazy map refresh: only rebuild markers when Map tab becomes active
        self.tabview.configure(command=self._on_tab_changed)

        self._build_map_tab()
        self._build_table_tab()
        self._build_ioc_tab()
        self._build_summary_tab()

        # ── Separator above log panel ─────────────────────────────────────────
        ttk.Separator(self.main, orient="horizontal",
                      style="TH.TSeparator").grid(row=3, column=0, sticky="ew")

        # ── Log panel (IRFlow-style terminal strip) ───────────────────────────
        log_outer = ctk.CTkFrame(self.main, fg_color=tc["panel"],
                                 corner_radius=0, height=140)
        log_outer.grid(row=4, column=0, sticky="nsew", padx=0, pady=0)
        log_outer.grid_propagate(False)
        log_outer.grid_rowconfigure(1, weight=1)
        log_outer.grid_columnconfigure(0, weight=1)

        # Log header bar
        log_hdr = ctk.CTkFrame(log_outer, fg_color=tc["card"],
                               corner_radius=0, height=26)
        log_hdr.grid(row=0, column=0, sticky="ew")
        log_hdr.grid_propagate(False)
        log_hdr.grid_columnconfigure(0, weight=1)
        ctk.CTkFrame(log_outer, fg_color=tc["border"], height=1,
                     corner_radius=0).grid(row=0, column=0, sticky="ew")

        hdr_inner = ctk.CTkFrame(log_hdr, fg_color="transparent")
        hdr_inner.grid(row=0, column=0, sticky="ew", padx=10, pady=3)
        hdr_inner.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(hdr_inner,
                     text="ACTIVITY LOG",
                     font=ctk.CTkFont(family=mono, size=11, weight="bold"),
                     text_color=tc["text_dim"]).grid(row=0, column=0, sticky="w")
        ctk.CTkButton(hdr_inner,
                      text="CLEAR",
                      width=58, height=22,
                      fg_color="transparent",
                      hover_color=tc["status_err"],
                      text_color=tc["text_dim"],
                      border_color=tc["border_lt"], border_width=1,
                      font=ctk.CTkFont(family=mono, size=9, weight="bold"),
                      command=self._clear_log).grid(row=0, column=1, sticky="e", padx=(0, 4))

        self._log_box = ctk.CTkTextbox(
            log_outer,
            fg_color=tc["panel"],
            text_color=tc["text_dim"],
            font=ctk.CTkFont(family=mono, size=10),
            state="disabled")
        self._log_box.grid(row=1, column=0, padx=4, pady=(0, 4), sticky="nsew")

    # ── Map tab ───────────────────────────────────────────────────────────────
    def _on_tab_changed(self):
        """Called whenever the user switches tabs. Flushes lazy refreshes."""
        active = self.tabview.get()
        if "Map" in active and getattr(self, "_map_dirty", False):
            self._map_dirty = False
            self._refresh_map()

    def _build_map_tab(self):
        tc   = self._tc
        mono = MONO
        tab  = self.tabview.tab("Map View")
        tab.grid_rowconfigure(2, weight=1)   # row 2 = map/detail (row 0=toolbar, 1=sep)
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_columnconfigure(1, weight=0)

        # Toolbar strip — mockup-faithful hint bar with coloured keywords
        bar = ctk.CTkFrame(tab, fg_color=tc["card"], corner_radius=0, height=32)
        bar.grid(row=0, column=0, columnspan=2, sticky="ew")
        bar.grid_propagate(False)
        bar.grid_columnconfigure(0, weight=1)

        # Left: coloured keyword hints in a horizontal pack
        hints_frame = ctk.CTkFrame(bar, fg_color="transparent")
        hints_frame.grid(row=0, column=0, padx=10, sticky="w")

        def _hint(parent, keyword, suffix):
            ctk.CTkLabel(parent, text=keyword,
                         font=ctk.CTkFont(family=mono, size=9, weight="bold"),
                         text_color=tc["accent"]).pack(side="left")
            ctk.CTkLabel(parent, text=suffix + "   ",
                         font=ctk.CTkFont(family=mono, size=9),
                         text_color=tc["text_dim"]).pack(side="left")

        _hint(hints_frame, "scroll", " zoom")
        _hint(hints_frame, "drag",   " pan")
        _hint(hints_frame, "click",  " detail")
        _hint(hints_frame, "right-click", " options")

        # Right: pin/event count
        self._map_count_lbl = ctk.CTkLabel(bar, text="",
                                            font=ctk.CTkFont(family=mono, size=9),
                                            text_color=tc["accent"])
        self._map_count_lbl.grid(row=0, column=1, padx=(0, 14), sticky="e")

        ttk.Separator(tab, orient="horizontal",
                      style="TH.TSeparator").grid(
            row=1, column=0, columnspan=2, sticky="ew")

        map_container = ctk.CTkFrame(tab, fg_color=tc["card"], corner_radius=0)
        map_container.grid(row=2, column=0, sticky="nsew", padx=(0, 0), pady=0)
        map_container.grid_rowconfigure(0, weight=1)
        map_container.grid_columnconfigure(0, weight=1)

        if MAPVIEW_AVAILABLE:
            self._map_widget = TkinterMapView(map_container, corner_radius=0,
                                               bg_color=tc["bg"])
            self._map_widget.grid(row=0, column=0, sticky="nsew")
            self._map_widget.set_position(20, 0)
            self._map_widget.set_zoom(2)
            self._map_widget.set_tile_server("https://a.tile.openstreetmap.org/{z}/{x}/{y}.png")
            self._map_widget.add_right_click_menu_command(
                "Copy Coordinates", command=self._map_copy_coords, pass_coords=True)
            self._map_widget.add_right_click_menu_command(
                "Zoom to All Markers", command=lambda c: self._zoom_to_markers())
            self._map_widget.add_right_click_menu_command(
                "Clear All Markers", command=lambda c: self._clear_map_markers())
        else:
            ctk.CTkLabel(map_container,
                         text="TkinterMapView not found.\nEnsure tkintermapview/ folder is present.",
                         text_color=tc["status_err"],
                         font=ctk.CTkFont(family=mono, size=12)).grid(
                row=0, column=0, padx=20, pady=40)
            self._map_widget = None

        # Detail panel — flush edge, IRFlow-style info column
        detail = ctk.CTkFrame(tab, fg_color=tc["panel"], corner_radius=0, width=260)
        detail.grid(row=2, column=1, sticky="nsew", pady=0)
        detail.grid_propagate(False)
        detail.grid_rowconfigure(2, weight=1)
        detail.grid_columnconfigure(0, weight=1)

        # Detail header
        det_hdr = ctk.CTkFrame(detail, fg_color=tc["card"], corner_radius=0, height=28)
        det_hdr.grid(row=0, column=0, sticky="ew")
        det_hdr.grid_propagate(False)
        ttk.Separator(detail, orient="horizontal",
                      style="TH.TSeparator").grid(row=1, column=0, sticky="ew")
        ctk.CTkLabel(det_hdr,
                     text="LOCATION DETAIL",
                     font=ctk.CTkFont(family=mono, size=10, weight="bold"),
                     text_color=tc["text_dim"]).grid(
            row=0, column=0, padx=10, pady=4, sticky="w")

        self._detail_box = ctk.CTkTextbox(
            detail, fg_color=tc["panel"], text_color=tc["text"],
            font=ctk.CTkFont(family=mono, size=11),
            state="disabled", wrap="word")
        self._detail_box.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)

    # ── Table tab ─────────────────────────────────────────────────────────────
    def _build_table_tab(self):
        tc   = self._tc
        mono = MONO
        tab  = self.tabview.tab("Data Table")
        tab.grid_rowconfigure(2, weight=1)   # row 2 = tree (0=toolbar, 1=sep)
        tab.grid_columnconfigure(0, weight=1)

        # ── Toolbar ───────────────────────────────────────────────────────────
        bar = ctk.CTkFrame(tab, fg_color=tc["card"], corner_radius=0, height=32)
        bar.grid(row=0, column=0, sticky="ew")
        bar.grid_propagate(False)
        bar.grid_columnconfigure(2, weight=1)

        self._row_lbl = ctk.CTkLabel(bar, text="No data loaded",
                                     font=ctk.CTkFont(family=mono, size=9),
                                     text_color=tc["text_dim"])
        self._row_lbl.grid(row=0, column=0, padx=(10, 14), pady=6)

        ctk.CTkLabel(bar, text="SEARCH",
                     font=ctk.CTkFont(family=mono, size=11, weight="bold"),
                     text_color=tc["text_dim"]).grid(row=0, column=1, padx=(0, 6))
        self._search_var = ctk.StringVar()
        self._search_var.trace_add("write", self._on_search_changed)
        ctk.CTkEntry(bar, textvariable=self._search_var, width=280,
                     placeholder_text="filter rows…",
                     fg_color=tc["bg"], border_color=tc["border"], border_width=1,
                     text_color=tc["text"], placeholder_text_color=tc["text_dim"],
                     height=22, corner_radius=2,
                     font=ctk.CTkFont(family=mono, size=9)).grid(
            row=0, column=2, padx=(0, 6), pady=5, sticky="w")

        # Impossible travel filter toggle
        self._imp_travel_active = False
        self._imp_travel_cache  = {}
        self._imp_btn = ctk.CTkButton(
            bar, text="⚠  IMP. TRAVEL",
            fg_color="transparent",
            hover_color=tc["card"],
            text_color=tc["status_err"],
            border_color=tc["status_err"], border_width=1,
            height=22, corner_radius=2,
            font=ctk.CTkFont(family=mono, size=9, weight="bold"),
            command=self._toggle_imp_travel)
        self._imp_btn.grid(row=0, column=3, padx=(0, 8), pady=5)

        # ── Data grid ─────────────────────────────────────────────────────────
        ttk.Separator(tab, orient="horizontal",
                      style="TH.TSeparator").grid(row=1, column=0, sticky="ew")
        tree_outer = ctk.CTkFrame(tab, fg_color=tc["card"], corner_radius=0)
        tree_outer.grid(row=2, column=0, sticky="nsew")
        tree_outer.grid_rowconfigure(0, weight=1)
        tree_outer.grid_columnconfigure(0, weight=1)
        self._apply_ttk_style()
        self._tree = ttk.Treeview(tree_outer, show="headings",
                                  selectmode="browse", style="TH.Treeview")
        vsb = ttk.Scrollbar(tree_outer, orient="vertical",   command=self._tree.yview)
        hsb = ttk.Scrollbar(tree_outer, orient="horizontal", command=self._tree.xview)
        self._tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self._tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        self._tree.bind("<ButtonRelease-1>",   self._on_table_click)
        self._tree.bind("<Double-Button-1>",   self._on_table_double_click)
        self._tree.bind("<Button-3>",          self._on_tree_right_click)

        # Configure row tags once at build time — not on every render
        if self._mode == "dark":
            self._tree.tag_configure("imp_travel",
                                     background="#2d0800", foreground="#FCA5A5")
        else:
            self._tree.tag_configure("imp_travel",
                                     background="#FFF0EE", foreground="#991B1B")

        # ── Keyboard shortcut bar ─────────────────────────────────────────────
        self._build_shortcut_bar(tab, row=3)

        # Bind shortcuts at app level
        self.bind_all("<Control-f>", lambda e: self._search_var.set("") or
                      self.tabview.set("Data Table") or self._search_var.set(""))
        self.bind_all("<Control-e>", lambda e: self._export_results())
        self.bind_all("<Control-i>", lambda e: self.tabview.set("IOC Filter"))
        self.bind_all("<Control-m>", lambda e: self.tabview.set("Map View"))
        self.bind_all("<Control-r>", lambda e: self._start_enrichment())
        self.bind_all("<Control-u>", lambda e: self.tabview.set("Summary"))

    # ── IOC Filter tab ────────────────────────────────────────────────────────
    def _build_ioc_tab(self):
        tc   = self._tc
        mono = MONO
        tab  = self.tabview.tab("IOC Filter")
        tab.grid_rowconfigure(2, weight=1)
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_columnconfigure(1, weight=1)

        # Input toolbar
        inp = ctk.CTkFrame(tab, fg_color=tc["card"], corner_radius=0)
        inp.grid(row=0, column=0, columnspan=2, sticky="ew")
        inp.grid_columnconfigure(1, weight=1)
        inp.grid_columnconfigure(3, weight=1)

        ctk.CTkLabel(inp, text="IOC FILTER",
                     font=ctk.CTkFont(family=mono, size=11, weight="bold"),
                     text_color=tc["accent"]).grid(
            row=0, column=0, columnspan=4, padx=12, pady=(8, 4), sticky="w")

        labels = ["CLIENT IP(s)", "SESSION ID(s)", "USER AGENT(s)", "TOKEN ID(s)"]
        placeholders = [
            "1.2.3.4, 5.6.7.8",
            "session-id-1, session-id-2",
            "python-requests/2.28, …",
            "token-id-1, …",
        ]
        self._ioc_vars: Dict[str, ctk.StringVar] = {}
        ioc_keys = ["ClientIP", "SessionId", "UserAgent", "UniqueTokenId"]

        for i, (lbl, ph, key) in enumerate(zip(labels, placeholders, ioc_keys)):
            col = (i % 2) * 2
            row = 1 + (i // 2)
            ctk.CTkLabel(inp, text=lbl,
                         font=ctk.CTkFont(family=mono, size=11, weight="bold"),
                         text_color=tc["text_dim"], width=110, anchor="e").grid(
                row=row, column=col, padx=(12, 6), pady=4, sticky="e")
            v = ctk.StringVar()
            self._ioc_vars[key] = v
            ctk.CTkEntry(inp, textvariable=v, placeholder_text=ph,
                         fg_color=tc["bg"], border_color=tc["border"], border_width=1,
                         text_color=tc["text"], placeholder_text_color=tc["text_dim"],
                         height=26, corner_radius=2,
                         font=ctk.CTkFont(family=mono, size=9)).grid(
                row=row, column=col + 1, padx=(0, 16), pady=4, sticky="ew")

        btn_row = ctk.CTkFrame(inp, fg_color="transparent")
        btn_row.grid(row=3, column=0, columnspan=4, padx=12, pady=(6, 10), sticky="ew")
        btn_row.grid_columnconfigure(2, weight=1)

        self._ioc_run_btn = ctk.CTkButton(
            btn_row, text="RUN IOC FILTER  ›",
            fg_color=tc["btn_primary"],
            hover_color=tc["btn_primary_hover"],
            text_color="#FFFFFF", height=30, corner_radius=3,
            font=ctk.CTkFont(family=mono, size=9, weight="bold"),
            command=self._run_ioc_filter)
        self._ioc_run_btn.grid(row=0, column=0, padx=(0, 8))

        ctk.CTkButton(
            btn_row, text="CLEAR",
            fg_color="transparent",
            hover_color=tc["card"],
            text_color=tc["text_dim"],
            border_color=tc["border"], border_width=1,
            height=30, corner_radius=3,
            font=ctk.CTkFont(family=mono, size=9),
            command=self._clear_ioc_fields).grid(row=0, column=1)

        self._ioc_export_btn = ctk.CTkButton(
            btn_row, text="EXPORT  ›",
            fg_color="transparent",
            hover_color=tc["card"],
            text_color=tc["text_dim"],
            border_color=tc["border"], border_width=1,
            height=30, corner_radius=3,
            font=ctk.CTkFont(family=mono, size=9),
            command=self._export_ioc_results, state="disabled")
        self._ioc_export_btn.grid(row=0, column=3, padx=(8, 0))

        # Results panels
        ttk.Separator(tab, orient="horizontal",
                      style="TH.TSeparator").grid(row=1, column=0, columnspan=2, sticky="ew")
        left = ctk.CTkFrame(tab, fg_color=tc["panel"], corner_radius=0)
        left.grid(row=2, column=0, sticky="nsew", padx=0, pady=0)
        left.grid_rowconfigure(1, weight=1)
        left.grid_columnconfigure(0, weight=1)

        lhdr = ctk.CTkFrame(left, fg_color=tc["card"], corner_radius=0, height=26)
        lhdr.grid(row=0, column=0, sticky="ew")
        lhdr.grid_propagate(False)
        ctk.CTkLabel(lhdr, text="IOC MATCH SUMMARY",
                     font=ctk.CTkFont(family=mono, size=11, weight="bold"),
                     text_color=tc["text_dim"]).grid(row=0, column=0, padx=10, pady=4, sticky="w")

        self._ioc_summary_box = ctk.CTkTextbox(
            left, fg_color=tc["panel"], text_color=tc["text"],
            font=ctk.CTkFont(family=mono, size=10),
            state="disabled")
        self._ioc_summary_box.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)

        right = ctk.CTkFrame(tab, fg_color=tc["panel"], corner_radius=0)
        right.grid(row=2, column=1, sticky="nsew", padx=0, pady=0)
        right.grid_rowconfigure(1, weight=1)
        right.grid_columnconfigure(0, weight=1)

        rhdr = ctk.CTkFrame(right, fg_color=tc["card"], corner_radius=0, height=26)
        rhdr.grid(row=0, column=0, sticky="ew")
        rhdr.grid_propagate(False)
        ctk.CTkLabel(rhdr, text="MATCHED ROWS",
                     font=ctk.CTkFont(family=mono, size=11, weight="bold"),
                     text_color=tc["text_dim"]).grid(row=0, column=0, padx=10, pady=4, sticky="w")

        ioc_tree_outer = ctk.CTkFrame(right, fg_color="transparent")
        ioc_tree_outer.grid(row=1, column=0, sticky="nsew", padx=0, pady=0)
        ioc_tree_outer.grid_rowconfigure(0, weight=1)
        ioc_tree_outer.grid_columnconfigure(0, weight=1)

        self._ioc_tree = ttk.Treeview(ioc_tree_outer, show="headings",
                                       selectmode="browse", style="TH.Treeview")
        ivsb = ttk.Scrollbar(ioc_tree_outer, orient="vertical", command=self._ioc_tree.yview)
        ihsb = ttk.Scrollbar(ioc_tree_outer, orient="horizontal", command=self._ioc_tree.xview)
        self._ioc_tree.configure(yscrollcommand=ivsb.set, xscrollcommand=ihsb.set)
        self._ioc_tree.grid(row=0, column=0, sticky="nsew")
        ivsb.grid(row=0, column=1, sticky="ns")
        ihsb.grid(row=1, column=0, sticky="ew")

    # ── Summary tab ───────────────────────────────────────────────────────────
    def _build_summary_tab(self):
        tc   = self._tc
        mono = MONO
        tab  = self.tabview.tab("Summary")
        tab.grid_rowconfigure(0, weight=1)
        tab.grid_columnconfigure(0, weight=1)
        scroll = ctk.CTkScrollableFrame(tab, fg_color=tc["bg"],
                                         scrollbar_button_color=tc["border"],
                                         scrollbar_button_hover_color=tc["btn_primary"])
        scroll.grid(row=0, column=0, sticky="nsew")
        scroll.grid_columnconfigure(0, weight=1)
        scroll.grid_columnconfigure(1, weight=1)
        self._summary_frame = scroll
        ctk.CTkLabel(scroll,
                     text="Run enrichment to view statistics",
                     font=ctk.CTkFont(family=mono, size=12),
                     text_color=tc["text_dim"]).grid(
            row=0, column=0, columnspan=2, padx=20, pady=60)

    def _apply_ttk_style(self):
        tc   = self._tc
        mono = MONO
        s = ttk.Style()
        s.theme_use("clam")

        # Separator — matches border_lt colour for both themes
        s.configure("TH.TSeparator", background=tc["border_lt"])

        if self._mode == "dark":
            # IRFlow-style: near-black rows, tight 22px height, monospace font
            s.configure("TH.Treeview",
                        background="#0F1217",
                        foreground="#E2E8F0",
                        fieldbackground="#0F1217",
                        rowheight=22,
                        font=(mono, 10),
                        borderwidth=0,
                        relief="flat")
            s.configure("TH.Treeview.Heading",
                        background="#0A0C0F",
                        foreground="#64748B",
                        relief="flat",
                        borderwidth=0,
                        font=(mono, 9, "bold"))
            s.map("TH.Treeview",
                  background=[("selected", "#1D4ED8")],
                  foreground=[("selected", "#F8FAFC")])
            # Alternate row tinting via tag (applied on insert)
            s.configure("TH.Treeview",
                        rowheight=22)
            # Impossible travel row highlight
            self._tree_tag_imp_travel = ("imp_travel",)

        else:
            s.configure("TH.Treeview",
                        background="#FFFFFF",
                        foreground="#0F172A",
                        fieldbackground="#FFFFFF",
                        rowheight=22,
                        font=(mono, 10),
                        borderwidth=0,
                        relief="flat")
            s.configure("TH.Treeview.Heading",
                        background="#F1F5F9",
                        foreground="#475569",
                        relief="flat",
                        borderwidth=0,
                        font=(mono, 9, "bold"))
            s.map("TH.Treeview",
                  background=[("selected", "#2563EB")],
                  foreground=[("selected", "#FFFFFF")])
            self._tree_tag_imp_travel = ("imp_travel",)

    # ─────────────────────────────────────────────────────────────────────────
    # File / folder pickers
    # ─────────────────────────────────────────────────────────────────────────
    def _select_ual(self):
        path = filedialog.askopenfilename(
            title="Select UAL Export",
            filetypes=[("Supported", "*.csv *.xlsx *.xls"),
                       ("CSV", "*.csv"), ("Excel", "*.xlsx *.xls")])
        if path:
            self._input_path = path
            self._ual_lbl.configure(
                text=f"✔  {Path(path).name}", text_color=self._tc["status_ok"])
            self._log(f"UAL file: {Path(path).name}")

    def _select_city_db(self):
        path = filedialog.askopenfilename(
            title="Select GeoLite2-City.mmdb",
            filetypes=[("MaxMind DB", "*.mmdb"), ("All files", "*.*")])
        if path:
            self._city_db_path = path
            self._city_lbl.configure(
                text=f"City DB: ✔  {Path(path).name}", text_color=self._tc["status_ok"])
            self._log(f"City DB: {Path(path).name}")

    def _select_asn_db(self):
        path = filedialog.askopenfilename(
            title="Select GeoLite2-ASN.mmdb",
            filetypes=[("MaxMind DB", "*.mmdb"), ("All files", "*.*")])
        if path:
            self._asn_db_path = path
            self._asn_lbl.configure(
                text=f"ASN DB: ✔  {Path(path).name}", text_color=self._tc["status_ok"])
            self._log(f"ASN DB: {Path(path).name}")

    def _show_case_info(self):
        """Open a popup showing case metadata and live stats."""
        if self._case is None:
            return
        tc   = self._tc
        mono = MONO

        pop = ctk.CTkToplevel(self)
        pop.title("Case Information")
        pop.geometry("480x400")
        pop.configure(fg_color=tc["bg"])
        pop.grab_set()
        pop.resizable(True, True)
        pop.minsize(480, 360)
        pop.grid_rowconfigure(1, weight=1)
        pop.grid_columnconfigure(0, weight=1)

        # Header
        hdr = ctk.CTkFrame(pop, fg_color=tc["panel"], corner_radius=0, height=46)
        hdr.grid(row=0, column=0, sticky="ew")
        hdr.grid_propagate(False)
        hdr.grid_columnconfigure(0, weight=1)
        ctk.CTkFrame(hdr, fg_color=tc["accent"], width=3,
                     corner_radius=0).grid(row=0, column=0, sticky="ns")
        ctk.CTkLabel(hdr, text="CASE INFORMATION",
                     font=ctk.CTkFont(family=mono, size=12, weight="bold"),
                     text_color=tc["accent"]).grid(
            row=0, column=1, padx=14, pady=14, sticky="w")
        ctk.CTkFrame(pop, fg_color=tc["border"], height=1,
                     corner_radius=0).grid(row=0, column=0, sticky="sew")

        # Body
        body = ctk.CTkScrollableFrame(pop, fg_color=tc["bg"],
                                       scrollbar_button_color=tc["border"])
        body.grid(row=1, column=0, sticky="nsew", padx=0, pady=0)
        body.grid_columnconfigure(1, weight=1)

        stats = self._case.stats()

        fields = [
            ("Case Name",    self._case.name),
            ("Client",       self._case.client       or "—"),
            ("Analyst",      self._case.analyst      or "—"),
            ("Description",  self._case.description  or "—"),
            ("Created",      (self._case.created_at  or "")[:16]),
            ("File",         str(self._case.path)),
        ]
        stat_fields = [
            ("Total Events",  f"{stats['events']:,}"),
            ("IOCs",          str(stats["iocs"])),
            ("Artefacts",     str(stats["artefacts"])),
            ("Identities",    str(stats["identities"])),
            ("Notes",         str(stats["notes"])),
        ]

        def _row(parent, row, label, value, color=None):
            ctk.CTkLabel(parent, text=label,
                         font=ctk.CTkFont(family=mono, size=10, weight="bold"),
                         text_color=tc["text_dim"],
                         width=120, anchor="e").grid(
                row=row, column=0, padx=(16, 10), pady=5, sticky="ne")
            ctk.CTkLabel(parent, text=value,
                         font=ctk.CTkFont(family=mono, size=10),
                         text_color=color or tc["text"],
                         anchor="w", wraplength=280, justify="left").grid(
                row=row, column=1, padx=(0, 16), pady=5, sticky="w")

        # Divider label
        def _section(parent, row, title):
            ctk.CTkFrame(parent, fg_color=tc["border"], height=1).grid(
                row=row, column=0, columnspan=2, padx=16, pady=(10, 4), sticky="ew")
            ctk.CTkLabel(parent, text=title,
                         font=ctk.CTkFont(family=mono, size=9, weight="bold"),
                         text_color=tc["text_muted"]).grid(
                row=row, column=0, columnspan=2, padx=16, pady=(10, 4), sticky="w")

        r = 0
        _section(body, r, "METADATA"); r += 1
        for label, value in fields:
            _row(body, r, label, value)
            r += 1

        _section(body, r, "STATISTICS"); r += 1
        for label, value in stat_fields:
            _row(body, r, label, value, tc["accent"])
            r += 1

        # Footer: DELETE CASE (left) + CLOSE (right)
        footer = ctk.CTkFrame(pop, fg_color="transparent")
        footer.grid(row=2, column=0, padx=16, pady=(4, 12), sticky="ew")
        footer.grid_columnconfigure(1, weight=1)

        def _do_delete():
            case_name = self._case.name
            case_path = str(self._case.path)
            if not messagebox.askyesno(
                "Delete Case",
                f'Permanently delete case:\n\n"{case_name}"\n\n'
                f'File: {case_path}\n\n'
                "This cannot be undone.",
                icon="warning", parent=pop):
                return
            pop.destroy()
            # Remove from recents
            try:
                from pathlib import Path as _P
                import json as _json
                recent_file = _P.home() / ".threadhunter_recent"
                if recent_file.exists():
                    paths = _json.loads(recent_file.read_text())
                    paths = [p for p in paths if p != case_path]
                    recent_file.write_text(_json.dumps(paths))
            except Exception:
                pass
            # Delete the file then close the investigation window
            try:
                self._case.close()
                _secure_delete(case_path)
            except Exception:
                pass
            # Trigger close handler to return to launcher
            handler = getattr(self, "_on_close_handler", None)
            if handler:
                handler()
            else:
                self.destroy()

        ctk.CTkButton(footer, text="DELETE CASE",
                      fg_color="transparent",
                      hover_color=tc["btn_danger"],
                      text_color=tc["status_err"],
                      border_color=tc["status_err"], border_width=1,
                      height=30, corner_radius=3,
                      font=ctk.CTkFont(family=mono, size=10, weight="bold"),
                      command=_do_delete).grid(
            row=0, column=0, sticky="w")

        ctk.CTkButton(footer, text="CLOSE",
                      fg_color="transparent", hover_color=tc["card"],
                      text_color=tc["text_dim"], border_color=tc["border"],
                      border_width=1, height=30, corner_radius=3,
                      font=ctk.CTkFont(family=mono, size=10),
                      command=pop.destroy).grid(
            row=0, column=2, sticky="e")

    def _close_case(self):
        """Close this case window and return to the launcher."""
        if self._busy:
            if not messagebox.askyesno(
                "Processing in progress",
                "Enrichment is still running. Close anyway?",
                parent=self,
            ):
                return
        # Call the registered close handler (set by main.py via protocol())
        # Falls back to plain destroy if no handler was registered (standalone mode)
        handler = getattr(self, "_on_close_handler", None)
        if handler:
            handler()
        else:
            if self._case is not None:
                try:
                    self._case.close()
                except Exception:
                    pass
            self.destroy()

    def _select_output_dir(self):
        path = filedialog.askdirectory(title="Select Output Folder")
        if path:
            self._output_dir = path
            self._out_lbl.configure(
                text=f"✔  {path}", text_color=self._tc["status_ok"])
            self._log(f"Output folder: {path}")

    # ─────────────────────────────────────────────────────────────────────────
    # Enrichment
    # ─────────────────────────────────────────────────────────────────────────
    def _start_enrichment(self):
        if self._busy:
            return
        if not self._input_path:
            messagebox.showwarning("No Input", "Select a UAL file first.")
            return
        fmt = "csv" if self._fmt_var.get() == "CSV" else "xlsx"
        self._busy = True
        self._run_btn.configure(state="disabled", text="⏳  Processing…")
        self._progress.start()
        self._status_var.set("● Running…")
        self._status_lbl.configure(text_color=self._tc["status_warn"])
        self._log("─" * 55)
        self._log(f"Enriching: {Path(self._input_path).name}")
        ql = QueueLogger(self._log_q)
        threading.Thread(
            target=run_enrichment,
            args=(
                self._input_path,
                self._city_db_path,
                self._asn_db_path,
                self._skip_geo.get(),
                self._output_dir,
                fmt,
                self._split_ops.get(),
                ql,
                self._result_q,
            ),
            daemon=True,
        ).start()

    def _op_listbox_set_values(self, values, select=None):
        """
        Repopulate the op listbox without firing <<ListboxSelect>> events.
        select: None/"All Operations"/[] → tick checkbox, clear selection
                str or list → select those items, untick checkbox
        """
        self._op_updating = True
        try:
            lb = self._op_listbox
            lb.delete(0, tk.END)
            # Exclude "All Operations" from listbox — checkbox handles it
            ops = [v for v in values if v != "All Operations"]
            for op in ops:
                lb.insert(tk.END, op)

            lb.selection_clear(0, tk.END)
            if select is None or select == "All Operations" or select == []:
                if hasattr(self, "_op_all_var"): self._op_all_var.set(True)
                self._op_var.set("All Operations")
            else:
                if hasattr(self, "_op_all_var"): self._op_all_var.set(False)
                targets = [select] if isinstance(select, str) else list(select)
                for t in targets:
                    if t in ops:
                        i = ops.index(t)
                        lb.selection_set(i)
                        lb.see(i)
                self._op_var.set(",".join(targets))
        finally:
            self._op_updating = False

    def _on_op_listbox_select(self, event=None):
        """Called on listbox selection change — apply multi-op filter."""
        if getattr(self, "_op_updating", False):
            return  # programmatic update in progress — ignore event
        sel = self._op_listbox.curselection()
        if not sel:
            # Nothing selected — treat as "All Operations"
            if hasattr(self, "_op_all_var"): self._op_all_var.set(True)
            self._op_var.set("All Operations")
            self._apply_filter()
            return
        # Untick "All" checkbox when specific items are selected
        if hasattr(self, "_op_all_var"): self._op_all_var.set(False)
        self._apply_filter()

    def _on_op_all_toggle(self):
        """Checkbox toggled — select all ops or clear to nothing."""
        self._op_updating = True
        try:
            if self._op_all_var.get():
                # Ticked: clear listbox selection, show all data
                self._op_listbox.selection_clear(0, tk.END)
                self._op_var.set("All Operations")
            else:
                # Unticked: select all items in listbox
                if self._op_listbox.size() > 0:
                    self._op_listbox.selection_set(0, tk.END)
        finally:
            self._op_updating = False
        self._apply_filter()

    def _apply_filter(self, op: str = None):
        if self._df is None:
            return
        # Reset impossible travel filter if active — op filter takes precedence
        if getattr(self, "_imp_travel_active", False):
            self._imp_travel_active = False
            if hasattr(self, "_imp_btn"):
                self._imp_btn.configure(
                    fg_color="transparent",
                    text_color=self._tc["status_err"],
                    border_color=self._tc["status_err"],
                    text="⚠  IMP. TRAVEL")

        # Read selected operations from listbox + checkbox state
        selected_ops: List[str] = []
        all_checked = getattr(self, "_op_all_var", None)
        if all_checked is None or all_checked.get():
            # "All Operations" checkbox is ticked — no filter
            self._fdf = self._df
        else:
            if hasattr(self, "_op_listbox"):
                sel = self._op_listbox.curselection()
                selected_ops = [self._op_listbox.get(i) for i in sel]
            if not selected_ops:
                # Nothing selected — show all
                self._fdf = self._df
            elif len(selected_ops) == 1:
                try:
                    self._fdf = self._df.filter(
                        pl.col("Operation") == selected_ops[0])
                except Exception:
                    self._fdf = self._df
            else:
                try:
                    self._fdf = self._df.filter(
                        pl.col("Operation").is_in(selected_ops))
                except Exception:
                    self._fdf = self._df

        n = len(self._fdf) if self._fdf is not None else 0
        count_str = f"{n:,} rows"
        if selected_ops:
            count_str += f"  ·  {len(selected_ops)} op(s)"
        self._row_lbl.configure(text=count_str)

        # Refresh the active tab immediately; mark map dirty so it
        # updates lazily when the user actually switches to it.
        active = self.tabview.get()
        if "Map" in active:
            self._map_dirty = False
            self._refresh_map()
            self._refresh_table()
        else:
            self._map_dirty = True
            self._refresh_table()

    def _export_results(self):
        if self._df is None:
            return
        fmt = "csv" if self._fmt_var.get() == "CSV" else "xlsx"
        path = filedialog.asksaveasfilename(
            defaultextension=f".{fmt}",
            filetypes=[("CSV", "*.csv"), ("Excel", "*.xlsx")],
            title="Export Current View")
        if not path:
            return
        try:
            df = self._fdf if self._fdf is not None else self._df
            if path.endswith(".csv"):
                df.write_csv(path)
            else:
                df.write_excel(path)
            self._log(f"Exported {len(df):,} rows → {Path(path).name}")
            messagebox.showinfo("Exported", f"Saved {len(df):,} rows to:\n{path}")
        except Exception as e:
            messagebox.showerror("Export Error", str(e))

    # ─────────────────────────────────────────────────────────────────────────
    # IOC filter
    # ─────────────────────────────────────────────────────────────────────────
    def _run_ioc_filter(self):
        if self._df is None:
            messagebox.showwarning("No Data", "Run enrichment first.")
            return
        if self._busy:
            return

        iocs: Dict[str, List[str]] = {}
        for key, var in self._ioc_vars.items():
            vals = [v.strip() for v in var.get().split(",") if v.strip()]
            if vals:
                iocs[key] = vals

        if not iocs:
            messagebox.showwarning("No IOCs", "Enter at least one IOC value.")
            return

        self._busy = True
        self._ioc_run_btn.configure(state="disabled", text="Filtering...")
        self._progress.start()
        self._status_var.set("● IOC filtering…")
        self._status_lbl.configure(text_color=self._tc["status_warn"])

        fmt = "csv" if self._fmt_var.get() == "CSV" else "xlsx"
        stem = Path(self._input_path).stem if self._input_path else "ual"
        ql = QueueLogger(self._log_q)

        threading.Thread(
            target=run_ioc_filter,
            args=(self._df, iocs, self._output_dir, fmt, stem, ql, self._result_q),
            daemon=True,
        ).start()

    def _clear_ioc_fields(self):
        for v in self._ioc_vars.values():
            v.set("")
        self._ioc_summary_box.configure(state="normal")
        self._ioc_summary_box.delete("1.0", "end")
        self._ioc_summary_box.configure(state="disabled")
        for item in self._ioc_tree.get_children():
            self._ioc_tree.delete(item)
        self._ioc_export_btn.configure(state="disabled")
        self._ioc_df = None

    def _export_ioc_results(self):
        if self._ioc_df is None:
            return
        fmt = "csv" if self._fmt_var.get() == "CSV" else "xlsx"
        path = filedialog.asksaveasfilename(
            defaultextension=f".{fmt}",
            filetypes=[("CSV", "*.csv"), ("Excel", "*.xlsx")],
            title="Export IOC Filtered Results")
        if not path:
            return
        try:
            if path.endswith(".csv"):
                self._ioc_df.write_csv(path)
            else:
                self._ioc_df.write_excel(path)
            self._log(f"IOC export: {len(self._ioc_df):,} rows → {Path(path).name}")
            messagebox.showinfo("Exported", f"Saved {len(self._ioc_df):,} rows to:\n{path}")
        except Exception as e:
            messagebox.showerror("Export Error", str(e))

    def _populate_ioc_results(self, fdf, summary: Dict):
        tc = self._tc

        # Summary box
        self._ioc_summary_box.configure(state="normal")
        self._ioc_summary_box.delete("1.0", "end")

        def w(text):
            self._ioc_summary_box.insert("end", text)

        w(f"{'─' * 32}\n")
        w(f"  IOC Filter Results\n")
        w(f"{'─' * 32}\n")
        w(f"  IOCs searched : {summary['searched']}\n")
        w(f"  IOCs matched  : {len(summary['found'])}\n")
        w(f"  IOCs missed   : {len(summary['not_found'])}\n")
        w(f"  Matching rows : {summary['total_rows']:,}\n")

        if summary["found"]:
            w(f"\n▸ MATCHED IOCs\n")
            for ioc, count in sorted(summary["found"].items(),
                                     key=lambda x: x[1], reverse=True):
                w(f"  ✔  {ioc}\n")
                w(f"     {count:,} row(s)\n")

        if summary["not_found"]:
            w(f"\n▸ NOT FOUND\n")
            for ioc in summary["not_found"]:
                w(f"  ✗  {ioc}\n")

        self._ioc_summary_box.configure(state="disabled")

        # Results table
        for item in self._ioc_tree.get_children():
            self._ioc_tree.delete(item)

        if fdf is None or len(fdf) == 0:
            self._ioc_tree["columns"] = ("result",)
            self._ioc_tree.heading("result", text="Result")
            self._ioc_tree.column("result", width=300)
            self._ioc_tree.insert("", "end", values=("No matching rows found",))
            return

        PRIORITY = ["CreationDate", "Operation", "UserId", "ClientIP",
                    "Country", "City", "ASN", "Organization",
                    "AppDisplayName", "SessionId", "UniqueTokenId", "UserAgent"]
        HIDDEN = {"AuditData", "Latitude", "Longitude"}
        cols = [c for c in PRIORITY if c in fdf.columns]
        cols += [c for c in fdf.columns if c not in cols and c not in HIDDEN]

        self._ioc_tree["columns"] = cols
        for col in cols:
            self._ioc_tree.heading(col, text=col)
            w2 = max(80, min(200, len(col) * 11 + 20))
            self._ioc_tree.column(col, width=w2, minwidth=50)

        self._ioc_tree.grid_remove()
        self._ioc_tree.delete(*self._ioc_tree.get_children())

        col_indices = [fdf.columns.index(c) for c in cols if c in fdf.columns]
        for raw in fdf.head(2000).iter_rows():
            self._ioc_tree.insert("", "end",
                                  values=tuple(
                                      "" if raw[i] is None else str(raw[i])
                                      for i in col_indices))

        self._ioc_tree.grid(row=0, column=0, sticky="nsew")

    # ─────────────────────────────────────────────────────────────────────────
    # Queue polling
    # ─────────────────────────────────────────────────────────────────────────
    def _poll_queues(self):
        # Drain log queue — batch all pending messages into one textbox write
        lines: List[str] = []
        try:
            while True:
                item = self._log_q.get_nowait()
                if item[0] == "log":
                    ts    = datetime.now().strftime("%H:%M:%S")
                    level = item[1]   # "INFO", "WARN", "ERROR", "DEBUG"
                    msg   = item[2]
                    # Plain INFO messages (from _log()) get a clean format;
                    # WARN/ERROR from the enrichment worker keep the level tag.
                    if level == "INFO":
                        lines.append(f"[{ts}]  {msg}\n")
                    else:
                        lines.append(f"[{ts}] [{level}]  {msg}\n")
        except queue.Empty:
            pass

        if lines:
            self._log_box.configure(state="normal")
            self._log_box.insert("end", "".join(lines))
            # Cap at 500 lines — trim oldest when exceeded
            line_count = int(self._log_box.index("end-1c").split(".")[0])
            if line_count > 500:
                self._log_box.delete("1.0", f"{line_count - 500}.0")
            self._log_box.see("end")
            self._log_box.configure(state="disabled")

        # Check result queue
        try:
            item = self._result_q.get_nowait()
            kind = item[0]
            if kind == "done":
                _, df, out_path, split_results = item
                self._on_enrichment_done(df, out_path, split_results)
            elif kind == "error":
                self._on_enrichment_error(item[1])
            elif kind == "ioc_done":
                _, fdf, summary, out_path = item
                self._on_ioc_done(fdf, summary, out_path)
            elif kind == "ioc_error":
                self._on_ioc_error(item[1])
        except queue.Empty:
            pass

        # Poll faster during enrichment, slower when idle to reduce CPU wake-ups
        interval = 80 if self._busy else 250
        self.after(interval, self._poll_queues)

    def _on_enrichment_done(self, df, out_path: str, split_results: Dict[str, int]):
        self._df = df
        self._fdf = df
        self._busy = False
        self._progress.stop()
        self._progress.set(1.0)
        self._run_btn.configure(state="normal", text="▶  RUN ENRICHMENT")
        self._export_btn.configure(state="normal")
        self._report_btn.configure(state="normal")
        self._status_var.set(f"● {len(df):,} ROWS ENRICHED")
        self._status_lbl.configure(text_color=self._tc["status_ok"])
        self._log(f"✔ Enriched file: {Path(out_path).name}")
        if split_results:
            self._log(f"✔ Operation splits: {len(split_results)} file(s)")

        # ── Persist events into case database (background thread) ───────────────
        if self._case is not None:
            import threading as _th
            _case_ref  = self._case
            _log_fn    = self._log
            _update_fn = self._update_banner_stats
            def _write_case_db():
                try:
                    rows = df.to_dicts()
                    _case_ref.insert_events_bulk(rows, source="ual")
                    stats = _case_ref.stats()
                    # Schedule UI update back on main thread
                    self.after(0, lambda: _log_fn(f"✔ Case DB: {stats['events']:,} total events"))
                    self.after(0, lambda: _update_fn(stats))
                except Exception as e:
                    self.after(0, lambda: _log_fn(f"⚠ Could not save to case DB: {e}"))
            self._log("Saving events to case database…")
            _th.Thread(target=_write_case_db, daemon=True).start()

        ops = ["All Operations"]
        if "Operation" in df.columns:
            try:
                ops += sorted(df["Operation"].drop_nulls().unique().to_list())
            except Exception:
                pass
        self._operations = ops
        if hasattr(self, "_op_listbox"):
            self._op_listbox_set_values(ops, select="All Operations")
        self._table_cols_cache  = []    # force column header reconfigure
        self._summary_cache_key = None  # force summary rebuild
        self._imp_travel_cache  = {}    # invalidate impossible travel cache
        self._imp_travel_active = False  # reset filter state on new data

        # Stagger: table first (instant feedback), then map, then summary, then modules
        self._refresh_table()
        self._row_lbl.configure(text=f"{len(df):,} rows")
        self.after(50,  self._refresh_map)
        self.after(150, self._refresh_summary)

    def _on_enrichment_error(self, msg: str):
        self._busy = False
        self._progress.stop()
        self._progress.set(0)
        self._run_btn.configure(state="normal", text="▶  RUN ENRICHMENT")
        self._status_var.set("● Error — see log")
        self._status_lbl.configure(text_color=self._tc["status_err"])
        self._log(f"ERROR: {msg[:400]}")
        messagebox.showerror("Enrichment Error", msg[:600])

    def _on_ioc_done(self, fdf, summary: Dict, out_path: str):
        self._busy = False
        self._progress.stop()
        self._progress.set(0)
        self._ioc_run_btn.configure(state="normal", text="Run IOC Filter")

        found = len(summary.get("found", {}))
        total = summary.get("total_rows", 0)
        self._status_var.set(f"● IOC: {found} matched, {total:,} rows")
        self._status_lbl.configure(text_color=self._tc["status_ok"] if found else self._tc["status_warn"])

        self._ioc_df = fdf
        if fdf is not None and len(fdf) > 0:
            self._ioc_export_btn.configure(state="normal")

        self._populate_ioc_results(fdf, summary)
        if out_path:
            self._log(f"✔ IOC filtered file: {Path(out_path).name}")
        self.tabview.set("IOC Filter")

    def _on_ioc_error(self, msg: str):
        self._busy = False
        self._progress.stop()
        self._progress.set(0)
        self._ioc_run_btn.configure(state="normal", text="Run IOC Filter")
        self._status_var.set("● IOC error — see log")
        self._status_lbl.configure(text_color=self._tc["status_err"])
        self._log(f"IOC ERROR: {msg[:400]}")
        messagebox.showerror("IOC Filter Error", msg[:600])

    # ─────────────────────────────────────────────────────────────────────────
    # Banner stats update
    # ─────────────────────────────────────────────────────────────────────────
    def _update_banner_stats(self, stats: Dict = None):
        """
        Refresh the three stat pill labels in the case banner after enrichment.
        Rebuilds the pill text in place — avoids a full UI rebuild.
        """
        if self._case is None:
            return
        if stats is None:
            stats = self._case.stats()
        # The pills are CTkLabel widgets inside CTkFrame pills.
        # We stored references to them at build time if we can find them;
        # if not (e.g. on first load), the banner already has correct values.
        try:
            if hasattr(self, "_stat_events_lbl"):
                self._stat_events_lbl.configure(
                    text=f"{stats['events']:,} events")
        except Exception:
            pass

    # ─────────────────────────────────────────────────────────────────────────
    # Map
    # ─────────────────────────────────────────────────────────────────────────
    def _refresh_map(self):
        if self._map_widget is None:
            return
        self._clear_map_markers()
        df = self._fdf if self._fdf is not None else self._df
        if df is None:
            return

        has_lat  = "Latitude"  in df.columns
        has_lon  = "Longitude" in df.columns
        has_cty  = "Country"   in df.columns
        has_city = "City"      in df.columns

        # ── Build a working frame with resolved lat/lon ───────────────────────
        # For rows missing exact coords, fill from country centroid.
        # Done entirely in Polars — no Python row loop.
        work = df.select([
            c for c in ["ClientIP", "UserId", "Country", "City",
                        "Organization", "Operation", "ASN",
                        "Latitude", "Longitude"]
            if c in df.columns
        ])

        if has_lat and has_lon and has_cty:
            centroids = _get_centroid_df()
            work = (work
                    .join(centroids, on="Country", how="left")
                    .with_columns([
                        pl.when(pl.col("Latitude").is_null())
                          .then(pl.col("_clat"))
                          .otherwise(pl.col("Latitude"))
                          .alias("Latitude"),
                        pl.when(pl.col("Longitude").is_null())
                          .then(pl.col("_clon"))
                          .otherwise(pl.col("Longitude"))
                          .alias("Longitude"),
                    ])
                    .drop(["_clat", "_clon"]))
        elif has_cty and not (has_lat and has_lon):
            c2 = _get_centroid_df()
            if c2 is not None:
                c2 = c2.rename({"_clat": "Latitude", "_clon": "Longitude"})
                work = work.join(c2, on="Country", how="left")

        # Drop rows where we still have no coords
        if "Latitude" in work.columns and "Longitude" in work.columns:
            work = work.filter(
                pl.col("Latitude").is_not_null() & pl.col("Longitude").is_not_null()
            )
        else:
            return  # nothing to plot

        # Round to 3dp bucket for clustering
        work = work.with_columns([
            (pl.col("Latitude")  * 1000).round(0).truediv(1000).alias("_lat_b"),
            (pl.col("Longitude") * 1000).round(0).truediv(1000).alias("_lon_b"),
        ])

        # Aggregate per bucket in Polars — single pass, vectorised
        agg_exprs = [pl.len().alias("count")]
        for col in ["ClientIP", "UserId", "Organization", "Operation", "ASN"]:
            if col in work.columns:
                agg_exprs.append(
                    pl.col(col).drop_nulls().unique().implode().alias(f"_{col}_list")
                )
        for col in ["Country", "City", "Latitude", "Longitude"]:
            if col in work.columns:
                agg_exprs.append(pl.col(col).first().alias(col))

        grouped = work.group_by(["_lat_b", "_lon_b"]).agg(agg_exprs)

        total_events = grouped["count"].sum()
        self._map_count_lbl.configure(
            text=f"{len(grouped)} pins  ·  {total_events:,} events")

        # ── Place markers ─────────────────────────────────────────────────────
        tc = self._tc
        for row in grouped.iter_rows(named=True):
            lat     = row.get("Latitude") or row["_lat_b"]
            lon     = row.get("Longitude") or row["_lon_b"]
            country = row.get("Country") or "Unknown"
            city    = row.get("City") or ""
            count   = row["count"]

            # Collect set values from imploded columns
            def _set(key):
                v = row.get(f"_{key}_list")
                if v is None:
                    return set()
                return set(v) if isinstance(v, list) else set()

            data = {
                "lat": float(lat), "lon": float(lon),
                "count": count,
                "country": country,
                "city": city,
                "ips":        _set("ClientIP"),
                "users":      _set("UserId"),
                "orgs":       _set("Organization"),
                "operations": _set("Operation"),
                "asns":       _set("ASN"),
            }

            label  = f"{(city + ', ') if city else ''}{country}  ({count:,})"
            marker = self._map_widget.set_marker(
                float(lat), float(lon), text=label,
                marker_color_circle=tc["marker_inner"],
                marker_color_outside=tc["marker_outer"],
                text_color=tc["marker_text"],
                command=lambda m, d=data: self._on_marker_click(m, d),
                data=data,
            )
            self._markers.append(marker)

        if grouped is not None and len(grouped) > 0:
            self.after(200, self._zoom_to_markers)

    def _clear_map_markers(self):
        for m in self._markers:
            try:
                m.delete()
            except Exception:
                pass
        self._markers.clear()
        self._detail_box.configure(state="normal")
        self._detail_box.delete("1.0", "end")
        self._detail_box.configure(state="disabled")

    def _zoom_to_markers(self):
        if not self._markers or self._map_widget is None:
            return
        lats = [m.position[0] for m in self._markers if m.position]
        lons = [m.position[1] for m in self._markers if m.position]
        if not lats:
            return
        clat = (min(lats) + max(lats)) / 2
        clon = (min(lons) + max(lons)) / 2
        span = max(max(lats) - min(lats), max(lons) - min(lons), 0.5)
        zoom = max(1, min(10, int(math.log2(360 / span))))
        self._map_widget.set_position(clat, clon)
        self._map_widget.set_zoom(zoom)

    def _on_marker_click(self, marker, data: Dict):
        self._detail_box.configure(state="normal")
        self._detail_box.delete("1.0", "end")

        country  = data.get("country", "Unknown")
        city     = data.get("city", "")
        count    = data.get("count", 0)
        ips      = sorted(data.get("ips",  set()))
        users    = sorted(data.get("users", set()))
        orgs     = sorted(data.get("orgs",  set()))
        ops      = sorted(data.get("operations", set()))
        asns     = sorted(data.get("asns",  set()))
        lat, lon = data.get("lat", 0), data.get("lon", 0)
        loc      = f"{(city + ', ') if city else ''}{country}"

        def _w(text):
            self._detail_box.insert("end", text)

        def _sec(title, items, limit=8):
            if not items:
                return
            _w(f"\n▸ {title}\n")
            for item in items[:limit]:
                _w(f"  {item}\n")
            if len(items) > limit:
                _w(f"  … +{len(items) - limit} more\n")

        _w(f"{'─' * 30}\n  📍 {loc}\n{'─' * 30}\n")
        _w(f"  Events    {count:,}\n")
        _w(f"  Lat/Lon   {lat:.4f}, {lon:.4f}\n")
        _sec("Client IPs", ips)
        _sec("Users", users)
        _sec("ASNs", asns)
        _sec("Organisations", list(orgs))
        _sec("Operations", ops)
        self._detail_box.configure(state="disabled")

    def _map_copy_coords(self, coords: Tuple[float, float]):
        lat, lon = coords
        text = f"{lat:.6f}, {lon:.6f}"
        self.clipboard_clear()
        self.clipboard_append(text)
        self._log(f"Copied: {text}")

    def _change_tile_server(self, selection: str):
        if self._map_widget is None:
            return
        url, max_zoom = TILE_SERVERS.get(selection, TILE_SERVERS["OpenStreetMap"])
        self._map_widget.set_tile_server(url, max_zoom=max_zoom)
        self._log(f"Tile server → {selection}")

    # ─────────────────────────────────────────────────────────────────────────
    # Table
    # ─────────────────────────────────────────────────────────────────────────
    # ─────────────────────────────────────────────────────────────────────────
    # Impossible Travel Detection
    # ─────────────────────────────────────────────────────────────────────────
    # Time window: events from the same session/token in different countries
    # within this many minutes are flagged as impossible travel.
    # How long (minutes) between logins from different countries
    # before we consider physical travel impossible.
    # A commercial flight between major hubs is rarely < 2 hours,
    # and most BEC login pairs occur within minutes.
    _IMP_TRAVEL_WINDOW_MIN = 120

    def _compute_impossible_travel(self, df) -> dict:
        """
        Detect impossible travel from UserLoggedIn events only.

        Logic:
          1. Filter df to Operation == "UserLoggedIn"
          2. Group by UserId
          3. Sort each user's logins by CreationDate
          4. Walk consecutive pairs — if country changes within
             _IMP_TRAVEL_WINDOW_MIN minutes, both rows are flagged

        Returns a dict:
          {
            original_row_index: {
              "user":    str,
              "from":    str,   # country A
              "to":      str,   # country B
              "gap_min": float, # minutes between the two logins
              "ip_from": str,
              "ip_to":   str,
            },
            ...
          }
        The keys are row indices into *df* (the frame passed in).
        """
        result: dict = {}
        if not POLARS_AVAILABLE or df is None:
            return result
        if "Operation" not in df.columns or "UserId" not in df.columns \
                or "Country" not in df.columns or "CreationDate" not in df.columns:
            return result

        from datetime import datetime as _dt
        from collections import defaultdict

        try:
            # ── Step 1: filter to UserLoggedIn, attach original row index ────
            n_total = len(df)
            work = (
                df.with_columns(
                    pl.Series("_orig_idx", list(range(n_total)))
                )
                .filter(pl.col("Operation") == "UserLoggedIn")
                .filter(
                    pl.col("UserId").is_not_null() &
                    pl.col("Country").is_not_null()
                )
            )

            if len(work) == 0:
                return result

            ip_col = "ClientIP" if "ClientIP" in work.columns else None

            # ── Step 2: parse and group ───────────────────────────────────────
            cols_needed = ["_orig_idx", "UserId", "Country", "CreationDate"]
            if ip_col:
                cols_needed.append(ip_col)

            by_user: dict = defaultdict(list)
            for row in work.select(cols_needed).iter_rows(named=True):
                ts_raw = (row.get("CreationDate") or "")
                dt = None
                for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S",
                            "%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ"):
                    try:
                        dt = _dt.strptime(str(ts_raw)[:26], fmt)
                        break
                    except Exception:
                        continue
                by_user[row["UserId"]].append({
                    "idx":     row["_orig_idx"],
                    "country": row["Country"],
                    "dt":      dt,
                    "ip":      row.get(ip_col, "") if ip_col else "",
                })

            # ── Step 3: sort each user's logins, check consecutive pairs ──────
            window_secs = self._IMP_TRAVEL_WINDOW_MIN * 60

            for user, events in by_user.items():
                # Sort: events with no timestamp go last
                events.sort(key=lambda e: e["dt"] or _dt.max)

                for i in range(len(events) - 1):
                    a = events[i]
                    b = events[i + 1]
                    if a["country"] == b["country"]:
                        continue

                    # Calculate gap
                    gap_min: float = 0.0
                    if a["dt"] and b["dt"]:
                        gap_sec = abs((b["dt"] - a["dt"]).total_seconds())
                        gap_min = gap_sec / 60.0
                        if gap_sec > window_secs:
                            continue   # too far apart — not flagged
                    # else: no timestamps → always flag (country change, no time anchor)

                    detail = {
                        "user":    user,
                        "from":    a["country"],
                        "to":      b["country"],
                        "gap_min": round(gap_min, 1),
                        "ip_from": a["ip"] or "",
                        "ip_to":   b["ip"] or "",
                        "ts_from": str(a["dt"])[:19] if a["dt"] else "",
                        "ts_to":   str(b["dt"])[:19] if b["dt"] else "",
                    }
                    result[a["idx"]] = detail
                    result[b["idx"]] = detail

        except Exception as e:
            self._log(f"Impossible travel error: {e}")

        return result

    PRIORITY_COLS = [
        "CreationDate", "Operation", "UserId", "ClientIP",
        "Country", "City", "ASN", "Organization",
        "AppDisplayName", "UserAgent", "ResultStatus",
        "SessionId", "UniqueTokenId",
    ]
    HIDDEN_COLS  = {"AuditData", "Latitude", "Longitude"}
    _TABLE_LIMIT = 2000   # rows rendered in the live table
    def _on_search_changed(self, *_):
        """Debounce search: wait 300 ms after last keystroke."""
        if self._search_after_id:
            self.after_cancel(self._search_after_id)
        self._search_after_id = self.after(300, self._refresh_table)

    def _refresh_table(self):
        df = self._fdf if self._fdf is not None else self._df
        if df is None:
            return

        search = getattr(self, "_search_var", None)
        search = search.get().lower().strip() if search else ""

        cols = [c for c in self.PRIORITY_COLS if c in df.columns]
        cols += [c for c in df.columns if c not in cols and c not in self.HIDDEN_COLS]

        # Only reconfigure headings when schema actually changes
        if cols != self._table_cols_cache:
            self._table_cols_cache = cols
            self._tree["columns"] = cols
            for col in cols:
                self._tree.heading(col, text=col,
                                   command=lambda c=col: self._sort_table(c))
                w = max(80, min(210, len(col) * 11 + 20))
                self._tree.column(col, width=w, minwidth=50)

        # Detach from layout — suppresses per-row screen redraws during bulk insert
        self._tree.grid_remove()

        # Fastest clear: delete all children in one call
        children = self._tree.get_children()
        if children:
            self._tree.delete(*children)

        total_df = len(df)
        limit    = self._TABLE_LIMIT

        try:
            if search and POLARS_AVAILABLE:
                # Search only priority/visible columns — not every column in the df
                search_cols = [c for c in self.PRIORITY_COLS if c in df.columns]
                mask = None
                for col in search_cols:
                    try:
                        s = (df[col].cast(pl.Utf8, strict=False)
                             .str.to_lowercase()
                             .str.contains(search, literal=True))
                        mask = s if mask is None else (mask | s)
                    except Exception:
                        pass
                view_df = df.filter(mask).head(limit) if mask is not None else df.head(limit)
            else:
                view_df = df.head(limit)

            # Impossible travel cache — keyed by id of the base df
            cache_key = id(self._df)
            if cache_key not in getattr(self, "_imp_travel_cache", {}):
                self._imp_travel_cache = {cache_key: self._compute_impossible_travel(
                    self._df if self._df is not None else view_df)}
            imp_map = self._imp_travel_cache.get(cache_key, {})

            col_indices = [view_df.columns.index(c) for c in cols]

            # Pre-convert entire view to Python tuples in one Polars call —
            # much faster than calling str() per cell inside a Python loop.
            rows_raw = view_df.select(
                [pl.col(c).cast(pl.Utf8, strict=False).fill_null("") for c in cols]
            ).iter_rows()

            insert = self._tree.insert
            imp_tag = ("imp_travel",)
            no_tag  = ()
            for row_idx, raw in enumerate(rows_raw):
                insert("", "end", values=raw,
                       tags=imp_tag if row_idx in imp_map else no_tag)

            inserted = len(view_df)
        except Exception as _e:
            self._log(f"Table render error: {_e}")
            inserted = 0

        # Re-attach
        self._tree.grid(row=0, column=0, sticky="nsew")

        if search:
            self._row_lbl.configure(text=f"{inserted:,} / {total_df:,} rows matched")
        elif total_df > limit:
            self._row_lbl.configure(text=f"{inserted:,} of {total_df:,} rows  (scroll to load more)")
        else:
            self._row_lbl.configure(text=f"{inserted:,} rows")

    def _sort_table(self, col: str):
        df = self._fdf if self._fdf is not None else self._df
        if df is None:
            return
        try:
            asc = self._sort_state.get(col, True)
            sorted_df = df.sort(col, descending=not asc, nulls_last=True)
            self._fdf = sorted_df
            self._sort_state[col] = not asc
            self._refresh_table()
        except Exception:
            pass

    def _toggle_imp_travel(self):
        """
        Filter Data Table to UserLoggedIn rows with impossible travel, or clear.
        When active, only the flagged rows are shown and each is highlighted.
        The log shows a per-user summary of what was detected.
        """
        tc = self._tc
        df = self._df
        if df is None:
            return

        self._imp_travel_active = not self._imp_travel_active

        if self._imp_travel_active:
            # Run detection on the full dataset
            imp_map = self._compute_impossible_travel(df)

            if not imp_map:
                self._imp_travel_active = False
                self._imp_btn.configure(
                    fg_color="transparent",
                    text_color=tc["status_err"],
                    border_color=tc["status_err"],
                    text="⚠  IMP. TRAVEL")
                try:
                    no_logins = ("Operation" not in df.columns or
                                 df.filter(pl.col("Operation") == "UserLoggedIn").is_empty())
                except Exception:
                    no_logins = True
                if no_logins:
                    msg = ("No UserLoggedIn events found.\n\n"
                           "Impossible travel detection requires UserLoggedIn "
                           "operations with Country and CreationDate fields.")
                else:
                    msg = ("No impossible travel detected in UserLoggedIn events.\n\n"
                           f"Window: {self._IMP_TRAVEL_WINDOW_MIN} minutes. "
                           "All logins from the same user appeared from "
                           "the same country within the time window.")
                messagebox.showinfo("No Impossible Travel", msg, parent=self)
                return

            # Slice df to only the flagged rows
            flagged_indices = sorted(imp_map.keys())
            try:
                self._fdf = df[flagged_indices]
            except Exception as e:
                self._log(f"Impossible travel filter error: {e}")
                self._imp_travel_active = False
                return

            # Log a per-user summary
            seen_users: dict = {}
            for detail in imp_map.values():
                u = detail["user"]
                if u not in seen_users:
                    seen_users[u] = detail
            self._log(f"⚠ Impossible travel: {len(imp_map)} flagged events, "
                      f"{len(seen_users)} user(s)")
            for user, d in seen_users.items():
                gap = f"{d['gap_min']} min" if d['gap_min'] else "unknown gap"
                self._log(f"  → {user}: {d['from']} → {d['to']} ({gap})")

            self._imp_btn.configure(
                fg_color=tc["status_err"],
                text_color="#FFFFFF",
                border_color=tc["status_err"],
                text="⚠  IMP. TRAVEL  ×")

            n = len(self._fdf)
            self._row_lbl.configure(
                text=f"{n} impossible travel event(s) — {len(seen_users)} user(s)")

        else:
            # Clear — restore operation filter
            self._imp_btn.configure(
                fg_color="transparent",
                text_color=tc["status_err"],
                border_color=tc["status_err"],
                text="⚠  IMP. TRAVEL")
            self._apply_filter()
            return

        self._refresh_table()

    def _on_table_click(self, event):
        """Single-click: pan map to the row's location without switching tabs."""
        sel = self._tree.selection()
        if not sel or self._map_widget is None:
            return
        vals = self._tree.item(sel[0], "values")
        cols = list(self._tree["columns"])
        rd   = dict(zip(cols, vals))

        # Prefer exact GeoIP coordinates, fall back to country centroid
        lat = lon = None
        try:
            if rd.get("Latitude") and rd.get("Longitude"):
                lat = float(rd["Latitude"])
                lon = float(rd["Longitude"])
        except (ValueError, TypeError):
            pass
        if lat is None:
            country = rd.get("Country", "")
            if country and country in COUNTRY_COORDS:
                lat, lon = COUNTRY_COORDS[country]
        if lat is not None and lon is not None:
            self._map_widget.set_position(lat, lon)
            if getattr(self._map_widget, "zoom", 2) < 4:
                self._map_widget.set_zoom(5)

    def _on_table_double_click(self, event):
        """Double-click: open a detail popup showing all fields for this row."""
        sel = self._tree.selection()
        if not sel:
            return
        vals = self._tree.item(sel[0], "values")
        cols = list(self._tree["columns"])
        rd   = dict(zip(cols, vals))

        tc   = self._tc
        mono = MONO
        pop  = ctk.CTkToplevel(self)
        pop.title("Row Detail")
        pop.geometry("700x540")
        pop.configure(fg_color=tc["bg"])
        pop.grab_set()
        pop.grid_rowconfigure(1, weight=1)
        pop.grid_columnconfigure(0, weight=1)

        # Header
        hdr = ctk.CTkFrame(pop, fg_color=tc["panel"], corner_radius=0, height=36)
        hdr.grid(row=0, column=0, sticky="ew")
        hdr.grid_propagate(False)
        hdr.grid_columnconfigure(1, weight=1)
        ctk.CTkFrame(hdr, fg_color=tc["accent"], width=3,
                     corner_radius=0).grid(row=0, column=0, sticky="ns")
        ts = rd.get("CreationDate", "") or rd.get("CreationTime", "")
        op = rd.get("Operation", "Row Detail")
        ctk.CTkLabel(hdr, text=f"{op}  ·  {ts}",
                     font=ctk.CTkFont(family=mono, size=11, weight="bold"),
                     text_color=tc["text_bright"]).grid(
            row=0, column=1, padx=12, pady=10, sticky="w")
        ctk.CTkButton(hdr, text="CLOSE", width=60, height=24,
                      fg_color="transparent", hover_color=tc["border"],
                      text_color=tc["text_dim"], border_color=tc["border"],
                      border_width=1, corner_radius=2,
                      font=ctk.CTkFont(family=mono, size=9),
                      command=pop.destroy).grid(
            row=0, column=2, padx=12, pady=6, sticky="e")
        ctk.CTkFrame(pop, fg_color=tc["border"], height=1,
                     corner_radius=0).grid(row=0, column=0, sticky="sew")

        # Scrollable field list
        scroll = ctk.CTkScrollableFrame(pop, fg_color=tc["bg"],
                                         scrollbar_button_color=tc["border"])
        scroll.grid(row=1, column=0, sticky="nsew", padx=0, pady=0)
        scroll.grid_columnconfigure(1, weight=1)

        # BEC-relevant fields highlighted
        highlight = {"ClientIP", "Country", "Operation", "UserId",
                     "SessionId", "UniqueTokenId", "UserAgent", "Organization"}
        sev_ops   = set(self._BEC_OP_SEVERITY.keys())

        # Pull raw_json AuditData if available for full detail
        raw_json_str = None
        df = self._fdf if self._fdf is not None else self._df
        if df is not None and "AuditData" in df.columns:
            # Find the matching row by CreationDate + UserId
            try:
                filters = []
                if rd.get("CreationDate") and "CreationDate" in df.columns:
                    filters.append(pl.col("CreationDate").cast(pl.Utf8) == rd["CreationDate"])
                if rd.get("UserId") and "UserId" in df.columns:
                    filters.append(pl.col("UserId") == rd["UserId"])
                if filters:
                    mask = filters[0]
                    for f in filters[1:]: mask = mask & f
                    match = df.filter(mask).head(1)
                    if len(match) > 0:
                        raw_json_str = match["AuditData"][0]
            except Exception:
                pass

        for i, (col, val) in enumerate(rd.items()):
            is_hl  = col in highlight
            is_sev = (col == "Operation" and val in sev_ops)
            fg_key = tc["text_bright"] if is_hl else tc["text_dim"]
            sev    = self._BEC_OP_SEVERITY.get(val, "") if is_sev else ""
            row_bg = tc["card"] if i % 2 == 0 else tc["panel"]

            rf = ctk.CTkFrame(scroll, fg_color=row_bg, corner_radius=0)
            rf.grid(row=i, column=0, columnspan=2, sticky="ew", pady=0)
            rf.grid_columnconfigure(1, weight=1)
            ctk.CTkLabel(rf, text=col,
                         font=ctk.CTkFont(family=mono, size=10, weight="bold"),
                         text_color=tc["text_dim"],
                         width=160, anchor="e").grid(
                row=0, column=0, padx=(10, 8), pady=4, sticky="e")
            val_text = "" if val is None else str(val)
            label_color = (tc["status_err"] if sev in ("CRITICAL","HIGH")
                           else tc["accent4"] if sev == "MEDIUM"
                           else fg_key)
            ctk.CTkLabel(rf, text=val_text,
                         font=ctk.CTkFont(family=mono, size=10),
                         text_color=label_color,
                         anchor="w", wraplength=460).grid(
                row=0, column=1, padx=(0, 10), pady=4, sticky="w")

        # Raw AuditData JSON if available
        if raw_json_str:
            i_raw = len(rd)
            sep = ctk.CTkFrame(scroll, fg_color=tc["border"], height=1, corner_radius=0)
            sep.grid(row=i_raw, column=0, columnspan=2, sticky="ew", pady=4)
            ctk.CTkLabel(scroll, text="RAW AUDITDATA",
                         font=ctk.CTkFont(family=mono, size=9, weight="bold"),
                         text_color=tc["text_dim"]).grid(
                row=i_raw+1, column=0, columnspan=2, padx=12, pady=(4,2), sticky="w")
            try:
                import json as _json
                formatted = _json.dumps(_json.loads(raw_json_str), indent=2)
            except Exception:
                formatted = raw_json_str or ""
            txt = ctk.CTkTextbox(scroll, fg_color=tc["panel"],
                                  text_color=tc["text_dim"],
                                  font=ctk.CTkFont(family=mono, size=9),
                                  height=200, wrap="none")
            txt.grid(row=i_raw+2, column=0, columnspan=2,
                     sticky="ew", padx=8, pady=(0, 8))
            txt.insert("1.0", formatted)
            txt.configure(state="disabled")

    # ─────────────────────────────────────────────────────────────────────────
    # Summary
    # ─────────────────────────────────────────────────────────────────────────
    def _refresh_summary(self):
        df = self._df
        if df is None:
            return
        # Skip rebuild if data and theme haven't changed
        cache_key = (id(df), len(df), self._mode)
        if getattr(self, "_summary_cache_key", None) == cache_key:
            return
        self._summary_cache_key = cache_key

        for w in self._summary_frame.winfo_children():
            w.destroy()

        tc = self._tc
        ri = 0

        def stat_card(title, value, sub="", row=0, col=0, color=None):
            c = ctk.CTkFrame(self._summary_frame, fg_color=tc["card"], corner_radius=10)
            c.grid(row=row, column=col, padx=6, pady=6, sticky="nsew")
            c.grid_columnconfigure(0, weight=1)
            clr = color or tc["accent"]
            ctk.CTkLabel(c, text=title, font=ctk.CTkFont(size=11),
                         text_color=tc["text_dim"]).grid(
                row=0, padx=14, pady=(12, 2), sticky="w")
            ctk.CTkLabel(c, text=str(value),
                         font=ctk.CTkFont(size=26, weight="bold"),
                         text_color=clr).grid(
                row=1, padx=14, pady=(0, 2), sticky="w")
            ctk.CTkLabel(c, text=sub, font=ctk.CTkFont(size=10),
                         text_color=tc["text_dim"]).grid(
                row=2, padx=14, pady=(0, 12), sticky="w")

        def hr():
            nonlocal ri
            ctk.CTkFrame(self._summary_frame, fg_color=tc["border"], height=1).grid(
                row=ri, column=0, columnspan=2, padx=6, pady=6, sticky="ew")
            ri += 1

        def sh(title):
            nonlocal ri
            hr()
            ctk.CTkLabel(self._summary_frame, text=title,
                         font=ctk.CTkFont(size=10, weight="bold"),
                         text_color=tc["text_dim"]).grid(
                row=ri, column=0, columnspan=2, padx=12, pady=(4, 4), sticky="w")
            ri += 1

        # Overview row
        ctk.CTkLabel(self._summary_frame, text="OVERVIEW",
                     font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=tc["text_dim"]).grid(
            row=ri, column=0, columnspan=2, padx=12, pady=(10, 4), sticky="w")
        ri += 1
        stat_card("Total Events", f"{len(df):,}", "enriched rows", row=ri, col=0)
        if "UserId" in df.columns:
            try:
                stat_card("Unique Users",
                          f"{df['UserId'].drop_nulls().n_unique():,}",
                          "distinct userIds", row=ri, col=1, color=tc["accent3"])
            except Exception:
                pass
        ri += 1
        if "ClientIP" in df.columns:
            try:
                stat_card("Unique IPs",
                          f"{df['ClientIP'].drop_nulls().n_unique():,}",
                          "distinct IPs", row=ri, col=0, color=tc["accent2"])
            except Exception:
                pass
        if "Country" in df.columns:
            try:
                stat_card("Countries",
                          f"{df['Country'].drop_nulls().n_unique():,}",
                          "geo locations", row=ri, col=1, color=tc["accent"])
            except Exception:
                pass
        ri += 1

        def bar_list(col_name, grp_cols, label_fn, color, limit=15, image_fn=None, label_w=320):
            nonlocal ri
            try:
                agg = (df.filter(pl.col(col_name).is_not_null())
                       .group_by(grp_cols)
                       .agg(pl.len().alias("n"))
                       .sort("n", descending=True)
                       .head(limit))
                max_n = agg["n"].max() or 1
                for agg_row in agg.iter_rows(named=True):
                    n     = agg_row["n"]
                    label = label_fn(agg_row)
                    img   = image_fn(agg_row) if image_fn else None

                    # Hard-truncate label to 48 chars so no text overflows
                    # the fixed column and pushes the bar start point.
                    MAX_CHARS = 48
                    if len(label) > MAX_CHARS:
                        label = label[:MAX_CHARS - 1] + "…"

                    rf = ctk.CTkFrame(self._summary_frame, fg_color=tc["card"], corner_radius=6)
                    rf.grid(row=ri, column=0, columnspan=2, padx=6, pady=2, sticky="ew")

                    # Strict fixed-column layout — only col 2 (bar) expands.
                    # Columns 0,1,3 are fixed-size so every bar in the list
                    # starts and ends at the same x-position.
                    FLAG_W  = 28   # flag image slot
                    LABEL_W = label_w
                    COUNT_W = 62   # event count
                    rf.grid_columnconfigure(0, weight=0, minsize=FLAG_W)
                    rf.grid_columnconfigure(1, weight=0, minsize=LABEL_W)
                    rf.grid_columnconfigure(2, weight=1)   # bar — expands
                    rf.grid_columnconfigure(3, weight=0, minsize=COUNT_W)

                    # col 0 width is reserved by minsize on grid_columnconfigure;
                    # only place a widget there when we actually have a flag.
                    if img is not None:
                        ctk.CTkLabel(rf, text="", image=img, width=FLAG_W).grid(
                            row=0, column=0, padx=(6, 2), pady=5, sticky="w")

                    ctk.CTkLabel(rf, text=label, font=ctk.CTkFont(size=11),
                                 text_color=tc["text"],
                                 width=LABEL_W, anchor="w").grid(
                        row=0, column=1, padx=(4, 6), pady=5, sticky="w")

                    pb = ctk.CTkProgressBar(rf, height=7,
                                           fg_color=tc["border"],
                                           progress_color=color)
                    pb.grid(row=0, column=2, padx=(0, 8), pady=5, sticky="ew")
                    pb.set(n / max_n)

                    ctk.CTkLabel(rf, text=f"{n:,}",
                                 font=ctk.CTkFont(size=11, weight="bold"),
                                 text_color=color, width=COUNT_W, anchor="e").grid(
                        row=0, column=3, padx=(0, 10), pady=5)
                    ri += 1
            except Exception as e:
                ctk.CTkLabel(self._summary_frame, text=f"Error: {e}",
                             text_color=tc["status_err"]).grid(
                    row=ri, column=0, columnspan=2)
                ri += 1

        if "Operation" in df.columns:
            sh("TOP OPERATIONS")
            bar_list("Operation", ["Operation"],
                     lambda r: r["Operation"] or "Unknown", tc["accent"],
                     limit=12, label_w=200)

        if "ClientIP" in df.columns:
            sh("TOP CLIENT IPs")
            grp = ["ClientIP"]
            if "Country"      in df.columns: grp.append("Country")
            if "Organization" in df.columns: grp.append("Organization")

            def ip_label(r):
                ip  = r.get("ClientIP", "")
                cty = r.get("Country", "") or ""
                org = (r.get("Organization") or "")[:30]
                return f"{ip}  {cty}{('  · ' + org) if org else ''}"
            def ip_image(r):
                return _flag_image(r.get("Country", "") or "")

            bar_list("ClientIP", grp, ip_label, tc["accent2"], image_fn=ip_image)

        if "UserId" in df.columns:
            sh("TOP USERS")
            bar_list("UserId", ["UserId"], lambda r: r["UserId"] or "", tc["accent3"])

        if "Country" in df.columns:
            sh("TOP COUNTRIES")
            bar_list("Country", ["Country"],
                     lambda r: r["Country"] or "Unknown",
                     tc["accent4"],
                     image_fn=lambda r: _flag_image(r["Country"] or ""))

    # ─────────────────────────────────────────────────────────────────────────
    # Generate Report
    # ─────────────────────────────────────────────────────────────────────────
    def _generate_report(self):
        """Generate a self-contained HTML investigation report from the current case."""
        df = self._fdf if self._fdf is not None else self._df
        if df is None:
            messagebox.showwarning("No Data", "Run enrichment first.", parent=self)
            return

        from datetime import datetime as _dt
        import html as _html

        # ── Choose save path ─────────────────────────────────────────────────
        default_name = "ThreadHunter_Report"
        if self._case:
            safe = "".join(c if c.isalnum() or c in " _-" else "_"
                           for c in self._case.name)
            default_name = f"{safe}_Report"

        out_path = filedialog.asksaveasfilename(
            defaultextension=".html",
            filetypes=[("HTML Report", "*.html")],
            initialfile=default_name,
            title="Save Investigation Report")
        if not out_path:
            return

        self._log("Generating report\u2026")

        try:
            # ── Gather metadata ───────────────────────────────────────────────
            case_name    = self._case.name      if self._case else "Untitled"
            case_client  = self._case.client    if self._case else ""
            case_analyst = self._case.analyst   if self._case else ""
            case_created = self._case.created_at if self._case else ""
            generated_at = _dt.now().strftime("%Y-%m-%d %H:%M:%S")
            total_events = len(df)
            iocs         = self._case.get_iocs()  if self._case else []
            notes        = self._case.get_notes() if self._case else []
            imp_map      = self._compute_impossible_travel(df)

            def _vc(col, agg_col="count"):
                """Value counts for a column, returns list of dicts."""
                if col not in df.columns:
                    return []
                try:
                    return (df[col].drop_nulls()
                            .value_counts()
                            .sort(agg_col, descending=True)
                            .head(12)
                            .iter_rows(named=True))
                except Exception:
                    return []

            top_ops       = list(_vc("Operation"))
            top_ips       = list(_vc("ClientIP"))
            top_users     = list(_vc("UserId"))
            top_countries = list(_vc("Country"))

            # Impossible travel sample rows (up to 100)
            unique_users = df["UserId"].n_unique()  if "UserId"   in df.columns else 0
            unique_ips   = df["ClientIP"].n_unique() if "ClientIP" in df.columns else 0

            def esc(v):
                return _html.escape(str(v)) if v is not None else ""

            def sev_badge(op):
                sev = self._BEC_OP_SEVERITY.get(op, "")
                c = {"CRITICAL": ("#FF4D6D","#2d0010"),
                     "HIGH":     ("#F59E0B","#2d1a00"),
                     "MEDIUM":   ("#3B82F6","#001030"),
                     "LOW":      ("#64748B","#111")}.get(sev)
                if c:
                    return (f'<span style="background:{c[1]};color:{c[0]};'
                            f'padding:1px 7px;border-radius:3px;font-size:10px;'
                            f'font-weight:bold;border:1px solid {c[0]}">{sev}</span>')
                return ""

            def stat_box(label, val, color="#3B82F6"):
                return (f'<div class="sb"><div class="sv" style="color:{color}">'
                        f'{esc(str(val))}</div>'
                        f'<div class="sl">{esc(label)}</div></div>')

            def tbl(rows, cols):
                h = "".join(f"<th>{esc(c)}</th>" for c in cols)
                body = ""
                for r in rows:
                    body += "<tr>" + "".join(
                        f"<td>{esc(r.get(c) if isinstance(r, dict) else '')}</td>"
                        for c in cols) + "</tr>"
                return f"<table><tr>{h}</tr>{body}</table>" if body else "<p class='dim'>No data.</p>"

            def sec(title, body):
                return (f'<div class="sec">'
                        f'<div class="sh">{esc(title)}</div>'
                        f'<div class="sb2">{body}</div></div>')

            # ── Stats row ─────────────────────────────────────────────────────
            stats_html = '<div class="srow">'
            stats_html += stat_box("Total Events",       f"{total_events:,}")
            stats_html += stat_box("Unique Users",        unique_users,   "#10B981")
            stats_html += stat_box("Unique IPs",          unique_ips,     "#10B981")
            stats_html += stat_box("IOCs",                len(iocs),      "#EF4444")
            stats_html += stat_box("Impossible Travel",   len(set(d["user"] for d in imp_map.values())),"#F59E0B")
            stats_html += '</div>'

            # ── Operations ────────────────────────────────────────────────────
            ops_rows = ""
            for r in top_ops:
                op = r.get("Operation") or ""
                ct = r.get("count", 0)
                ops_rows += f"<tr><td>{esc(op)}</td><td>{ct:,}</td><td>{sev_badge(op)}</td></tr>"
            ops_html = (f"<table><tr><th>Operation</th><th>Count</th><th>Severity</th></tr>"
                        f"{ops_rows}</table>") if ops_rows else "<p class='dim'>No data.</p>"

            # ── IPs ───────────────────────────────────────────────────────────
            ips_rows = "".join(
                f"<tr><td>{esc(r.get('ClientIP',''))}</td><td>{r.get('count',0):,}</td></tr>"
                for r in top_ips)
            ips_html = (f"<table><tr><th>IP Address</th><th>Events</th></tr>{ips_rows}</table>"
                        if ips_rows else "<p class='dim'>No data.</p>")

            # ── Users ─────────────────────────────────────────────────────────
            usr_rows = "".join(
                f"<tr><td>{esc(r.get('UserId',''))}</td><td>{r.get('count',0):,}</td></tr>"
                for r in top_users)
            usr_html = (f"<table><tr><th>User</th><th>Events</th></tr>{usr_rows}</table>"
                        if usr_rows else "<p class='dim'>No data.</p>")

            # ── Countries ─────────────────────────────────────────────────────
            def _cty_cell(name):
                iso2 = _COUNTRY_ISO2.get(name or "", "")
                if iso2:
                    png_path = _FLAGS_DIR / f"{iso2}.png"
                    if png_path.exists():
                        import base64 as _b64
                        b64 = _b64.b64encode(png_path.read_bytes()).decode()
                        img_tag = (f'<img src="data:image/png;base64,{b64}" '
                                   f'width="20" height="15" style="vertical-align:middle;margin-right:6px">')
                        return f'{img_tag}{esc(name)}'
                return esc(name or "")
            cty_rows = "".join(
                f"<tr><td>{_cty_cell(r.get('Country',''))}</td><td>{r.get('count',0):,}</td></tr>"
                for r in top_countries)
            cty_html = (f"<table><tr><th>Country</th><th>Events</th></tr>{cty_rows}</table>"
                        if cty_rows else "<p class='dim'>No data.</p>")

            # ── Impossible travel ─────────────────────────────────────────────
            if imp_map:
                # De-duplicate by user — one summary row per user pair
                seen = {}
                for idx, d in imp_map.items():
                    key = (d["user"], d["from"], d["to"])
                    if key not in seen:
                        seen[key] = d
                imp_summary_rows = list(seen.values())
                imp_cols = ["user", "from", "to", "gap_min",
                            "ip_from", "ip_to", "ts_from", "ts_to"]
                # Build manually so from/to columns get flag emojis
                imp_tbl_rows = ""
                for d in imp_summary_rows:
                    frm  = d.get("from", "")
                    to   = d.get("to", "")
                    def _imp_cty(c):
                        return _cty_cell(c)
                    imp_tbl_rows += (
                        f'<tr class="imp"><td>{esc(d.get("user",""))}</td>'
                        f'<td>{_imp_cty(frm)}</td>'
                        f'<td>{_imp_cty(to)}</td>'
                        f'<td>{esc(str(d.get("gap_min","")))}</td>'
                        f'<td>{esc(d.get("ip_from",""))}</td>'
                        f'<td>{esc(d.get("ip_to",""))}</td>'
                        f'<td>{esc(d.get("ts_from",""))}</td>'
                        f'<td>{esc(d.get("ts_to",""))}</td></tr>'
                    )
                imp_html = (f"<table><tr>"
                            + "".join(f"<th>{esc(c)}</th>" for c in imp_cols)
                            + f"</tr>{imp_tbl_rows}</table>")
                imp_html += (f"<p class='dim' style='margin-top:8px'>"
                             f"UserLoggedIn events where the same account "
                             f"appeared from different countries within "
                             f"{self._IMP_TRAVEL_WINDOW_MIN} minutes.</p>")
            else:
                imp_html = "<p class='dim'>No impossible travel detected in UserLoggedIn events.</p>"

            # ── IOCs ──────────────────────────────────────────────────────────
            if iocs:
                ioc_rows = "".join(
                    f"<tr><td>{esc(i.get('ioc_type',''))}</td>"
                    f"<td>{esc(i.get('value',''))}</td>"
                    f"<td>{esc(i.get('confidence',''))}</td>"
                    f"<td>{esc(i.get('description',''))}</td>"
                    f"<td>{esc((i.get('added_at') or '')[:10])}</td></tr>"
                    for i in iocs)
                ioc_html = (f"<table><tr><th>Type</th><th>Value</th>"
                            f"<th>Confidence</th><th>Description</th><th>Added</th></tr>"
                            f"{ioc_rows}</table>")
            else:
                ioc_html = "<p class='dim'>No IOCs recorded.</p>"

            # ── Notes ─────────────────────────────────────────────────────────
            if notes:
                notes_html = "".join(
                    f'<div class="note">'
                    f'<div class="nm">{esc((n.get("section") or "general").upper())} '
                    f'\u00b7 {esc((n.get("created_at") or "")[:16])}</div>'
                    f'<div class="nc">{esc(n.get("content",""))}</div>'
                    f'</div>'
                    for n in notes)
            else:
                notes_html = "<p class='dim'>No analyst notes.</p>"

            # ── HTML shell ────────────────────────────────────────────────────
            meta_parts = []
            if case_analyst: meta_parts.append(f"Analyst: {esc(case_analyst)}")
            if case_client:  meta_parts.append(f"Client: {esc(case_client)}")
            if case_created: meta_parts.append(f"Opened: {esc(case_created[:10])}")
            meta_parts.append(f"Generated: {esc(generated_at)}")
            meta_str = "  \u00b7  ".join(meta_parts)

            html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>ThreadHunter \u2014 {esc(case_name)}</title>
<style>
:root{{--bg:#0A0C0F;--panel:#0F1217;--card:#141820;--brd:#1E2535;
  --brdl:#2A3548;--acc:#3B82F6;--red:#EF4444;--amb:#F59E0B;
  --grn:#10B981;--txt:#E2E8F0;--dim:#64748B;--mut:#334155;
  --mono:"Courier New",monospace}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:var(--bg);color:var(--txt);font-family:var(--mono);
  font-size:12px;line-height:1.6}}
.hdr{{background:var(--panel);border-bottom:2px solid var(--brdl);
  padding:28px 40px 22px}}
.brand{{color:var(--acc);font-size:10px;font-weight:bold;
  letter-spacing:3px;margin-bottom:8px}}
.title{{font-size:22px;font-weight:bold;color:#F8FAFC;margin-bottom:6px}}
.meta{{color:var(--dim);font-size:11px}}
.wrap{{max-width:1200px;margin:0 auto;padding:32px 40px}}
.sec{{margin-bottom:36px}}
.sh{{font-size:10px;font-weight:bold;letter-spacing:2px;
  color:var(--dim);text-transform:uppercase;padding-bottom:8px;
  border-bottom:1px solid var(--brd);margin-bottom:14px}}
.sb2{{}}
.srow{{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:4px}}
.sb{{background:var(--card);border:1px solid var(--brdl);
  border-radius:6px;padding:16px 22px;min-width:130px}}
.sv{{font-size:28px;font-weight:bold}}
.sl{{color:var(--dim);font-size:10px;margin-top:4px;
  text-transform:uppercase;letter-spacing:1px}}
.two{{display:grid;grid-template-columns:1fr 1fr;gap:24px}}
@media(max-width:800px){{.two{{grid-template-columns:1fr}}}}
table{{width:100%;border-collapse:collapse;background:var(--card);
  border:1px solid var(--brd);overflow:hidden}}
th{{background:var(--panel);color:var(--dim);font-size:9px;font-weight:bold;
  letter-spacing:1px;text-transform:uppercase;padding:8px 12px;
  text-align:left;border-bottom:1px solid var(--brd)}}
td{{padding:6px 12px;border-bottom:1px solid var(--brd);
  word-break:break-all}}
tr:last-child td{{border-bottom:none}}
tr.imp td{{background:#200800;color:#FCA5A5}}
.note{{background:var(--card);border:1px solid var(--brd);
  border-left:3px solid var(--acc);border-radius:4px;
  padding:12px 16px;margin-bottom:10px}}
.nm{{color:var(--dim);font-size:10px;margin-bottom:5px}}
.nc{{white-space:pre-wrap}}
.dim{{color:var(--dim);font-style:italic}}
.ftr{{border-top:1px solid var(--brd);padding:18px 40px;
  color:var(--mut);font-size:10px;text-align:center;margin-top:24px}}
.conf{{background:#1a0a00;border:1px solid #92400e;color:#fbbf24;
  font-size:10px;font-weight:bold;letter-spacing:2px;text-align:center;
  padding:8px 40px;text-transform:uppercase}}
</style>
</head>
<body>
<div class="conf">&#9888;&#xFE0E;  Confidential &mdash; Contains Personal Information &mdash; Handle in Accordance with Engagement Data Handling Policy  &#9888;&#xFE0E;</div>
<div class="hdr">
  <div class="brand">\u25ce THREADHUNTER \u2014 BEC FORENSICS</div>
  <div class="title">{esc(case_name)}</div>
  <div class="meta">{meta_str}</div>
</div>
<div class="wrap">
  {sec("Executive Summary", stats_html)}
  {sec("Operation Breakdown", ops_html)}
  <div class="two">
    {sec("Top Source IPs", ips_html)}
    {sec("Top Users", usr_html)}
  </div>
  {sec("Geographic Distribution", cty_html)}
  {sec("Impossible Travel", imp_html)}
  {sec("IOC Watchlist", ioc_html)}
  {sec("Analyst Notes", notes_html)}
</div>
<div class="ftr" style="text-align:left;padding:14px 40px 6px"><span style="color:#92400e;font-weight:bold">PRIVACY NOTICE</span> &mdash; This report contains personal information derived from Microsoft 365 audit logs. Distribution must be limited to authorised personnel. Retain and dispose of in accordance with applicable privacy law and your engagement data handling policy.</div>
<div class="ftr">ThreadHunter BEC Forensics \u00b7 {esc(generated_at)} \u00b7 {total_events:,} events analysed</div>
</body>
</html>"""

            with open(out_path, "w", encoding="utf-8") as fh:
                fh.write(html)

            self._log(f"\u2714 Report saved: {Path(out_path).name}")
            messagebox.showinfo("Report Saved",
                                f"Saved to:\n{out_path}\n\nOpening in browser\u2026",
                                parent=self)
            try:
                import webbrowser
                webbrowser.open(Path(out_path).as_uri())
            except Exception:
                pass

        except Exception as e:
            import traceback
            self._log(f"Report error: {e}\n{traceback.format_exc()[:400]}")
            messagebox.showerror("Report Error", str(e)[:600], parent=self)

    # ─────────────────────────────────────────────────────────────────────────
    # Log helpers
    # ─────────────────────────────────────────────────────────────────────────
    def _log(self, msg: str):
        """Push a log message onto the queue — written in the next poll tick.
        This keeps the main thread free; _poll_queues batches all pending
        messages into a single textbox write.
        """
        self._log_q.put(("log", "INFO", str(msg)))

    def _clear_log(self):
        self._log_box.configure(state="normal")
        self._log_box.delete("1.0", "end")
        self._log_box.configure(state="disabled")

    # ─────────────────────────────────────────────────────────────────────────
    # Theme switching
    # ─────────────────────────────────────────────────────────────────────────
    def _set_theme(self, mode: str):
        if mode == self._mode:
            return
        stash = dict(
            df=self._df, fdf=self._fdf, ioc_df=self._ioc_df,
            ops=list(self._operations),
            op=([self._op_listbox.get(i) for i in self._op_listbox.curselection()]
                if hasattr(self, '_op_listbox') else []),
            op_all=(self._op_all_var.get()
                    if hasattr(self, '_op_all_var') else True),
            city_db=self._city_db_path, asn_db=self._asn_db_path,
            input_path=self._input_path, output_dir=self._output_dir,
            tile=self._tile_var.get(),
            fmt=self._fmt_var.get(),
            split=self._split_ops.get(),
            skip_geo=self._skip_geo.get(),
            ioc_vars={k: v.get() for k, v in self._ioc_vars.items()},
        )
        self._mode = mode
        self._tc   = THEME[mode]
        ctk.set_appearance_mode("dark" if mode == "dark" else "light")

        for w in self.winfo_children():
            w.destroy()

        self._markers           = []
        self._sort_state        = {}
        self._search_var        = ctk.StringVar()
        self._table_cols_cache  = []
        self._summary_cache_key = None
        self._imp_travel_active = False
        self._imp_travel_cache  = {}
        self._op_updating       = False
        self._map_dirty         = False

        self._build_ui()

        # Restore state
        self._df           = stash["df"]
        self._fdf          = stash["fdf"]
        self._ioc_df       = stash["ioc_df"]
        self._city_db_path = stash["city_db"]
        self._asn_db_path  = stash["asn_db"]
        self._input_path   = stash["input_path"]
        self._output_dir   = stash["output_dir"]
        self._skip_geo.set(stash["skip_geo"])
        self._split_ops.set(stash["split"])
        self._fmt_var.set(stash["fmt"])

        if self._input_path:
            self._ual_lbl.configure(
                text=f"✔  {Path(self._input_path).name}",
                text_color=self._tc["status_ok"])
        if self._city_db_path:
            self._city_lbl.configure(
                text=f"City DB: ✔  {Path(self._city_db_path).name}",
                text_color=self._tc["status_ok"])
        if self._asn_db_path:
            self._asn_lbl.configure(
                text=f"ASN DB: ✔  {Path(self._asn_db_path).name}",
                text_color=self._tc["status_ok"])
        if self._output_dir:
            self._out_lbl.configure(
                text=f"✔  {self._output_dir}",
                text_color=self._tc["status_ok"])
        if stash["ops"]:
            self._operations = stash["ops"]
            if hasattr(self, "_op_listbox"):
                saved_sel = stash.get("op", [])
                if not saved_sel or stash.get("op_all", True):
                    self._op_listbox_set_values(stash["ops"], select=None)
                else:
                    self._op_listbox_set_values(stash["ops"], select=saved_sel)
        for k, v in stash["ioc_vars"].items():
            if k in self._ioc_vars:
                self._ioc_vars[k].set(v)

        self._tile_var.set(stash["tile"])
        self._change_tile_server(stash.get("tile", "OpenStreetMap"))

        if self._df is not None:
            self._export_btn.configure(state="normal")
            self._report_btn.configure(state="normal")
            # Re-apply impossible travel button visual if filter was active
            if getattr(self, "_imp_travel_active", False) and hasattr(self, "_imp_btn"):
                self._imp_btn.configure(
                    fg_color=self._tc["status_err"],
                    text_color="#FFFFFF",
                    border_color=self._tc["status_err"],
                    text="⚠  IMP. TRAVEL  ×")
            n = len(self._fdf if self._fdf is not None else self._df)
            self._status_var.set(f"● {n:,} ROWS ENRICHED")
            self._status_lbl.configure(text_color=self._tc["status_ok"])
            # Stagger refreshes so the window reappears instantly
            self._refresh_table()
            self._row_lbl.configure(text=f"{n:,} rows")
            self.after(50,  self._refresh_map)
            self.after(150, self._refresh_summary)
            if self._ioc_df is not None:
                self._ioc_export_btn.configure(state="normal")

    # ─────────────────────────────────────────────────────────────────────────
    # Keyboard shortcut bar
    # ─────────────────────────────────────────────────────────────────────────
    def _build_shortcut_bar(self, parent, row: int):
        tc   = self._tc
        mono = MONO
        bar  = ctk.CTkFrame(parent, fg_color=tc["panel"], corner_radius=0, height=22)
        bar.grid(row=row, column=0, sticky="ew")
        bar.grid_propagate(False)

        shortcuts = [
            ("Ctrl+F", "Search"),
            ("Ctrl+E", "Export"),
            ("Ctrl+I", "IOC Filter"),
            ("Ctrl+M", "Map"),
            ("Ctrl+U", "Summary"),
            ("Ctrl+R", "Run Enrichment"),
        ]

        inner = ctk.CTkFrame(bar, fg_color="transparent")
        inner.place(relx=0, rely=0.5, anchor="w", x=8)

        for i, (key, label) in enumerate(shortcuts):
            f = ctk.CTkFrame(inner, fg_color="transparent")
            f.grid(row=0, column=i * 2, padx=(0, 0))
            ctk.CTkLabel(f, text=key,
                         font=ctk.CTkFont(family=mono, size=8, weight="bold"),
                         text_color=tc["accent"]).grid(row=0, column=0)
            ctk.CTkLabel(f, text=f" {label}",
                         font=ctk.CTkFont(family=mono, size=8),
                         text_color=tc["text_dim"]).grid(row=0, column=1)
            if i < len(shortcuts) - 1:
                ctk.CTkLabel(inner, text="  ·  ",
                             font=ctk.CTkFont(family=mono, size=8),
                             text_color=tc["text_muted"]).grid(row=0, column=i * 2 + 1)

    # ─────────────────────────────────────────────────────────────────────────
    # Column Quick Stats (right-click column header)
    # ─────────────────────────────────────────────────────────────────────────

    # Severity ordering for BEC operations
    _BEC_OP_SEVERITY: Dict[str, str] = {
        "New-InboxRule":              "CRITICAL",
        "UpdateInboxRules":           "CRITICAL",
        "Set-Mailbox":                "CRITICAL",
        "Add-MailboxPermission":      "CRITICAL",
        "SendAs":                     "HIGH",
        "Send":                       "HIGH",
        "FileDownloaded":             "HIGH",
        "FileSyncDownloadedFull":     "HIGH",
        "MailItemsAccessed":          "MEDIUM",
        "SearchQueryInitiatedExchange": "MEDIUM",
        "MailboxLogin":               "LOW",
        "UserLoggedIn":               "LOW",
        "UserLoginFailed":            "LOW",
    }

    def _on_tree_right_click(self, event):
        """Right-click on a treeview header → Column Quick Stats popup."""
        # Identify the column header under the cursor
        region = self._tree.identify_region(event.x, event.y)
        if region != "heading":
            return
        col_id = self._tree.identify_column(event.x)
        if not col_id:
            return
        # col_id is "#1", "#2", etc.
        try:
            col_idx = int(col_id.replace("#", "")) - 1
            cols    = list(self._tree["columns"])
            col_name = cols[col_idx]
        except (ValueError, IndexError):
            return

        self._show_col_stats(col_name, event.x_root, event.y_root)

    def _show_col_stats(self, col_name: str, rx: int, ry: int):
        """Open a popup with BEC-aware stats for the given column."""
        df = self._fdf if self._fdf is not None else self._df
        if df is None or col_name not in df.columns:
            return

        tc   = self._tc
        mono = MONO
        popup = ctk.CTkToplevel(self)
        popup.title(f"Column Stats — {col_name}")
        popup.geometry(f"480x440+{rx}+{ry}")
        popup.configure(fg_color=tc["bg"])
        popup.grab_set()
        popup.grid_columnconfigure(0, weight=1)
        popup.grid_rowconfigure(2, weight=1)

        # Header
        hdr = ctk.CTkFrame(popup, fg_color=tc["panel"], corner_radius=0, height=36)
        hdr.grid(row=0, column=0, sticky="ew")
        hdr.grid_propagate(False)
        hdr.grid_columnconfigure(0, weight=1)
        ctk.CTkFrame(hdr, fg_color=tc["accent"], width=3,
                     corner_radius=0).grid(row=0, column=0, sticky="ns", rowspan=2)
        ctk.CTkLabel(hdr, text=col_name.upper(),
                     font=ctk.CTkFont(family=mono, size=11, weight="bold"),
                     text_color=tc["accent"]).grid(
            row=0, column=1, padx=12, pady=8, sticky="w")

        ctk.CTkFrame(popup, fg_color=tc["border"], height=1,
                     corner_radius=0).grid(row=1, column=0, sticky="ew")

        # Content
        scroll = ctk.CTkScrollableFrame(popup, fg_color=tc["bg"],
                                         scrollbar_button_color=tc["border"])
        scroll.grid(row=2, column=0, sticky="nsew", padx=0, pady=0)
        scroll.grid_columnconfigure(0, weight=1)

        try:
            series   = df[col_name].cast(pl.Utf8, strict=False)
            total    = len(series)
            non_null = series.drop_nulls()
            n_unique = non_null.n_unique()
            fill_pct = len(non_null) / total * 100 if total > 0 else 0

            def _stat(label, val, colour=None):
                f = ctk.CTkFrame(scroll, fg_color="transparent")
                f.grid(sticky="ew", padx=12, pady=1)
                f.grid_columnconfigure(1, weight=1)
                ctk.CTkLabel(f, text=label,
                             font=ctk.CTkFont(family=mono, size=9),
                             text_color=tc["text_dim"], width=140, anchor="w").grid(
                    row=0, column=0, sticky="w")
                ctk.CTkLabel(f, text=str(val),
                             font=ctk.CTkFont(family=mono, size=9, weight="bold"),
                             text_color=colour or tc["text"]).grid(
                    row=0, column=1, sticky="w")

            def _sep():
                ctk.CTkFrame(scroll, fg_color=tc["border"], height=1).grid(
                    sticky="ew", padx=12, pady=4)

            def _section(title):
                ctk.CTkLabel(scroll, text=title,
                             font=ctk.CTkFont(family=mono, size=8, weight="bold"),
                             text_color=tc["text_dim"]).grid(
                    sticky="w", padx=12, pady=(8, 2))

            _section("OVERVIEW")
            _stat("Total rows",   f"{total:,}")
            _stat("Non-null",     f"{len(non_null):,}  ({fill_pct:.0f}% fill)")
            _stat("Unique values", f"{n_unique:,}")

            # ── BEC-aware analysis per column ──────────────────────────────────
            if col_name == "Operation" and "Operation" in df.columns:
                _sep()
                _section("BEC SEVERITY BREAKDOWN")
                vc = (non_null.value_counts().sort("count", descending=True)
                      .head(20))
                for row in vc.iter_rows(named=True):
                    op  = row[non_null.name]
                    cnt = row["count"]
                    sev = self._BEC_OP_SEVERITY.get(op, "")
                    sev_col = {"CRITICAL": tc["status_err"],
                               "HIGH":     tc["accent2"],
                               "MEDIUM":   tc["accent4"],
                               "LOW":      tc["text_dim"]}.get(sev, tc["text_dim"])
                    pct_bar  = cnt / total
                    f = ctk.CTkFrame(scroll, fg_color=tc["card"], corner_radius=2)
                    f.grid(sticky="ew", padx=12, pady=1)
                    f.grid_columnconfigure(1, weight=1)
                    ctk.CTkLabel(f, text=op or "(blank)",
                                 font=ctk.CTkFont(family=mono, size=9),
                                 text_color=tc["text"], width=200, anchor="w").grid(
                        row=0, column=0, padx=(8, 4), pady=3, sticky="w")
                    pb = ctk.CTkProgressBar(f, height=4, fg_color=tc["border"],
                                            progress_color=sev_col or tc["accent"])
                    pb.grid(row=0, column=1, padx=(0, 4), pady=3, sticky="ew")
                    pb.set(pct_bar)
                    ctk.CTkLabel(f, text=f"{cnt:,}",
                                 font=ctk.CTkFont(family=mono, size=9),
                                 text_color=sev_col or tc["text_dim"], width=54, anchor="e").grid(
                        row=0, column=2, padx=(0, 8), pady=3)
                    if sev:
                        ctk.CTkLabel(f, text=sev,
                                     font=ctk.CTkFont(family=mono, size=7, weight="bold"),
                                     text_color=sev_col, width=52, anchor="e").grid(
                            row=0, column=3, padx=(0, 6), pady=3)

            elif col_name == "ClientIP":
                _sep()
                _section("TOP IPs — HOSTING VS ISP")
                vc = (non_null.value_counts().sort("count", descending=True).head(15))
                for row in vc.iter_rows(named=True):
                    ip  = row[non_null.name]
                    cnt = row["count"]
                    # Check if this IP exists in the df's Organisation column
                    org = ""
                    if "Organization" in df.columns:
                        org_rows = df.filter(pl.col("ClientIP") == ip)["Organization"].drop_nulls()
                        if len(org_rows):
                            org = str(org_rows[0])[:30]
                    pct_bar = cnt / total
                    f = ctk.CTkFrame(scroll, fg_color=tc["card"], corner_radius=2)
                    f.grid(sticky="ew", padx=12, pady=1)
                    f.grid_columnconfigure(1, weight=1)
                    ctk.CTkLabel(f, text=ip or "(blank)",
                                 font=ctk.CTkFont(family=mono, size=9),
                                 text_color=tc["text"], width=130, anchor="w").grid(
                        row=0, column=0, padx=(8, 4), pady=3)
                    pb = ctk.CTkProgressBar(f, height=4, fg_color=tc["border"],
                                            progress_color=tc["accent2"])
                    pb.grid(row=0, column=1, padx=(0, 4), pady=3, sticky="ew")
                    pb.set(pct_bar)
                    ctk.CTkLabel(f, text=f"{cnt:,}",
                                 font=ctk.CTkFont(family=mono, size=9),
                                 text_color=tc["text_dim"], width=46, anchor="e").grid(
                        row=0, column=2, padx=(0, 4), pady=3)
                    if org:
                        ctk.CTkLabel(f, text=org,
                                     font=ctk.CTkFont(family=mono, size=8),
                                     text_color=tc["text_dim"]).grid(
                            row=1, column=0, columnspan=3, padx=(8, 4), pady=(0, 3), sticky="w")

            elif col_name == "SessionId":
                _sep()
                _section("TOKEN REUSE ANALYSIS")
                ctk.CTkLabel(scroll,
                             text="Sessions shared by >1 user = token replay indicator",
                             font=ctk.CTkFont(family=mono, size=8),
                             text_color=tc["text_dim"]).grid(
                    sticky="w", padx=12, pady=(0, 4))
                if "UserId" in df.columns:
                    shared = (df.group_by("SessionId")
                              .agg(pl.col("UserId").drop_nulls().n_unique().alias("users"))
                              .filter(pl.col("users") > 1)
                              .sort("users", descending=True))
                    if len(shared) == 0:
                        ctk.CTkLabel(scroll,
                                     text="No shared sessions detected.",
                                     font=ctk.CTkFont(family=mono, size=9),
                                     text_color=tc["status_ok"]).grid(
                            sticky="w", padx=12, pady=2)
                    else:
                        _stat("Shared sessions found", f"{len(shared)}", tc["status_err"])
                        for row in shared.head(10).iter_rows(named=True):
                            sid   = str(row["SessionId"] or "")[:36]
                            users = row["users"]
                            f = ctk.CTkFrame(scroll, fg_color=tc["card"], corner_radius=2)
                            f.grid(sticky="ew", padx=12, pady=1)
                            f.grid_columnconfigure(0, weight=1)
                            ctk.CTkLabel(f, text=sid,
                                         font=ctk.CTkFont(family=mono, size=9),
                                         text_color=tc["text"]).grid(
                                row=0, column=0, padx=(8, 4), pady=3, sticky="w")
                            ctk.CTkLabel(f, text=f"{users} users",
                                         font=ctk.CTkFont(family=mono, size=9, weight="bold"),
                                         text_color=tc["status_err"]).grid(
                                row=0, column=1, padx=(0, 8), pady=3)

            elif col_name in ("Country", "City"):
                _sep()
                _section("TOP GEOGRAPHIC VALUES")
                vc = (non_null.value_counts().sort("count", descending=True).head(15))
                for row in vc.iter_rows(named=True):
                    val = row[non_null.name]
                    cnt = row["count"]
                    pct_bar = cnt / total
                    f = ctk.CTkFrame(scroll, fg_color=tc["card"], corner_radius=2)
                    f.grid(sticky="ew", padx=12, pady=1)
                    f.grid_columnconfigure(1, weight=1)
                    ctk.CTkLabel(f, text=val or "(unknown)",
                                 font=ctk.CTkFont(family=mono, size=9),
                                 text_color=tc["text"], width=160, anchor="w").grid(
                        row=0, column=0, padx=(8, 4), pady=3)
                    pb = ctk.CTkProgressBar(f, height=4, fg_color=tc["border"],
                                            progress_color=tc["accent3"])
                    pb.grid(row=0, column=1, padx=(0, 4), pady=3, sticky="ew")
                    pb.set(pct_bar)
                    ctk.CTkLabel(f, text=f"{cnt:,}",
                                 font=ctk.CTkFont(family=mono, size=9),
                                 text_color=tc["text_dim"], width=46, anchor="e").grid(
                        row=0, column=2, padx=(0, 8), pady=3)

            else:
                # Generic top-N for all other columns
                _sep()
                _section(f"TOP {min(15, n_unique)} VALUES")
                vc = (non_null.value_counts().sort("count", descending=True).head(15))
                for row in vc.iter_rows(named=True):
                    val = row[non_null.name]
                    cnt = row["count"]
                    pct_bar = cnt / total
                    f = ctk.CTkFrame(scroll, fg_color=tc["card"], corner_radius=2)
                    f.grid(sticky="ew", padx=12, pady=1)
                    f.grid_columnconfigure(1, weight=1)
                    ctk.CTkLabel(f, text=str(val or "(blank)")[:50],
                                 font=ctk.CTkFont(family=mono, size=9),
                                 text_color=tc["text"], width=200, anchor="w").grid(
                        row=0, column=0, padx=(8, 4), pady=3)
                    pb = ctk.CTkProgressBar(f, height=4, fg_color=tc["border"],
                                            progress_color=tc["accent"])
                    pb.grid(row=0, column=1, padx=(0, 4), pady=3, sticky="ew")
                    pb.set(pct_bar)
                    ctk.CTkLabel(f, text=f"{cnt:,}",
                                 font=ctk.CTkFont(family=mono, size=9),
                                 text_color=tc["text_dim"], width=46, anchor="e").grid(
                        row=0, column=2, padx=(0, 8), pady=3)

        except Exception as e:
            ctk.CTkLabel(scroll, text=f"Stats error: {e}",
                         text_color=tc["status_err"],
                         font=ctk.CTkFont(family=mono, size=10)).grid(
                sticky="w", padx=12, pady=8)

        ctk.CTkButton(popup, text="CLOSE",
                      fg_color="transparent", hover_color=tc["card"],
                      text_color=tc["text_dim"], border_color=tc["border"],
                      border_width=1, height=28, corner_radius=2,
                      font=ctk.CTkFont(family=mono, size=9),
                      command=popup.destroy).grid(
            row=3, column=0, padx=12, pady=(0, 10), sticky="e")

# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    app = ThreadHunterApp()
    app.mainloop()
