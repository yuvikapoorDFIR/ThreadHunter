"""
main.py
-------
ThreadHunter Platform entry point.
Single Tk event loop. Launcher owns it; main investigation window
is a CTkToplevel so it can be closed and a new case opened without restarting.
"""
import sys
from pathlib import Path

import customtkinter as ctk

from core.case import Case
from launcher import LauncherWindow


def main():
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("dark-blue")

    # Create the launcher as the root window (owns the event loop)
    launcher = LauncherWindow(on_case_opened=_open_main_window)

    # If a .threadhunter file was passed as a CLI arg, skip straight to it
    if len(sys.argv) > 1:
        path = sys.argv[1]
        if Path(path).exists() and path.endswith(".threadhunter"):
            try:
                case = Case.open(path)
                _open_main_window(case, launcher)
            except Exception as e:
                print(f"Could not open case: {e}")

    launcher.mainloop()


def _open_main_window(case: Case, launcher: "LauncherWindow" = None):
    """
    Open the main investigation window as a Toplevel over the launcher.
    When the user closes it (via the X button or Close Case), the launcher reappears.
    """
    from threadhunter import ThreadHunterApp

    app = ThreadHunterApp(case=case)

    def on_close():
        # Case may already be closed if user used the Close Case button
        try:
            case.close()
        except Exception:
            pass
        try:
            app.destroy()
        except Exception:
            pass
        # Bring launcher back and refresh recent cases
        if launcher is not None:
            try:
                launcher.deiconify()
                launcher.lift()
                launcher.focus_force()
                launcher._load_recent_cases()
            except Exception:
                pass

    app._on_close_handler = on_close
    app.protocol("WM_DELETE_WINDOW", on_close)


if __name__ == "__main__":
    main()
