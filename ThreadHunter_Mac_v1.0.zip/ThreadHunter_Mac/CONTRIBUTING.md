# Contributing to ThreadHunter

Thank you for your interest in contributing to ThreadHunter.

## Getting Started

1. Fork the repository and clone it locally
2. Install dependencies: `pip install -r requirements.txt`
3. Obtain GeoLite2 databases from MaxMind (free, see README)
4. Run with: `python main.py`

## Code Conventions

- **Language:** Python 3.10+
- **GUI:** CustomTkinter — all UI code lives in `threadhunter.py` and `launcher.py`
- **Data:** Polars DataFrames throughout — avoid converting to Python lists/dicts unnecessarily
- **Threading:** All enrichment runs in a daemon thread (`threading.Thread`). Never call Tkinter widget methods from a background thread — use `queue.Queue` + `after()` polling instead
- **Fonts:** `MONO` constant (`"Courier"`) is used everywhere for consistency
- **Colours:** All colours come from `THEME["dark"]` or `THEME["light"]` — no hardcoded hex in widget code

## Pull Request Guidelines

- Keep PRs focused — one feature or fix per PR
- Test with a real UAL export if touching enrichment code
- Do not commit `.threadhunter` case files, `*.mmdb` databases, or enriched output CSVs
- Update `CHANGELOG.md` with a brief description of your change

## Security

If you discover a security issue, please open a private GitHub Security Advisory rather than a public issue.

## Sensitive Data Warning

ThreadHunter processes Microsoft 365 audit logs which contain personally identifiable information (PII). Never commit case files, enriched outputs, or real UAL exports to the repository.
