---
name: Bug report
about: Report a bug or unexpected behaviour
title: '[BUG] '
labels: bug
assignees: ''
---

**Describe the bug**
A clear description of what went wrong.

**Steps to reproduce**
1. Go to '...'
2. Click on '...'
3. See error

**Expected behaviour**
What you expected to happen.

**Screenshots**
If applicable, add screenshots.

**Environment**
- OS: [e.g. Windows 11, macOS 14, Ubuntu 22.04]
- Python version: [e.g. 3.11]
- ThreadHunter version: [e.g. 2.1]

**Activity log output**
Paste any relevant lines from the Activity Log panel.

**Note:** Do not attach real UAL exports or case files — they contain PII.
