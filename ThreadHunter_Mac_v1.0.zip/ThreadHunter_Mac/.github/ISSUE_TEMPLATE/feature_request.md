---
name: Feature request
about: Suggest a new feature or improvement
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

**What problem does this solve?**
Describe the analyst workflow or investigation scenario this would help with.

**Proposed solution**
Describe what you'd like to see added or changed.

**Alternatives considered**
Any other approaches you've thought about.

**Additional context**
Any mockups, examples, or references.
