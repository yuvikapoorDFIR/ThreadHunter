"""
core/case.py
------------
Case model: creates and manages the per-case SQLite schema.
Each investigation is stored in a single .threadhunter file.
"""
import sqlite3
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any

from core.database import Database


# ── Schema version — increment when migrations are needed ─────────────────────
SCHEMA_VERSION = 1

# ── DDL ───────────────────────────────────────────────────────────────────────
SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS case_meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS events (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    source         TEXT NOT NULL,          -- 'ual', 'azure_ad', 'exchange', etc.
    event_time     TEXT,                   -- ISO-8601 string, nullable until normalised
    operation      TEXT,
    user_id        TEXT,
    client_ip      TEXT,
    country        TEXT,
    city           TEXT,
    asn            TEXT,
    organisation   TEXT,
    app_display    TEXT,
    session_id     TEXT,
    user_agent     TEXT,
    token_id       TEXT,
    latitude       REAL,
    longitude      REAL,
    raw_json       TEXT,                   -- original AuditData / raw row as JSON
    flagged        INTEGER DEFAULT 0,      -- 1 = analyst flagged as key finding
    flag_note      TEXT,
    ingested_at    TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_events_time   ON events(event_time);
CREATE INDEX IF NOT EXISTS idx_events_user   ON events(user_id);
CREATE INDEX IF NOT EXISTS idx_events_ip     ON events(client_ip);
CREATE INDEX IF NOT EXISTS idx_events_op     ON events(operation);
CREATE INDEX IF NOT EXISTS idx_events_source ON events(source);

CREATE TABLE IF NOT EXISTS iocs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ioc_type    TEXT NOT NULL,  -- 'ip', 'session_id', 'user_agent', 'token_id', 'email', 'domain'
    value       TEXT NOT NULL,
    description TEXT,
    confidence  TEXT DEFAULT 'medium',  -- 'low', 'medium', 'high'
    added_at    TEXT DEFAULT (datetime('now')),
    UNIQUE(ioc_type, value)
);

CREATE TABLE IF NOT EXISTS identities (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    identity_key TEXT UNIQUE NOT NULL,   -- e.g. 'user:john@acme.com', 'ip:1.2.3.4'
    identity_type TEXT NOT NULL,         -- 'user', 'ip', 'session', 'device', 'app'
    display_name TEXT,
    first_seen   TEXT,
    last_seen    TEXT,
    event_count  INTEGER DEFAULT 0,
    flagged      INTEGER DEFAULT 0,
    notes        TEXT
);

CREATE TABLE IF NOT EXISTS identity_links (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    src_key TEXT NOT NULL,
    dst_key TEXT NOT NULL,
    link_type TEXT,            -- 'authenticated_from', 'used_session', 'accessed_app'
    event_count INTEGER DEFAULT 1,
    UNIQUE(src_key, dst_key, link_type)
);

CREATE TABLE IF NOT EXISTS artefacts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    filename     TEXT NOT NULL,
    filepath     TEXT,
    sha256       TEXT,
    file_type    TEXT,
    size_bytes   INTEGER,
    description  TEXT,
    tags         TEXT,          -- JSON array of strings
    linked_event INTEGER REFERENCES events(id),
    added_at     TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS notes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    section    TEXT DEFAULT 'general',  -- 'general', 'timeline', 'ioc', 'identity'
    content    TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS timeline_entries (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id    INTEGER REFERENCES events(id),
    entry_time  TEXT NOT NULL,
    title       TEXT NOT NULL,
    detail      TEXT,
    category    TEXT DEFAULT 'general',  -- 'access', 'exfil', 'persistence', 'discovery', 'impact'
    source      TEXT,
    sort_order  INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_timeline_time ON timeline_entries(entry_time);
"""


class Case:
    """
    Represents a single ThreadHunter investigation case.

    Usage:
        case = Case.create('/path/to/MyCase.threadhunter', 'BEC - Acme Corp')
        case = Case.open('/path/to/MyCase.threadhunter')
        case.close()
    """

    def __init__(self, db: Database, meta: Dict[str, str]):
        self.db   = db
        self.path = db.path
        self._meta = meta

    # ── Properties ────────────────────────────────────────────────────────────

    @property
    def name(self) -> str:
        return self._meta.get("name", self.path.stem)

    @property
    def created_at(self) -> str:
        return self._meta.get("created_at", "")

    @property
    def client(self) -> str:
        return self._meta.get("client", "")

    @property
    def analyst(self) -> str:
        return self._meta.get("analyst", "")

    @property
    def description(self) -> str:
        return self._meta.get("description", "")

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    @classmethod
    def create(cls, path: str, name: str,
                client: str = "", analyst: str = "",
                description: str = "") -> "Case":
        """Create a new case file. Raises if file already exists."""
        p = Path(path)
        if p.exists():
            raise FileExistsError(f"Case file already exists: {path}")

        db = Database(path).open()
        db.conn.executescript(SCHEMA_SQL)

        now = datetime.now().isoformat(sep=" ", timespec="seconds")
        meta = {
            "schema_version": str(SCHEMA_VERSION),
            "name":           name,
            "client":         client,
            "analyst":        analyst,
            "description":    description,
            "created_at":     now,
            "updated_at":     now,
        }
        db.executemany(
            "INSERT OR REPLACE INTO case_meta(key, value) VALUES (?,?)",
            list(meta.items())
        )
        db.commit()
        return cls(db, meta)

    @classmethod
    def open(cls, path: str) -> "Case":
        """Open an existing case file."""
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"Case file not found: {path}")

        db = Database(path).open()
        # Ensure schema is current (idempotent creates)
        db.conn.executescript(SCHEMA_SQL)
        db.commit()

        meta = {
            row["key"]: row["value"]
            for row in db.conn.execute("SELECT key,value FROM case_meta").fetchall()
        }
        return cls(db, meta)

    def close(self):
        self.db.close()

    def save_meta(self, **kwargs):
        """Update one or more metadata fields."""
        kwargs["updated_at"] = datetime.now().isoformat(sep=" ", timespec="seconds")
        self.db.executemany(
            "INSERT OR REPLACE INTO case_meta(key, value) VALUES (?,?)",
            list(kwargs.items())
        )
        self.db.commit()
        self._meta.update(kwargs)

    # ── Stats ─────────────────────────────────────────────────────────────────

    def stats(self) -> Dict[str, int]:
        """Return quick summary counts for the dashboard."""
        q = self.db.fetchone
        return {
            "events":     (q("SELECT COUNT(*) AS n FROM events") or {}).get("n", 0),
            "flagged":    (q("SELECT COUNT(*) AS n FROM events WHERE flagged=1") or {}).get("n", 0),
            "iocs":       (q("SELECT COUNT(*) AS n FROM iocs") or {}).get("n", 0),
            "identities": (q("SELECT COUNT(*) AS n FROM identities") or {}).get("n", 0),
            "artefacts":  (q("SELECT COUNT(*) AS n FROM artefacts") or {}).get("n", 0),
            "notes":      (q("SELECT COUNT(*) AS n FROM notes") or {}).get("n", 0),
        }

    # ── Event helpers ─────────────────────────────────────────────────────────

    def insert_events_bulk(self, rows: List[Dict[str, Any]], source: str):
        """Bulk-insert normalised event rows. Commits after insertion."""
        cols = [
            "source", "event_time", "operation", "user_id", "client_ip",
            "country", "city", "asn", "organisation", "app_display",
            "session_id", "user_agent", "token_id", "latitude", "longitude",
            "raw_json",
        ]
        placeholders = ",".join(["?"] * len(cols))
        col_str      = ",".join(cols)

        data = []
        for r in rows:
            data.append((
                source,
                r.get("event_time") or r.get("CreationDate"),
                r.get("operation")  or r.get("Operation"),
                r.get("user_id")    or r.get("UserId"),
                r.get("client_ip")  or r.get("ClientIP"),
                r.get("country")    or r.get("Country"),
                r.get("city")       or r.get("City"),
                r.get("asn")        or r.get("ASN"),
                r.get("organisation") or r.get("Organization"),
                r.get("app_display")  or r.get("AppDisplayName"),
                r.get("session_id")   or r.get("SessionId"),
                r.get("user_agent")   or r.get("UserAgent"),
                r.get("token_id")     or r.get("UniqueTokenId"),
                r.get("latitude")     or r.get("Latitude"),
                r.get("longitude")    or r.get("Longitude"),
                r.get("raw_json"),
            ))

        self.db.executemany(
            f"INSERT INTO events ({col_str}) VALUES ({placeholders})", data
        )
        self.db.commit()

    # ── IOC helpers ───────────────────────────────────────────────────────────

    def add_ioc(self, ioc_type: str, value: str,
                description: str = "", confidence: str = "medium"):
        try:
            self.db.execute(
                "INSERT INTO iocs(ioc_type,value,description,confidence) VALUES (?,?,?,?)",
                (ioc_type, value, description, confidence)
            )
            self.db.commit()
            return True
        except sqlite3.IntegrityError:
            return False  # already exists

    def get_iocs(self) -> List[Dict]:
        return self.db.fetchall("SELECT * FROM iocs ORDER BY added_at DESC")

    # ── Note helpers ──────────────────────────────────────────────────────────

    def add_note(self, content: str, section: str = "general") -> int:
        cur = self.db.execute(
            "INSERT INTO notes(content,section) VALUES (?,?)", (content, section)
        )
        self.db.commit()
        return cur.lastrowid

    def get_notes(self, section: Optional[str] = None) -> List[Dict]:
        if section:
            return self.db.fetchall(
                "SELECT * FROM notes WHERE section=? ORDER BY created_at DESC", (section,)
            )
        return self.db.fetchall("SELECT * FROM notes ORDER BY created_at DESC")

    # ── Timeline helpers ──────────────────────────────────────────────────────

    def add_timeline_entry(self, entry_time: str, title: str,
                           detail: str = "", category: str = "general",
                           event_id: Optional[int] = None,
                           source: str = "") -> int:
        cur = self.db.execute(
            """INSERT INTO timeline_entries
               (event_id, entry_time, title, detail, category, source)
               VALUES (?,?,?,?,?,?)""",
            (event_id, entry_time, title, detail, category, source)
        )
        self.db.commit()
        return cur.lastrowid

    def get_timeline(self, category: Optional[str] = None) -> List[Dict]:
        if category:
            return self.db.fetchall(
                "SELECT * FROM timeline_entries WHERE category=? ORDER BY entry_time",
                (category,)
            )
        return self.db.fetchall(
            "SELECT * FROM timeline_entries ORDER BY entry_time"
        )
