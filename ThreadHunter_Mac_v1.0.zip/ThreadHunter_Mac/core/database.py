"""
core/database.py
----------------
SQLite connection manager for ThreadHunter cases.
One .threadhunter file = one case = one SQLite database.
"""
import sqlite3
from pathlib import Path
from typing import Optional


class Database:
    """Thin wrapper around a SQLite connection for a single case file."""

    def __init__(self, path: str):
        self.path = Path(path)
        self._conn: Optional[sqlite3.Connection] = None

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def open(self) -> "Database":
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        return self

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None

    def __enter__(self):
        return self.open()

    def __exit__(self, *_):
        self.close()

    # ── Query helpers ─────────────────────────────────────────────────────────

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("Database not open — call open() first")
        return self._conn

    def execute(self, sql: str, params=()):
        return self.conn.execute(sql, params)

    def executemany(self, sql: str, data):
        return self.conn.executemany(sql, data)

    def commit(self):
        self.conn.commit()

    def fetchall(self, sql: str, params=()) -> list:
        return [dict(row) for row in self.conn.execute(sql, params).fetchall()]

    def fetchone(self, sql: str, params=()) -> Optional[dict]:
        row = self.conn.execute(sql, params).fetchone()
        return dict(row) if row else None
