# Changelog

All notable changes to ThreadHunter are documented here.

## [Unreleased]

### Added
- Country flag images in Summary tab (Top Countries, Top Client IPs)
- Country flags in HTML report (Geographic Distribution, Impossible Travel)
- Multi-select Operation Filter with "All Operations" checkbox
- Impossible travel detection with configurable time window
- Column Quick Stats popup (right-click any column header in Data Table)
- Case information popup (click CASE pill in banner)
- Delete case from launcher and from case info popup
- HTML investigation report generator
- IOC Filter tab with session/IP/token/user-agent matching
- Dark and light theme toggle
- Map tile server switcher (OpenStreetMap, Google, CartoDB)
- Keyboard shortcuts (Ctrl+F, Ctrl+E, Ctrl+I, Ctrl+M, Ctrl+R)

### Changed
- Operation Filter replaced dropdown with scrollable multi-select listbox
- Summary bar charts use fixed-width columns so bars align regardless of label length
- CLEAR log button enlarged and styled as a visible destructive action

### Fixed
- `the truth value of a DataFrame is ambiguous` error in table render
- Listbox event storm during programmatic updates (guard flag)
- Flag images not showing on Windows (replaced emoji with pre-rendered PNGs)
- Bar chart label overflow causing uneven bar lengths

## [2.0.0] — Initial release
- UAL ingestion (CSV and XLSX)
- AuditData JSON parsing with parallel ThreadPoolExecutor
- GeoIP enrichment via MaxMind GeoLite2
- Live tile map with TkinterMapView
- Data Table with sort, search, and impossible travel highlighting
- Case management with SQLite backend (.threadhunter files)
- Export to CSV or Excel
