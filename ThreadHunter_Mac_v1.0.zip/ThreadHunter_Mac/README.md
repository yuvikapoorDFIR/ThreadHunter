# ThreadHunter — BEC Forensics

A desktop DFIR tool for enriching and investigating Microsoft 365 Unified Audit Log (UAL) data. Built for analysts working Business Email Compromise (BEC) and cloud intrusion engagements.

---

## Features

| Feature | Description |
|---|---|
| **UAL Ingestion** | Load raw M365 UAL exports (CSV or XLSX) |
| **AuditData Parsing** | Extracts ClientIP, AppId, SessionId, UserAgent, UniqueTokenId from nested JSON — parallel processing |
| **GeoIP Enrichment** | Country / City / ASN / Organisation with lat/lon via GeoLite2 (fully offline) |
| **Live Tile Map** | TkinterMapView — zoom, pan, clickable markers, right-click menu |
| **Data Table** | Sortable columns, full-text search, double-click row detail popup |
| **Impossible Travel** | Detects same-account logins from different countries within a configurable time window |
| **Operation Filter** | Multi-select scrollable filter — click to toggle individual operations |
| **Summary Dashboard** | Top operations, IPs, users, countries with flag images and bar charts |
| **IOC Filter** | Match across IP, SessionId, UserAgent, UniqueTokenId simultaneously |
| **HTML Report** | Self-contained dark-themed report with impossible travel, IOCs, and analyst notes |
| **Case Management** | SQLite-backed `.threadhunter` case files with metadata, events, IOCs, and notes |
| **Dark / Light Theme** | Toggle at runtime |
| **Export** | Save filtered or full data to CSV or Excel |

---

## Quick Start

### Compatibility

| Platform | Status | Notes |
|---|---|---|
| Windows 10/11 | ✅ Fully supported | Primary development platform |
| macOS 12+ (Intel & Apple Silicon) | ✅ Supported | See macOS notes below |
| Linux (Ubuntu 22.04+) | ✅ Supported | Requires `python3-tk` |

**macOS notes:**
- Install Python from [python.org](https://www.python.org/downloads/) — the bundled Tk is more reliable than Homebrew's
- If the app opens behind other windows, click the ThreadHunter icon in the Dock
- Menlo is used as the monospace font instead of Courier New

**Linux notes:**
- Run `sudo apt install python3-tk` before installing dependencies
- DejaVu Sans Mono is used as the monospace font

---

### 1. Clone and install

```bash
git clone https://github.com/your-org/threadhunter.git
cd threadhunter
pip install -r requirements.txt
```

### 2. Obtain GeoLite2 databases (free, one-time)

Register at [maxmind.com](https://www.maxmind.com/en/geolite2/signup) and download:
- `GeoLite2-City.mmdb`
- `GeoLite2-ASN.mmdb`

Place them anywhere on your machine — ThreadHunter lets you browse to them at runtime and remembers the paths between sessions.

> **Note:** GeoLite2 databases cannot be bundled in this repository under MaxMind's licence. ThreadHunter works fully offline once the databases are downloaded.

### 3. Run

```bash
python main.py
```

Or open a specific case directly:

```bash
python main.py path/to/MyCase.threadhunter
```

---

## Export a UAL from Microsoft 365

1. Go to [Microsoft Purview compliance portal](https://compliance.microsoft.com) → **Audit**
2. Set your date range and click **Search**
3. Once complete, click **Export** → **Download all results**
4. You'll receive a `.csv` — load this into ThreadHunter via **OPEN UAL FILE**

For full instructions see the [Microsoft documentation](https://learn.microsoft.com/en-us/purview/audit-log-export-records).

---

## Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `Ctrl+R` | Run Enrichment |
| `Ctrl+F` | Focus search in Data Table |
| `Ctrl+E` | Export current view |
| `Ctrl+M` | Switch to Map View |
| `Ctrl+I` | Switch to IOC Filter |
| `Ctrl+U` | Switch to Summary |

---

## File Structure

```
threadhunter/
├── main.py                  # Entry point
├── threadhunter.py          # Main investigation window
├── launcher.py              # Case launcher / recent cases
├── requirements.txt
├── appid_lookup.csv         # M365 Application ID → Display Name mapping
├── operations_config.yaml   # Per-operation field extraction config
├── flags/                   # Pre-rendered 20×15px country flag PNGs (253 flags)
├── tkintermapview/          # Bundled map widget
├── GeoIPLookup/             # GeoIP lookup module
├── core/
│   ├── case.py              # Case model and SQLite schema
│   └── database.py          # SQLite connection wrapper
├── modules/
│   ├── identity_graph.py    # Planned: identity graph (not yet active)
│   └── timeline.py          # Planned: attack timeline (not yet active)
└── enrich_ual.py            # Standalone CLI enrichment tool (optional)
```

---

## Standalone CLI Enrichment

`enrich_ual.py` is a standalone command-line enrichment tool, independent of the GUI:

```bash
pip install tqdm  # additional dependency for CLI only
python enrich_ual.py --input UAL_export.csv \
                     --city-db GeoLite2-City.mmdb \
                     --asn-db GeoLite2-ASN.mmdb \
                     --output enriched/
```

---

## Case Files

Each investigation is stored as a single `.threadhunter` file — a SQLite database containing:
- Case metadata (name, client, analyst, description)
- All enriched events
- IOC watchlist
- Analyst notes
- Artefact references
- Identity links (planned)

> **Security warning:** `.threadhunter` files contain PII from audit logs. Treat them as sensitive data. Never commit them to a repository — they are included in `.gitignore` by default.

---

## Attribution

- Map tiles: © [OpenStreetMap](https://www.openstreetmap.org/copyright) contributors
- GeoIP data: This product includes GeoLite2 data created by MaxMind, available from [maxmind.com](https://www.maxmind.com)
- Country flags: [iso-country-flags-svg-collection](https://github.com/joielechong/iso-country-flags-svg-collection)

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Please do not attach real UAL exports or case files to issues or pull requests.

## Licence

MIT — see [LICENSE](LICENSE)

---

## Data Sovereignty & Privacy

### What personal data ThreadHunter processes

A UAL export contains highly sensitive personal information, including:

- Full names and email addresses of every user who triggered an audit event
- IP addresses — often attributable to specific individuals
- Session IDs, token IDs, and device fingerprints (UserAgent strings)
- Timestamps of every login, file access, email send, and inbox rule change
- File names and mailbox references in operations like `FileAccessed` and `MailItemsAccessed`
- Authentication failures revealing which accounts were targeted

Handle UAL data and ThreadHunter case files with the same care as the underlying M365 environment.

---

### Self-hosted map tiles

If you want zero external tile requests, you can run your own OSM tile server locally and point ThreadHunter at it using the **Self-hosted (localhost)** option in the tile server dropdown. By default this points at `http://localhost:8080/{z}/{x}/{y}.png`.

The easiest way to run a local tile server is **OpenFreeMap** — a fully self-contained Docker-based OSM tile server:

> [github.com/hyperknot/openfreemap](https://github.com/hyperknot/openfreemap)

Once running, select **Self-hosted (localhost)** in ThreadHunter's Map Tile Server dropdown. No other changes needed.

### Map tile data egress

**By default, ThreadHunter starts in offline tile mode — no map tiles are fetched and no data leaves your workstation.**

When you select an external tile server (OpenStreetMap, Google Maps, CartoDB), map tile requests encode the latitude and longitude of the markers being viewed and send them to a third-party server. On sensitive engagements — particularly those involving government clients, critical infrastructure, or jurisdictions with strict data localisation requirements — keep the tile server set to **Offline (no tiles)**.

ThreadHunter will warn you the first time you switch to an external tile server in a session.

---

### Case files

Each `.threadhunter` file is a SQLite database containing the full enriched audit data including raw AuditData JSON. It is **not encrypted**.

**Recommended storage practices:**

- Store case files on an encrypted volume (BitLocker, FileVault, LUKS)
- Do not store case files on unencrypted shared network drives
- Apply the same access controls to case files as to the original UAL export
- Delete case files when they are no longer required for the engagement — use the in-app delete function which overwrites the file with zeros before removal

---

### GeoLite2 database — MaxMind licence requirements

ThreadHunter uses the MaxMind GeoLite2 databases for IP geolocation. These databases:

1. **Cannot be bundled with ThreadHunter** — redistribution is prohibited under MaxMind's [licence](https://www.maxmind.com/en/geolite2/eula)
2. **Require a free MaxMind account** to download — MaxMind collect your name and email address during registration
3. **Must be kept up to date** — MaxMind recommends updating at least weekly; outdated databases may produce inaccurate geolocation results
4. **Perform all lookups locally** — the mmdb files run entirely offline once downloaded; no data is sent to MaxMind during lookups

If your engagement cannot involve MaxMind account registration (e.g. strict third-party vendor controls), an alternative is the [DB-IP Lite](https://db-ip.com/db/lite.php.html) databases, which are available under Creative Commons and require no registration.

---

### Applicable privacy law considerations

| Jurisdiction | Key instrument | Consideration |
|---|---|---|
| Australia | Privacy Act 1988 / APPs | UAL data of Australian employees is personal information. Collect only what is necessary; destroy when no longer needed. |
| European Union | GDPR | Processing EU employee data outside the EEA requires adequate safeguards. Data minimisation and purpose limitation apply. Individuals may exercise access/erasure rights. |
| United Kingdom | UK GDPR / DPA 2018 | Same as EU GDPR in practice. |
| United States (healthcare) | HIPAA | UAL logs from healthcare organisations may touch systems handling PHI — treat audit logs accordingly. |
| United States (finance) | SEC / FINRA | Retention requirements may conflict with data minimisation. Confirm with client's compliance team. |

> **Note:** This is general guidance, not legal advice. Consult your firm's legal team and your client's data protection officer for jurisdiction-specific obligations.

---

### What does and does not leave your workstation

| Component | External contact | Data sent |
|---|---|---|
| GeoIP lookup | None — fully local | Nothing |
| Map tiles (Offline mode) | None | Nothing |
| Map tiles (external server) | Tile provider CDN | Tile coordinates (lat/lon bounding box) |
| Case file | None | Nothing |
| HTML report | None (opens locally in browser) | Nothing unless manually sent |
| Enrichment | None | Nothing |

