#!/usr/bin/env python3
"""
enrich_ual.py - M365 Unified Audit Log Enrichment Utility

Parses and enriches Microsoft 365 Unified Audit Log (UAL) data exported from
the M365 Security & Compliance Center. Extracts valuable fields from the
AuditData JSON column and adds them as separate columns for easier analysis.
"""

import argparse
import json
import logging
import re
import sys
import yaml
from pathlib import Path
from datetime import datetime
from typing import Tuple, Optional, Dict, Any, List
import polars as pl
from tqdm import tqdm

# Import GeoIPLookup from local module
sys.path.insert(0, str(Path(__file__).parent / "GeoIPLookup"))
from geoip_lookup import GeoIPLookup

# Global variable for AppId lookup table (loaded once)
APPID_LOOKUP: Optional[Dict[str, str]] = None

# Global variable for operations config (loaded once)
OPERATIONS_CONFIG: Optional[Dict[str, Any]] = None


def parse_arguments() -> argparse.Namespace:
    """
    Parse command-line arguments.

    Returns:
        argparse.Namespace: Parsed command-line arguments
    """
    parser = argparse.ArgumentParser(
        description="Enrich M365 Unified Audit Log exports with parsed AuditData fields and GeoIP information",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s input.csv
  %(prog)s input.xlsx -o output_enriched.xlsx
  %(prog)s input.csv --skip-geoip -v
  %(prog)s large_export.xlsx -o analyzed.xlsx --verbose
        """
    )

    parser.add_argument(
        "input_file",
        type=str,
        help="Path to the M365 UAL export file (CSV or XLSX format)"
    )

    parser.add_argument(
        "-o", "--output",
        type=str,
        dest="output_file",
        help="Path to the output file (default: <input>_enriched.<ext>)"
    )

    parser.add_argument(
        "--skip-geoip",
        action="store_true",
        help="Skip GeoIP enrichment (useful if MaxMind databases are not available)"
    )

    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose logging output"
    )

    parser.add_argument(
        "--disable-splitting",
        action="store_true",
        help="Disable operation splitting (only generate main enriched file)"
    )

    parser.add_argument(
        "--operations-config",
        type=str,
        dest="operations_config",
        help="Path to operations config YAML file (default: operations_config.yaml)"
    )

    parser.add_argument(
        "--output-dir",
        type=str,
        dest="output_dir",
        help="Output directory for enriched file and operation splits (default: current directory)"
    )

    parser.add_argument(
        "--filter-iocs",
        action="store_true",
        help="Enable IOC filtering mode (requires at least one IOC flag)"
    )

    parser.add_argument(
        "--client-ip",
        type=str,
        dest="client_ip",
        help="Filter by ClientIP (comma-separated list for multiple IPs)"
    )

    parser.add_argument(
        "--session-id",
        type=str,
        dest="session_id",
        help="Filter by SessionId (comma-separated list for multiple session IDs)"
    )

    parser.add_argument(
        "--user-agent",
        type=str,
        dest="user_agent",
        help="Filter by UserAgent (comma-separated list for multiple user agents)"
    )

    parser.add_argument(
        "--token-id",
        type=str,
        dest="token_id",
        help="Filter by UniqueTokenId (comma-separated list for multiple token IDs)"
    )

    return parser.parse_args()


def setup_logging(verbose: bool = False) -> logging.Logger:
    """
    Set up logging to both console and file.

    Args:
        verbose: Enable verbose (DEBUG level) logging

    Returns:
        logging.Logger: Configured logger instance
    """
    logger = logging.getLogger("enrich_ual")
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)

    # Prevent duplicate handlers if function is called multiple times
    if logger.handlers:
        logger.handlers.clear()

    # Create formatters
    detailed_formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    console_formatter = logging.Formatter("%(levelname)s: %(message)s")

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.DEBUG if verbose else logging.INFO)
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)

    # File handler
    log_filename = f"enrich_ual_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    file_handler = logging.FileHandler(log_filename, mode='w', encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(detailed_formatter)
    logger.addHandler(file_handler)

    logger.info(f"Logging to file: {log_filename}")

    return logger


def detect_file_format(file_path: str) -> Tuple[str, str]:
    """
    Detect file format (CSV or XLSX) from file extension.

    Args:
        file_path: Path to the input file

    Returns:
        Tuple of (format, extension) where format is 'csv' or 'xlsx'

    Raises:
        ValueError: If file format is not supported
    """
    path = Path(file_path)
    extension = path.suffix.lower()

    if extension == ".csv":
        return ("csv", extension)
    elif extension in [".xlsx", ".xls"]:
        return ("xlsx", extension)
    else:
        raise ValueError(
            f"Unsupported file format: {extension}. "
            f"Only CSV and XLSX formats are supported."
        )


def generate_output_filename(input_file: str, output_file: str = None, output_dir: str = None) -> str:
    """
    Generate output filename based on input filename.

    Args:
        input_file: Path to the input file
        output_file: Optional user-specified output path
        output_dir: Optional output directory

    Returns:
        Output file path (either user-specified or auto-generated)
    """
    if output_file:
        return output_file

    # Auto-generate: input_enriched.ext
    path = Path(input_file)
    stem = path.stem
    suffix = path.suffix

    # Use output_dir if specified, otherwise use current directory
    if output_dir:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        return str(output_path / f"{stem}_enriched{suffix}")
    else:
        return str(Path.cwd() / f"{stem}_enriched{suffix}")


def load_data(file_path: str, file_format: str, logger: logging.Logger) -> pl.DataFrame:
    """
    Load UAL data from CSV or XLSX file using Polars.

    Args:
        file_path: Path to the input file
        file_format: File format ('csv' or 'xlsx')
        logger: Logger instance

    Returns:
        Polars DataFrame containing the UAL data

    Raises:
        FileNotFoundError: If input file doesn't exist
        Exception: If file cannot be read or parsed
    """
    input_path = Path(file_path)

    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {file_path}")

    logger.info(f"Loading {file_format.upper()} file: {file_path}")

    try:
        if file_format == "csv":
            df = pl.read_csv(file_path)
        elif file_format == "xlsx":
            df = pl.read_excel(file_path)
        else:
            raise ValueError(f"Unsupported format: {file_format}")

        logger.info(f"Loaded {len(df):,} rows and {len(df.columns)} columns")
        logger.debug(f"Columns: {df.columns}")

        # Verify AuditData column exists
        if "AuditData" not in df.columns:
            raise ValueError(
                "Required 'AuditData' column not found in input file. "
                "Please verify this is a valid M365 UAL export."
            )

        return df

    except Exception as e:
        logger.error(f"Failed to load file: {e}")
        raise


def load_appid_lookup(logger: logging.Logger) -> Dict[str, str]:
    """
    Load AppId to friendly name lookup table from CSV.

    Args:
        logger: Logger instance

    Returns:
        Dictionary mapping AppId to AppDisplayName
    """
    global APPID_LOOKUP

    if APPID_LOOKUP is not None:
        return APPID_LOOKUP

    lookup_file = Path(__file__).parent / "appid_lookup.csv"

    if not lookup_file.exists():
        logger.warning(f"AppId lookup file not found: {lookup_file}")
        logger.warning("AppId friendly names will not be available")
        APPID_LOOKUP = {}
        return APPID_LOOKUP

    try:
        logger.debug(f"Loading AppId lookup table from {lookup_file}")
        lookup_df = pl.read_csv(lookup_file)

        # Create dictionary: AppId -> AppDisplayName
        APPID_LOOKUP = dict(zip(
            lookup_df["AppId"].to_list(),
            lookup_df["AppDisplayName"].to_list()
        ))

        logger.info(f"Loaded {len(APPID_LOOKUP):,} AppId mappings")

    except Exception as e:
        logger.warning(f"Failed to load AppId lookup table: {e}")
        APPID_LOOKUP = {}

    return APPID_LOOKUP


def load_operations_config(config_path: Optional[str], logger: logging.Logger) -> Dict[str, Any]:
    """
    Load and validate operations configuration from YAML file.

    Args:
        config_path: Path to the operations config YAML file (or None for default)
        logger: Logger instance

    Returns:
        Dictionary containing the parsed configuration
    """
    global OPERATIONS_CONFIG

    if OPERATIONS_CONFIG is not None:
        return OPERATIONS_CONFIG

    # Determine config file path
    if config_path:
        config_file = Path(config_path)
    else:
        config_file = Path(__file__).parent / "operations_config.yaml"

    if not config_file.exists():
        logger.warning(f"Operations config file not found: {config_file}")
        logger.warning("Operation splitting will be skipped")
        OPERATIONS_CONFIG = {}
        return OPERATIONS_CONFIG

    try:
        logger.debug(f"Loading operations config from {config_file}")

        with open(config_file, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)

        if not config:
            logger.warning("Operations config file is empty")
            OPERATIONS_CONFIG = {}
            return OPERATIONS_CONFIG

        # Validate config structure
        if 'operations' not in config:
            logger.warning("Operations config missing 'operations' section")
            OPERATIONS_CONFIG = {}
            return OPERATIONS_CONFIG

        # Count enabled operations
        enabled_ops = [
            op_name for op_name, op_config in config.get('operations', {}).items()
            if op_config.get('enabled', False)
        ]

        logger.info(f"Loaded operations config: {len(enabled_ops)} enabled operations")
        logger.debug(f"Enabled operations: {', '.join(enabled_ops)}")

        OPERATIONS_CONFIG = config

    except yaml.YAMLError as e:
        logger.error(f"Failed to parse operations config YAML: {e}")
        logger.warning("Operation splitting will be skipped due to config error")
        OPERATIONS_CONFIG = {}
    except Exception as e:
        logger.error(f"Failed to load operations config: {e}")
        logger.warning("Operation splitting will be skipped")
        OPERATIONS_CONFIG = {}

    return OPERATIONS_CONFIG


def extract_flat_field(data: Dict[str, Any], field_path: str, default_value: str = "") -> Any:
    """
    Extract a flat field directly from AuditData JSON.

    Args:
        data: Parsed AuditData JSON dictionary
        field_path: Field name to extract
        default_value: Value to return if field not found

    Returns:
        Field value or default_value if not found
    """
    return data.get(field_path, default_value)


def extract_name_value_array(
    data: Dict[str, Any],
    array_name: str,
    target_name: str,
    default_value: str = ""
) -> Any:
    """
    Extract value from Name/Value array structure.

    Searches for {"Name": target_name, "Value": "..."} in the specified array.

    Args:
        data: Parsed AuditData JSON dictionary
        array_name: Name of the array field (e.g., "ExtendedProperties")
        target_name: Name to search for (e.g., "ResultStatusDetail")
        default_value: Value to return if not found

    Returns:
        The Value associated with target_name, or default_value if not found

    Example:
        data = {"ExtendedProperties": [{"Name": "OS", "Value": "Windows"}]}
        extract_name_value_array(data, "ExtendedProperties", "OS") -> "Windows"
    """
    array = data.get(array_name, [])

    if not isinstance(array, list):
        return default_value

    for item in array:
        if isinstance(item, dict) and item.get("Name") == target_name:
            return item.get("Value", default_value)

    return default_value


def extract_nested_field(
    data: Dict[str, Any],
    field_path: str,
    default_value: str = ""
) -> Any:
    """
    Extract a nested field using dot notation.

    Args:
        data: Parsed AuditData JSON dictionary
        field_path: Dot-separated path (e.g., "Item.ParentFolder.Name")
        default_value: Value to return if field not found

    Returns:
        Field value or default_value if not found

    Example:
        data = {"Item": {"ParentFolder": {"Name": "Inbox"}}}
        extract_nested_field(data, "Item.ParentFolder.Name") -> "Inbox"
    """
    parts = field_path.split(".")
    current = data

    for part in parts:
        if isinstance(current, dict):
            current = current.get(part)
            if current is None:
                return default_value
        else:
            return default_value

    return current if current is not None else default_value


def extract_operation_fields(
    audit_data_str: str,
    operation_config: Dict[str, Any],
    logger: logging.Logger
) -> Dict[str, Any]:
    """
    Extract operation-specific fields from AuditData JSON based on config.

    Args:
        audit_data_str: JSON string from AuditData column
        operation_config: Configuration for this operation from YAML
        logger: Logger instance

    Returns:
        Dictionary of extracted field values
    """
    result = {}

    if not audit_data_str or audit_data_str.strip() == "":
        return result

    try:
        data = json.loads(audit_data_str)
    except json.JSONDecodeError as e:
        logger.debug(f"Failed to parse AuditData for operation extraction: {e}")
        return result

    fields = operation_config.get("fields", [])
    default_value = ""  # Will use global setting later

    for field_config in fields:
        field_type = field_config.get("type")
        output_name = field_config.get("output")

        if not output_name:
            logger.warning(f"Field config missing 'output' name: {field_config}")
            continue

        try:
            if field_type == "flat":
                source = field_config.get("source")
                result[output_name] = extract_flat_field(data, source, default_value)

            elif field_type == "name_value_array":
                array_name = field_config.get("source")
                target_name = field_config.get("name")
                result[output_name] = extract_name_value_array(
                    data, array_name, target_name, default_value
                )

            elif field_type == "nested":
                field_path = field_config.get("source")
                result[output_name] = extract_nested_field(data, field_path, default_value)

            elif field_type == "array_explosion":
                # Array explosion handled separately (MailItemsAccessed)
                continue

            else:
                logger.warning(f"Unknown field type '{field_type}' for field '{output_name}'")

        except Exception as e:
            logger.debug(f"Error extracting field '{output_name}': {e}")
            result[output_name] = default_value

    return result


def extract_operation_fields_with_explosion(
    audit_data_str: str,
    operation_config: Dict[str, Any],
    standard_row_data: Dict[str, Any],
    logger: logging.Logger
) -> List[Dict[str, Any]]:
    """
    Extract operation-specific fields with array explosion support.

    For operations with explode_array=true, this creates multiple rows
    (one per item in the nested array).

    Args:
        audit_data_str: JSON string from AuditData column
        operation_config: Configuration for this operation from YAML
        standard_row_data: Dictionary of standard columns for this row
        logger: Logger instance

    Returns:
        List of dictionaries, each representing a row to output
    """
    result_rows = []

    if not audit_data_str or audit_data_str.strip() == "":
        return result_rows

    try:
        data = json.loads(audit_data_str)
    except json.JSONDecodeError as e:
        logger.debug(f"Failed to parse AuditData for explosion: {e}")
        return result_rows

    fields = operation_config.get("fields", [])
    default_value = ""

    # Find array explosion config
    explosion_config = None
    non_explosion_fields = []

    for field_config in fields:
        if field_config.get("type") == "array_explosion":
            explosion_config = field_config
        else:
            non_explosion_fields.append(field_config)

    if not explosion_config:
        # No explosion, just extract fields normally
        extracted = extract_operation_fields(audit_data_str, operation_config, logger)
        result_rows.append({**standard_row_data, **extracted, "AuditData": audit_data_str})
        return result_rows

    # Extract non-explosion fields once (same for all rows)
    base_fields = {}
    for field_config in non_explosion_fields:
        field_type = field_config.get("type")
        output_name = field_config.get("output")

        if not output_name:
            continue

        try:
            if field_type == "flat":
                source = field_config.get("source")
                base_fields[output_name] = extract_flat_field(data, source, default_value)
            elif field_type == "name_value_array":
                array_name = field_config.get("source")
                target_name = field_config.get("name")
                base_fields[output_name] = extract_name_value_array(
                    data, array_name, target_name, default_value
                )
            elif field_type == "nested":
                field_path = field_config.get("source")
                base_fields[output_name] = extract_nested_field(data, field_path, default_value)
        except Exception as e:
            logger.debug(f"Error extracting base field '{output_name}': {e}")
            base_fields[output_name] = default_value

    # Process array explosion
    array_path = explosion_config.get("array_path")  # e.g., "Folders" or "AffectedItems"
    item_path = explosion_config.get("item_path")    # e.g., "FolderItems" (optional for single-level arrays)
    explosion_fields = explosion_config.get("fields", [])

    # Get the array to explode
    target_array = data.get(array_path, [])

    if not isinstance(target_array, list):
        logger.debug(f"Array path '{array_path}' is not a list")
        return result_rows

    # Check if this is a nested array explosion or single-level array explosion
    if item_path:
        # Nested array explosion (e.g., MailItemsAccessed: Folders → FolderItems)
        # Iterate through parent array (e.g., Folders)
        for parent_item in target_array:
            if not isinstance(parent_item, dict):
                continue

            # Get nested items array (e.g., FolderItems)
            items_array = parent_item.get(item_path, [])

            if not isinstance(items_array, list):
                continue

            # Create a row for each item
            for current_item in items_array:
                if not isinstance(current_item, dict):
                    continue

                # Extract fields for this item
                item_fields = {}

                for field_config in explosion_fields:
                    source = field_config.get("source", "")
                    output_name = field_config.get("output")

                    if not output_name:
                        continue

                    try:
                        # Handle $parent and $current references
                        if source.startswith("$parent."):
                            # Extract from parent item
                            field_path = source.replace("$parent.", "")
                            item_fields[output_name] = extract_nested_field(
                                parent_item, field_path, default_value
                            )
                        elif source.startswith("$current."):
                            # Extract from current item
                            field_path = source.replace("$current.", "")
                            item_fields[output_name] = extract_nested_field(
                                current_item, field_path, default_value
                            )
                        else:
                            # Regular field extraction
                            item_fields[output_name] = extract_nested_field(
                                current_item, source, default_value
                            )
                    except Exception as e:
                        logger.debug(f"Error extracting explosion field '{output_name}': {e}")
                        item_fields[output_name] = default_value

                # Combine all fields for this row
                row_data = {
                    **standard_row_data,
                    **base_fields,
                    **item_fields,
                    "AuditData": audit_data_str
                }

                result_rows.append(row_data)
    else:
        # Single-level array explosion (e.g., HardDelete: AffectedItems)
        # Create a row for each item in the array
        for current_item in target_array:
            if not isinstance(current_item, dict):
                continue

            # Extract fields for this item
            item_fields = {}

            for field_config in explosion_fields:
                source = field_config.get("source", "")
                output_name = field_config.get("output")

                if not output_name:
                    continue

                try:
                    # Handle $current references (no $parent in single-level)
                    if source.startswith("$current."):
                        # Extract from current item
                        field_path = source.replace("$current.", "")
                        item_fields[output_name] = extract_nested_field(
                            current_item, field_path, default_value
                        )
                    else:
                        # Regular field extraction from current item
                        item_fields[output_name] = extract_nested_field(
                            current_item, source, default_value
                        )
                except Exception as e:
                    logger.debug(f"Error extracting explosion field '{output_name}': {e}")
                    item_fields[output_name] = default_value

            # Combine all fields for this row
            row_data = {
                **standard_row_data,
                **base_fields,
                **item_fields,
                "AuditData": audit_data_str
            }

            result_rows.append(row_data)

    return result_rows


def sanitize_ip_address(ip_str: str) -> Optional[str]:
    """
    Sanitize IP address by removing port numbers if present.

    Handles both IPv4:port and IPv6 addresses correctly.

    Args:
        ip_str: IP address string (may include port)

    Returns:
        Sanitized IP address without port, or None if invalid
    """
    if not ip_str:
        return None

    ip_str = ip_str.strip()

    # Check if this looks like IPv6 (contains multiple colons or has brackets)
    if ip_str.count(':') > 1 or '[' in ip_str:
        # IPv6 address handling
        # Format could be: [2001:db8::1]:8080 or 2001:db8::1
        if '[' in ip_str:
            # Extract IPv6 from brackets: [IPv6]:port -> IPv6
            match = re.match(r'\[([^\]]+)\]', ip_str)
            if match:
                return match.group(1)
        # Otherwise assume it's a plain IPv6 without port
        return ip_str

    # IPv4 handling - remove port if present
    # Format: 192.168.1.1:8080 -> 192.168.1.1
    if ':' in ip_str:
        parts = ip_str.split(':')
        # Only keep the first part (IP), discard port
        return parts[0]

    # No port found, return as-is
    return ip_str


def parse_audit_data(audit_data_str: str, logger: logging.Logger) -> Dict[str, Any]:
    """
    Parse AuditData JSON string and extract relevant fields.

    Args:
        audit_data_str: JSON string from AuditData column
        logger: Logger instance

    Returns:
        Dictionary with extracted fields (ClientIP, AppId, SessionId, UserAgent)
    """
    result = {
        "ClientIP": None,
        "AppId": None,
        "AppDisplayName": None,
        "SessionId": None,
        "UserAgent": None,
        "UniqueTokenId": None
    }

    if not audit_data_str or audit_data_str.strip() == "":
        return result

    try:
        data = json.loads(audit_data_str)

        # Extract IP address with fallback: ClientIPAddress -> ClientIP
        raw_ip = data.get("ClientIPAddress") or data.get("ClientIP")
        result["ClientIP"] = sanitize_ip_address(raw_ip) if raw_ip else None

        # Extract AppId with fallback: AppId -> ClientAppId -> ApplicationId
        result["AppId"] = data.get("AppId") or data.get("ClientAppId") or data.get("ApplicationId")

        # Extract AppDisplayName with priority: ClientAppName (nested) -> ClientAppName (root) -> ApplicationDisplayName -> lookup from AppId
        # First try nested ClientAppName in AppAccessContext
        app_context = data.get("AppAccessContext", {})
        if isinstance(app_context, dict):
            result["AppDisplayName"] = app_context.get("ClientAppName")

        # Then try root-level fields
        if not result["AppDisplayName"]:
            result["AppDisplayName"] = data.get("ClientAppName") or data.get("ApplicationDisplayName")

        # If no display name in data, lookup from AppId using lookup table
        if not result["AppDisplayName"] and result["AppId"]:
            appid_lookup = load_appid_lookup(logger)
            result["AppDisplayName"] = appid_lookup.get(result["AppId"])

        # Extract SessionId with fallback: SessionId -> AADSessionId -> DeviceProperties
        result["SessionId"] = data.get("SessionId")
        if not result["SessionId"]:
            # Try nested AADSessionId in AppAccessContext
            app_context = data.get("AppAccessContext", {})
            if isinstance(app_context, dict):
                result["SessionId"] = app_context.get("AADSessionId")

        if not result["SessionId"]:
            # Try nested SessionId in DeviceProperties array
            device_props = data.get("DeviceProperties", [])
            if isinstance(device_props, list):
                for prop in device_props:
                    if isinstance(prop, dict) and prop.get("Name") == "SessionId":
                        result["SessionId"] = prop.get("Value")
                        break

        # Extract UserAgent with fallback: UserAgent -> ActorInfoString -> ExtendedProperties
        result["UserAgent"] = data.get("UserAgent") or data.get("ActorInfoString")

        if not result["UserAgent"]:
            # Try nested UserAgent in ExtendedProperties array
            extended_props = data.get("ExtendedProperties", [])
            if isinstance(extended_props, list):
                for prop in extended_props:
                    if isinstance(prop, dict) and prop.get("Name") == "UserAgent":
                        result["UserAgent"] = prop.get("Value")
                        break

        # Extract UniqueTokenId (direct or from AppAccessContext)
        result["UniqueTokenId"] = data.get("UniqueTokenId")
        if not result["UniqueTokenId"]:
            app_context = data.get("AppAccessContext", {})
            if isinstance(app_context, dict):
                result["UniqueTokenId"] = app_context.get("UniqueTokenId")

    except json.JSONDecodeError as e:
        logger.warning(f"Failed to parse AuditData JSON: {e}")
    except Exception as e:
        logger.warning(f"Unexpected error parsing AuditData: {e}")

    return result


def enrich_audit_data(df: pl.DataFrame, logger: logging.Logger) -> pl.DataFrame:
    """
    Parse AuditData column and add extracted fields as new columns.

    Args:
        df: Input DataFrame with AuditData column
        logger: Logger instance

    Returns:
        DataFrame with additional columns (ClientIP, AppId, SessionId, UserAgent)
    """
    logger.info("Parsing AuditData JSON and extracting fields...")

    # Parse JSON and extract fields using Polars' str.json_decode
    # Note: We'll handle this manually row-by-row for better error handling
    parsed_data = []

    for row in tqdm(df.iter_rows(named=True), total=len(df), desc="Parsing AuditData"):
        audit_data = row.get("AuditData", "")
        parsed = parse_audit_data(audit_data, logger)
        parsed_data.append(parsed)

    # Create DataFrame from parsed data
    parsed_df = pl.DataFrame(parsed_data)

    # Combine original and parsed data
    enriched_df = pl.concat([df, parsed_df], how="horizontal")

    # Note: Column reordering will happen after GeoIP enrichment
    # to group ClientIP with Country, City, ASN, Organization

    logger.info(f"Extracted fields for {len(enriched_df):,} rows")
    logger.debug(f"New columns added: {parsed_df.columns}")

    return enriched_df


def enrich_with_geoip(
    df: pl.DataFrame,
    skip_geoip: bool,
    logger: logging.Logger
) -> pl.DataFrame:
    """
    Enrich DataFrame with GeoIP data for unique IP addresses.

    Args:
        df: DataFrame with ClientIP column
        skip_geoip: Whether to skip GeoIP enrichment
        logger: Logger instance

    Returns:
        DataFrame with GeoIP columns added (Country, City, ASN, Organization)

    Raises:
        FileNotFoundError: If MaxMind databases not found and skip_geoip is False
    """
    if skip_geoip:
        logger.info("Skipping GeoIP enrichment (--skip-geoip flag set)")
        # Add empty GeoIP columns before AuditData
        enriched_df = df.with_columns([
            pl.lit(None).alias("Country"),
            pl.lit(None).alias("City"),
            pl.lit(None).alias("ASN"),
            pl.lit(None).alias("Organization")
        ])

        # Reorder to group IP-related columns together, keep other enriched fields before AuditData
        if "AuditData" in enriched_df.columns:
            ip_related_cols = ["ClientIP", "Country", "City", "ASN", "Organization"]
            other_enriched_cols = ["AppId", "AppDisplayName", "SessionId", "UserAgent", "UniqueTokenId"]
            all_enriched_cols = ip_related_cols + other_enriched_cols

            original_cols = [c for c in enriched_df.columns if c not in all_enriched_cols]
            audit_data_idx = original_cols.index("AuditData")
            cols_before_audit = original_cols[:audit_data_idx]
            cols_from_audit = original_cols[audit_data_idx:]

            new_column_order = cols_before_audit + all_enriched_cols + cols_from_audit
            enriched_df = enriched_df.select(new_column_order)

        return enriched_df

    # Check for MaxMind databases
    project_root = Path(__file__).parent
    city_db_path = project_root / "GeoIPLookup" / "GeoLite2-City" / "GeoLite2-City.mmdb"
    asn_db_path = project_root / "GeoIPLookup" / "GeoLite2-ASN" / "GeoLite2-ASN.mmdb"

    if not city_db_path.exists() or not asn_db_path.exists():
        error_msg = (
            "MaxMind GeoIP databases not found. "
            "Please ensure the following files exist:\n"
            f"  - {city_db_path}\n"
            f"  - {asn_db_path}\n"
            "Use --skip-geoip to skip GeoIP enrichment."
        )
        logger.error(error_msg)
        raise FileNotFoundError(error_msg)

    logger.info("Performing GeoIP enrichment...")

    # Extract unique IPs
    unique_ips = df.select("ClientIP").filter(
        pl.col("ClientIP").is_not_null()
    ).unique()

    logger.info(f"Found {len(unique_ips):,} unique IP addresses to lookup")

    # Perform GeoIP lookups
    geoip_results = []

    with GeoIPLookup(str(city_db_path), str(asn_db_path)) as geoip:
        for row in tqdm(unique_ips.iter_rows(named=True), total=len(unique_ips), desc="GeoIP lookups"):
            ip = row["ClientIP"]
            if ip:
                result = geoip.lookup(ip)
                geoip_results.append({
                    "ClientIP": ip,
                    "Country": result.get("country"),
                    "City": result.get("city"),
                    "ASN": result.get("asn"),
                    "Organization": result.get("organization")
                })

    logger.info(f"Completed GeoIP lookups for {len(geoip_results):,} IPs")

    # Create GeoIP DataFrame
    geoip_df = pl.DataFrame(geoip_results)

    # Join GeoIP data back to main DataFrame
    enriched_df = df.join(geoip_df, on="ClientIP", how="left")

    # Reorder columns: group IP-related fields together, keep other enriched fields before AuditData
    if "AuditData" in enriched_df.columns:
        # Define enriched columns in desired order
        ip_related_cols = ["ClientIP", "Country", "City", "ASN", "Organization"]
        other_enriched_cols = ["AppId", "AppDisplayName", "SessionId", "UserAgent", "UniqueTokenId"]
        all_enriched_cols = ip_related_cols + other_enriched_cols

        # Get original columns (exclude enriched columns)
        original_cols = [c for c in enriched_df.columns if c not in all_enriched_cols]

        # Find AuditData position in original_cols
        audit_data_idx = original_cols.index("AuditData")

        # Split original columns: before and from AuditData
        cols_before_audit = original_cols[:audit_data_idx]
        cols_from_audit = original_cols[audit_data_idx:]

        # New order: original_before + all_enriched + original_from_audit
        new_column_order = cols_before_audit + all_enriched_cols + cols_from_audit
        enriched_df = enriched_df.select(new_column_order)

    return enriched_df


def format_creation_date(df: pl.DataFrame, logger: logging.Logger) -> pl.DataFrame:
    """
    Transform CreationDate from ISO 8601 format to simple datetime format.

    Converts: "2025-11-24T17:41:34.0000000Z" to "2025-11-24 17:41:34"

    Args:
        df: DataFrame with CreationDate column
        logger: Logger instance

    Returns:
        DataFrame with formatted CreationDate
    """
    if "CreationDate" not in df.columns:
        return df

    logger.debug("Formatting CreationDate column")

    try:
        # Strip whitespace, parse ISO 8601 datetime and format as simple datetime string
        df = df.with_columns([
            pl.col("CreationDate")
            .str.strip_chars()  # Remove leading/trailing whitespace
            .str.strptime(pl.Datetime, "%Y-%m-%dT%H:%M:%S%.fZ", strict=False)
            .dt.strftime("%Y-%m-%d %H:%M:%S")
            .alias("CreationDate")
        ])
        logger.debug("CreationDate formatted successfully")
    except Exception as e:
        logger.warning(f"Failed to format CreationDate: {e}")

    return df


def write_output(
    df: pl.DataFrame,
    output_file: str,
    file_format: str,
    logger: logging.Logger
) -> None:
    """
    Write enriched DataFrame to output file.

    Args:
        df: Enriched DataFrame to write
        output_file: Path to output file
        file_format: Output format ('csv' or 'xlsx')
        logger: Logger instance
    """
    logger.info(f"Writing enriched data to {output_file}...")

    try:
        if file_format == "csv":
            df.write_csv(output_file)
        elif file_format == "xlsx":
            df.write_excel(output_file)
        else:
            raise ValueError(f"Unsupported output format: {file_format}")

        logger.info(f"Successfully wrote {len(df):,} rows to {output_file}")

    except Exception as e:
        logger.error(f"Failed to write output file: {e}")
        raise


def split_by_operations(
    df: pl.DataFrame,
    config: Dict[str, Any],
    input_filename: str,
    file_format: str,
    logger: logging.Logger
) -> None:
    """
    Split enriched DataFrame into operation-specific files.

    Args:
        df: Enriched DataFrame with all data
        config: Operations configuration from YAML
        input_filename: Original input filename (for naming split files)
        file_format: Output format ('csv' or 'xlsx')
        logger: Logger instance
    """
    if not config or 'operations' not in config:
        logger.debug("No operations config available, skipping splitting")
        return

    # Get settings
    settings = config.get('settings', {})
    output_dir_name = settings.get('output_directory', 'Operations')

    # Create output directory relative to the enriched file's directory
    # input_filename here is actually the enriched output file path
    enriched_file_path = Path(input_filename)
    enriched_file_dir = enriched_file_path.parent if enriched_file_path.parent != Path('.') else Path.cwd()
    output_path = enriched_file_dir / output_dir_name
    output_path.mkdir(exist_ok=True)
    logger.info(f"Created operations directory: {output_path}")

    # Get base filename without extension
    base_name = enriched_file_path.stem

    # Standard columns to include in all split files
    standard_columns = [
        "CreationDate", "Operation", "UserId", "ClientIP", "Country", "City",
        "ASN", "Organization", "AppId", "AppDisplayName", "SessionId",
        "UserAgent", "UniqueTokenId"
    ]

    # Filter to columns that actually exist in the DataFrame
    available_standard_cols = [col for col in standard_columns if col in df.columns]

    # Process each operation
    operations = config.get('operations', {})

    for operation_name, operation_config in operations.items():
        if not operation_config.get('enabled', False):
            logger.debug(f"Skipping disabled operation: {operation_name}")
            continue

        logger.info(f"Processing operation: {operation_name}")

        # Filter rows for this operation
        operation_df = df.filter(pl.col("Operation") == operation_name)

        if len(operation_df) == 0:
            logger.info(f"No rows found for operation: {operation_name}")
            continue

        logger.info(f"Found {len(operation_df):,} rows for {operation_name}")

        # Check if this operation uses array explosion
        if operation_config.get('explode_array', False):
            logger.info(f"Using array explosion for {operation_name}")

            # Extract operation-specific fields with array explosion
            all_rows = []

            for row in tqdm(
                operation_df.iter_rows(named=True),
                total=len(operation_df),
                desc=f"Exploding {operation_name} arrays"
            ):
                # Build standard row data from available standard columns
                standard_data = {col: row.get(col) for col in available_standard_cols}
                audit_data = row.get("AuditData", "")

                # Extract with explosion - returns list of row dicts
                exploded_rows = extract_operation_fields_with_explosion(
                    audit_data, operation_config, standard_data, logger
                )
                all_rows.extend(exploded_rows)

            # Create DataFrame from exploded rows
            if all_rows:
                result_df = pl.DataFrame(all_rows, infer_schema_length=None)

                # Write to file
                output_filename = f"{base_name}_{operation_name}.{file_format}"
                output_file = output_path / output_filename

                try:
                    if file_format == "csv":
                        result_df.write_csv(output_file)
                    elif file_format == "xlsx":
                        result_df.write_excel(output_file)

                    logger.info(f"Wrote {len(result_df):,} exploded rows to {output_file}")

                except Exception as e:
                    logger.error(f"Failed to write {operation_name} file: {e}")
                    continue
            else:
                logger.warning(f"No exploded rows generated for {operation_name}")

        else:
            # Standard extraction (no array explosion)
            operation_data = []

            for row in tqdm(
                operation_df.iter_rows(named=True),
                total=len(operation_df),
                desc=f"Extracting {operation_name} fields"
            ):
                audit_data = row.get("AuditData", "")
                extracted = extract_operation_fields(audit_data, operation_config, logger)
                operation_data.append(extracted)

            # Create DataFrame with extracted fields
            if operation_data:
                operation_fields_df = pl.DataFrame(operation_data)

                # Combine: standard columns + operation-specific columns + AuditData
                # Start with standard columns
                result_df = operation_df.select(available_standard_cols)

                # Add operation-specific columns
                result_df = pl.concat([result_df, operation_fields_df], how="horizontal")

                # Add AuditData column at the end
                if "AuditData" in operation_df.columns:
                    result_df = result_df.with_columns([
                        operation_df["AuditData"]
                    ])

                # Write to file
                output_filename = f"{base_name}_{operation_name}.{file_format}"
                output_file = output_path / output_filename

                try:
                    if file_format == "csv":
                        result_df.write_csv(output_file)
                    elif file_format == "xlsx":
                        result_df.write_excel(output_file)

                    logger.info(f"Wrote {len(result_df):,} rows to {output_file}")

                except Exception as e:
                    logger.error(f"Failed to write {operation_name} file: {e}")
                    continue

    logger.info("Operation splitting completed")


def parse_ioc_list(ioc_string: Optional[str]) -> List[str]:
    """
    Parse comma-separated IOC string into a list of IOCs.

    Args:
        ioc_string: Comma-separated IOC values or None

    Returns:
        List of IOC values (empty list if None)
    """
    if not ioc_string:
        return []

    # Split by comma and strip whitespace
    return [ioc.strip() for ioc in ioc_string.split(',') if ioc.strip()]


def filter_by_iocs(
    df: pl.DataFrame,
    client_ips: List[str],
    session_ids: List[str],
    user_agents: List[str],
    token_ids: List[str],
    logger: logging.Logger
) -> Tuple[pl.DataFrame, Dict[str, Any]]:
    """
    Filter DataFrame by IOCs with exact match and OR logic.

    Args:
        df: Enriched DataFrame
        client_ips: List of ClientIP values to match
        session_ids: List of SessionId values to match
        user_agents: List of UserAgent values to match
        token_ids: List of UniqueTokenId values to match
        logger: Logger instance

    Returns:
        Tuple of (filtered DataFrame, summary dict with match statistics)
    """
    # Initialize summary
    summary = {
        'total_searched': 0,
        'total_found': 0,
        'total_rows_matched': 0,
        'iocs_found': {},
        'iocs_not_found': {},
        'operations_with_matches': set()
    }

    # Build filter conditions (OR logic across all IOCs)
    conditions = []

    # Track all IOCs being searched
    all_iocs = {
        'ClientIP': client_ips,
        'SessionId': session_ids,
        'UserAgent': user_agents,
        'UniqueTokenId': token_ids
    }

    # Build filter conditions and track searched IOCs
    for column, ioc_list in all_iocs.items():
        if not ioc_list:
            continue

        # Check if column exists in DataFrame
        if column not in df.columns:
            logger.warning(f"Column '{column}' not found in enriched data, skipping")
            continue

        for ioc in ioc_list:
            summary['total_searched'] += 1

            # Create exact match condition
            condition = pl.col(column) == ioc
            conditions.append(condition)

            # Count matches for this IOC
            matches = df.filter(condition)
            match_count = len(matches)

            if match_count > 0:
                summary['total_found'] += 1
                summary['iocs_found'][f"{column}={ioc}"] = match_count

                # Track which operations contain this IOC
                if 'Operation' in matches.columns:
                    ops = matches['Operation'].unique().to_list()
                    summary['operations_with_matches'].update(ops)
            else:
                summary['iocs_not_found'][f"{column}={ioc}"] = 0

    # Apply filter if we have any conditions
    if conditions:
        # Combine all conditions with OR
        combined_condition = conditions[0]
        for condition in conditions[1:]:
            combined_condition = combined_condition | condition

        filtered_df = df.filter(combined_condition)
        summary['total_rows_matched'] = len(filtered_df)

        logger.info(f"IOC filtering matched {summary['total_rows_matched']:,} rows")
    else:
        filtered_df = pl.DataFrame()
        logger.warning("No valid IOC filters applied")

    return filtered_df, summary


def print_ioc_summary(summary: Dict[str, Any], logger: logging.Logger) -> None:
    """
    Print IOC filtering summary to console.

    Args:
        summary: Summary dictionary from filter_by_iocs
        logger: Logger instance
    """
    print("\n" + "=" * 70)
    print("IOC FILTERING SUMMARY")
    print("=" * 70)

    print(f"\nTotal IOCs searched: {summary['total_searched']}")
    print(f"Total IOCs found: {summary['total_found']}")
    print(f"Total rows matched: {summary['total_rows_matched']:,}")

    if summary['iocs_found']:
        print("\n" + "-" * 70)
        print("IOCs FOUND:")
        print("-" * 70)
        for ioc, count in sorted(summary['iocs_found'].items(), key=lambda x: x[1], reverse=True):
            print(f"  {ioc}: {count:,} matches")

    if summary['iocs_not_found']:
        print("\n" + "-" * 70)
        print("IOCs NOT FOUND (WARNING):")
        print("-" * 70)
        for ioc in sorted(summary['iocs_not_found'].keys()):
            print(f"  {ioc}")
            logger.warning(f"IOC not found in data: {ioc}")

    if summary['operations_with_matches']:
        print("\n" + "-" * 70)
        print(f"OPERATIONS WITH MATCHES ({len(summary['operations_with_matches'])}):")
        print("-" * 70)
        for op in sorted(summary['operations_with_matches']):
            print(f"  - {op}")

    print("\n" + "=" * 70 + "\n")


def main():
    """Main entry point for the enrich_ual utility."""
    args = parse_arguments()
    logger = setup_logging(verbose=args.verbose)

    try:
        # Check if IOC filtering mode is enabled
        if args.filter_iocs:
            logger.info("Starting IOC filtering mode")
            logger.debug(f"Arguments: {args}")

            # Validate that at least one IOC type is provided
            if not any([args.client_ip, args.session_id, args.user_agent, args.token_id]):
                logger.error("--filter-iocs requires at least one IOC flag (--client-ip, --session-id, --user-agent, --token-id)")
                return 1

            # Parse IOC lists
            client_ips = parse_ioc_list(args.client_ip)
            session_ids = parse_ioc_list(args.session_id)
            user_agents = parse_ioc_list(args.user_agent)
            token_ids = parse_ioc_list(args.token_id)

            logger.info(f"Searching for {len(client_ips)} ClientIP(s), {len(session_ids)} SessionId(s), "
                       f"{len(user_agents)} UserAgent(s), {len(token_ids)} UniqueTokenId(s)")

            # Validate and detect input file format
            file_format, _ = detect_file_format(args.input_file)
            logger.info(f"Detected file format: {file_format.upper()}")

            # Load enriched data (should already be enriched)
            df = load_data(args.input_file, file_format, logger)

            # Filter by IOCs
            filtered_df, summary = filter_by_iocs(
                df, client_ips, session_ids, user_agents, token_ids, logger
            )

            if len(filtered_df) == 0:
                print_ioc_summary(summary, logger)
                logger.info("No matches found. No files will be created.")
                return 0

            # Generate output filename for filtered data
            input_path = Path(args.input_file)
            base_name = input_path.stem

            # Use output_dir if specified, otherwise use current directory
            if args.output_dir:
                output_path = Path(args.output_dir)
                output_path.mkdir(parents=True, exist_ok=True)
                filtered_output = output_path / f"{base_name}_ioc_filtered.{file_format}"
            else:
                filtered_output = Path.cwd() / f"{base_name}_ioc_filtered.{file_format}"

            # Write filtered enriched output
            logger.info(f"Writing filtered data to: {filtered_output}")
            write_output(filtered_df, str(filtered_output), file_format, logger)

            # Split by operations with IOC-filtered data
            try:
                logger.info("Starting operation splitting for IOC-filtered data...")
                config = load_operations_config(args.operations_config, logger)

                if config and config.get('operations'):
                    # Modify output directory for IOC filtered operations
                    original_dir = config.get('settings', {}).get('output_directory', 'Operations')
                    config.setdefault('settings', {})['output_directory'] = 'IOC_Filtered_Operations'

                    split_by_operations(
                        filtered_df,
                        config,
                        str(filtered_output),  # Use filtered output as base name
                        file_format,
                        logger
                    )

                    # Restore original directory setting
                    config['settings']['output_directory'] = original_dir
                else:
                    logger.warning("No operations config available, skipping operation splitting")
            except Exception as e:
                logger.error(f"Error during operation splitting: {e}", exc_info=True)
                logger.warning("Continuing to print summary despite operation splitting error")

            # Print summary (always print even if splitting failed)
            print_ioc_summary(summary, logger)

            logger.info("IOC filtering completed successfully!")
            return 0

        # Normal enrichment mode (no IOC filtering)
        logger.info("Starting M365 UAL enrichment process")
        logger.debug(f"Arguments: {args}")

        # Validate and detect input file format
        file_format, _ = detect_file_format(args.input_file)
        logger.info(f"Detected file format: {file_format.upper()}")

        # Generate output filename if not specified
        output_file = generate_output_filename(args.input_file, args.output_file, args.output_dir)
        logger.info(f"Output file: {output_file}")

        # Load input data
        df = load_data(args.input_file, file_format, logger)

        # Enrich with parsed AuditData fields
        df = enrich_audit_data(df, logger)

        # Enrich with GeoIP data
        df = enrich_with_geoip(df, args.skip_geoip, logger)

        # Format CreationDate column
        df = format_creation_date(df, logger)

        # Write main enriched output
        write_output(df, output_file, file_format, logger)

        # Split by operations (unless disabled)
        if not args.disable_splitting:
            logger.info("Starting operation splitting...")
            config = load_operations_config(args.operations_config, logger)

            if config and config.get('operations'):
                # Pass the enriched output file path so operations go in same directory
                split_by_operations(df, config, output_file, file_format, logger)
            else:
                logger.info("No operations config available, skipping operation splitting")
        else:
            logger.info("Operation splitting disabled by --disable-splitting flag")

        logger.info("Enrichment process completed successfully!")
        return 0

    except FileNotFoundError as e:
        logger.error(str(e))
        return 1
    except Exception as e:
        logger.error(f"Unexpected error: {e}", exc_info=True)
        return 1


if __name__ == "__main__":
    main()
