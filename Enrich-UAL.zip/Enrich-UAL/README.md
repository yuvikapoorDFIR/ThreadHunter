# enrich_ual - M365 Unified Audit Log Enrichment Utility

A Python utility designed to parse and enrich Microsoft 365 Unified Audit Log (UAL) data exported from the M365 Security & Compliance Center. The tool extracts valuable fields from the AuditData JSON column and adds them as separate columns for easier analysis and investigation.

## Features

- **AuditData JSON Parsing**: Automatically extracts key fields from nested JSON data
- **GeoIP Enrichment**: Adds geographic context (country, city, ASN, organization) to IP addresses
- **Multiple Format Support**: Works with both CSV and XLSX files
- **Intelligent Field Fallbacks**: Handles variations in AuditData field names (e.g., ClientIPAddress vs ClientIP)
- **Progress Tracking**: Real-time progress bars for long-running operations
- **Comprehensive Logging**: Dual output to console and log file with verbosity control
- **Error Resilience**: Gracefully handles malformed JSON and missing fields

## Installation

1. Clone or download this repository
2. Install required dependencies:

```bash
pip install -r requirements.txt
```

### Dependencies

- `polars>=0.20.0` - High-performance DataFrame library
- `tqdm>=4.66.0` - Progress bar support
- `openpyxl>=3.1.0` - Excel file support
- `geoip2>=4.7.0` - GeoIP lookups (via local GeoIPLookup module)

## GeoIP Database Setup

For GeoIP enrichment to work, you need MaxMind GeoLite2 databases:

1. Download the free GeoLite2 databases from [MaxMind](https://dev.maxmind.com/geoip/geolite2-free-geolocation-data)
2. Place the database files in the following locations:
   - `GeoIPLookup/GeoLite2-City/GeoLite2-City.mmdb`
   - `GeoIPLookup/GeoLite2-ASN/GeoLite2-ASN.mmdb`

Alternatively, use the `--skip-geoip` flag to skip GeoIP enrichment.

## Usage

### Basic Usage

```bash
# Process a CSV file
python enrich_ual.py input.csv

# Process an XLSX file
python enrich_ual.py input.xlsx

# Specify output file
python enrich_ual.py input.csv -o output_enriched.csv

# Skip GeoIP enrichment
python enrich_ual.py input.csv --skip-geoip

# Enable verbose logging
python enrich_ual.py input.csv -v
```

### Command-Line Options

```
positional arguments:
  input_file            Path to the M365 UAL export file (CSV or XLSX format)

options:
  -h, --help            Show help message and exit
  -o OUTPUT_FILE, --output OUTPUT_FILE
                        Path to the output file (default: <input>_enriched.<ext>)
  --skip-geoip          Skip GeoIP enrichment (useful if MaxMind databases are not available)
  -v, --verbose         Enable verbose logging output
```

### Output

The tool generates:
1. **Enriched data file**: Original file with additional columns (same format as input)
2. **Log file**: Timestamped log file (`enrich_ual_YYYYMMDD_HHMMSS.log`)

## Extracted Fields

The tool extracts the following fields from the `AuditData` JSON column:

| Column | Source | Description |
|--------|--------|-------------|
| `ClientIP` | `ClientIPAddress` or `ClientIP` | IP address of the client |
| `AppId` | `AppId` or `ClientAppId` | Application/client identifier |
| `SessionId` | `SessionId` | Session identifier for correlating events |
| `UserAgent` | `UserAgent` | Browser/client user agent string |
| `Country` | GeoIP Lookup | Country of IP address |
| `City` | GeoIP Lookup | City of IP address |
| `ASN` | GeoIP Lookup | Autonomous System Number |
| `Organization` | GeoIP Lookup | ISP/Organization name |

### Field Fallback Logic

The tool implements intelligent fallback for field variations:
- **IP Address**: Tries `ClientIPAddress` first, then falls back to `ClientIP`
- **Application ID**: Tries `AppId` first, then falls back to `ClientAppId`

## Use Cases

### DFIR Investigations

This tool is particularly useful for:

1. **Business Email Compromise (BEC)**: Track suspicious login locations and session patterns
2. **Insider Threat**: Correlate user activities across sessions and identify anomalous locations
3. **Account Takeover**: Identify geographic impossibilities and session hijacking
4. **Data Exfiltration**: Track file access patterns with geographic and temporal context
5. **Incident Response**: Quick triage of UAL data to identify suspicious activity

### Example Workflow

1. Export UAL data from M365 Security & Compliance Center (CSV or XLSX)
2. Run `enrich_ual` tool against the export:
   ```bash
   python enrich_ual.py m365_audit_export.csv -v
   ```
3. Analyze enriched data in Excel, Splunk, ELK, or other analysis tools
4. Filter by country, ASN, or session patterns to identify anomalies
5. Use `SessionId` to correlate related events during investigation

## Performance Considerations

- **Polars DataFrame**: Chosen for excellent performance with large datasets (100k+ rows)
- **Unique IP Caching**: GeoIP lookups are performed only once per unique IP address
- **Progress Tracking**: `tqdm` progress bars provide real-time feedback for long operations
- **Efficient Column Operations**: Minimizes memory usage through efficient DataFrame operations

## Error Handling

The tool is designed to be resilient:

- **Malformed JSON**: Logs warnings but continues processing
- **Missing Fields**: Returns `None` for fields that don't exist in the JSON
- **Invalid IPs**: Skips GeoIP lookup but continues processing
- **Missing Databases**: Fails with clear error message (unless `--skip-geoip` is used)

## Logging

Logs are written to both:
1. **Console**: Human-readable format with severity levels
2. **Log File**: Detailed timestamped logs with full context

Use `-v` or `--verbose` for DEBUG-level logging.

## Project Structure

```
Enrich-UAL/
├── .claude.md                  # Project context for Claude
├── enrich_ual.py               # Main utility script
├── requirements.txt            # Python dependencies
├── README.md                   # This file
├── GeoIPLookup/                # Custom geolocation module
│   ├── geoip_lookup.py         # GeoIPLookup class
│   ├── requirements.txt        # GeoIPLookup dependencies
│   ├── GeoLite2-ASN/           # MaxMind ASN database
│   │   └── GeoLite2-ASN.mmdb
│   └── GeoLite2-City/          # MaxMind City database
│       └── GeoLite2-City.mmdb
└── examples/                   # Example files
    ├── sample_ual.csv          # Sample input
    └── sample_ual_enriched.csv # Sample output
```

## Future Enhancements

Planned features for future versions:

- User agent parsing (device type, OS, browser)
- Extract specific key operations and flatten ideal fields for those into new files (CSV) / sheets (XLSX)
- Bulk operation support for multiple files
- Integration with threat intelligence feeds for IP reputation
- Export to JSON/JSONL for SIEM ingestion
- Summary statistics and anomaly detection
- Time zone normalization for temporal analysis

## License

This tool is provided as-is for DFIR and security analysis purposes.

## Author

Created for digital forensics and incident response investigations involving Microsoft 365 environments.

## Related Tools

- **M365 Investigator** - Microsoft's UAL analysis tool
- **GeoIPLookup** - Custom MaxMind GeoIP2 wrapper (included)
- **Splunk/ELK** - SIEM platforms for centralized log analysis
