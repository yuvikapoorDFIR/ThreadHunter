"""
MaxMind GeoIP Lookup Module
Author: Stephen
Description: A reusable module for performing IP geolocation lookups using MaxMind databases
"""

import geoip2.database
import geoip2.errors
from pathlib import Path
from typing import Dict, Optional


class GeoIPLookup:
    """
    A class for performing IP geolocation lookups using MaxMind GeoIP2 databases.
    
    Attributes:
        city_db_path (str): Path to the GeoLite2-City.mmdb database
        asn_db_path (str): Path to the GeoLite2-ASN.mmdb database
    """
    
    def __init__(self, city_db_path: str, asn_db_path: str):
        """
        Initialize the GeoIPLookup class with database paths.
        
        Args:
            city_db_path (str): Path to the MaxMind City database (GeoLite2-City.mmdb)
            asn_db_path (str): Path to the MaxMind ASN database (GeoLite2-ASN.mmdb)
            
        Raises:
            FileNotFoundError: If either database file doesn't exist
        """
        self.city_db_path = Path(city_db_path)
        self.asn_db_path = Path(asn_db_path)
        
        # Validate database files exist
        if not self.city_db_path.exists():
            raise FileNotFoundError(f"City database not found: {city_db_path}")
        if not self.asn_db_path.exists():
            raise FileNotFoundError(f"ASN database not found: {asn_db_path}")
        
        # Initialize database readers
        self.city_reader = geoip2.database.Reader(str(self.city_db_path))
        self.asn_reader = geoip2.database.Reader(str(self.asn_db_path))
    
    def lookup(self, ip_address: str) -> Dict[str, Optional[str]]:
        """
        Perform a geolocation lookup for the given IP address.
        
        Args:
            ip_address (str): The IP address to lookup
            
        Returns:
            Dict[str, Optional[str]]: Dictionary containing:
                - ip: The queried IP address
                - country: Country name
                - city: City name
                - asn: Autonomous System Number
                - organization: Organization/ISP name
                
        Example:
            >>> geoip = GeoIPLookup('/path/to/GeoLite2-City.mmdb', '/path/to/GeoLite2-ASN.mmdb')
            >>> result = geoip.lookup('8.8.8.8')
            >>> print(result)
            {
                'ip': '8.8.8.8',
                'country': 'United States',
                'city': 'Mountain View',
                'asn': 'AS15169',
                'organization': 'Google LLC'
            }
        """
        result = {
            'ip': ip_address,
            'country': None,
            'city': None,
            'asn': None,
            'organization': None
        }
        
        # Lookup city and country data
        try:
            city_response = self.city_reader.city(ip_address)
            result['country'] = city_response.country.name
            result['city'] = city_response.city.name
        except geoip2.errors.AddressNotFoundError:
            # IP not found in city database
            pass
        except Exception as e:
            # Log other exceptions but continue
            print(f"Warning: Error looking up city data for {ip_address}: {e}")
        
        # Lookup ASN and organization data
        try:
            asn_response = self.asn_reader.asn(ip_address)
            result['asn'] = f"AS{asn_response.autonomous_system_number}"
            result['organization'] = asn_response.autonomous_system_organization
        except geoip2.errors.AddressNotFoundError:
            # IP not found in ASN database
            pass
        except Exception as e:
            # Log other exceptions but continue
            print(f"Warning: Error looking up ASN data for {ip_address}: {e}")
        
        return result
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - close database readers"""
        self.close()
    
    def close(self):
        """Close the database readers to free resources"""
        self.city_reader.close()
        self.asn_reader.close()


if __name__ == "__main__":
    # Example usage
    import sys
    
    if len(sys.argv) < 4:
        print("Usage: python geoip_lookup.py <city_db_path> <asn_db_path> <ip_address>")
        print("\nExample:")
        print("  python geoip_lookup.py ./GeoLite2-City.mmdb ./GeoLite2-ASN.mmdb 8.8.8.8")
        sys.exit(1)
    
    city_db = sys.argv[1]
    asn_db = sys.argv[2]
    ip = sys.argv[3]
    
    # Using context manager to ensure proper cleanup
    with GeoIPLookup(city_db, asn_db) as geoip:
        result = geoip.lookup(ip)
        
        print(f"\nGeoIP Lookup Results for {ip}:")
        print("-" * 50)
        for key, value in result.items():
            print(f"{key:15}: {value if value else 'N/A'}")